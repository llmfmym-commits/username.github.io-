package com.nova.browser;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class BrowserPrefs {
    private static final String FILE = "nova_browser";
    private final SharedPreferences store;

    public BrowserPrefs(Context context) {
        store = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public void saveLastUrl(String url) {
        store.edit().putString("last_url", url).apply();
    }

    public String lastUrl() {
        return store.getString("last_url", "");
    }

    public void addHistory(String url) {
        Set<String> values = new LinkedHashSet<>(history());
        values.remove(url);
        values.add(url);
        while (values.size() > 100) {
            String first = values.iterator().next();
            values.remove(first);
        }
        store.edit().putStringSet("history", values).apply();
    }

    public List<String> history() {
        Set<String> values = store.getStringSet("history", new LinkedHashSet<>());
        ArrayList<String> result = new ArrayList<>(values);
        java.util.Collections.reverse(result);
        return result;
    }

    public void addBookmark(String url) {
        Set<String> values = new LinkedHashSet<>(store.getStringSet("bookmarks", new LinkedHashSet<>()));
        values.add(url);
        store.edit().putStringSet("bookmarks", values).apply();
    }

    public List<String> bookmarks() {
        return new ArrayList<>(store.getStringSet("bookmarks", new LinkedHashSet<>()));
    }
}
