package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.content.Intent
import android.net.Uri
import android.webkit.*
import android.widget.*
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var prefs: BrowserPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BrowserPrefs(this)
        buildInterface()
        configureWebView()
        val lastUrl = prefs.lastUrl()
        loadInput(lastUrl.ifBlank { "https://www.google.com" })
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF7F8FA.toInt())
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 4)
        }

        address = EditText(this).apply {
            hint = "جست‌وجو یا وارد کردن نشانی"
            singleLine = true
            textSize = 15f
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setPadding(14, 0, 14, 0)
            setBackgroundColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, 48, 1f)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) {
                    loadInput(text.toString())
                    true
                } else false
            }
        }

        fun toolButton(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                textSize = 12f
                minWidth = 42
                setPadding(2, 0, 2, 0)
                setOnClickListener { action() }
            }

        top.addView(toolButton("‹") { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() })
        top.addView(address)
        top.addView(toolButton("→") { if (::webView.isInitialized && webView.canGoForward()) webView.goForward() })
        top.addView(toolButton("↻") { if (::webView.isInitialized) webView.reload() })
        root.addView(top)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 3
        ))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 2, 4, 2)
        }
        fun bottomButton(label: String, action: () -> Unit) {
            bottom.addView(Button(this).apply {
                text = label
                textSize = 11f
                setOnClickListener { action() }
                layoutParams = LinearLayout.LayoutParams(0, 48, 1f)
            })
        }
        bottomButton("خانه") { loadInput("https://www.google.com") }
        bottomButton("نشانک") { 
            val url = webView.url ?: return@bottomButton
            prefs.addBookmark(url)
            Toast.makeText(this, "به نشانک‌ها اضافه شد", Toast.LENGTH_SHORT).show()
        }
        bottomButton("تاریخچه") {
            val entries = prefs.history()
            AlertDialog.Builder(this)
                .setTitle("تاریخچه")
                .setItems(entries.toTypedArray()) { _, which -> loadInput(entries[which]) }
                .setNegativeButton("بستن", null).show()
        }
        bottomButton("دانلودها") {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        }
        root.addView(bottom)

        setContentView(root)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    false
                } else {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                address.setText(url)
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                address.setText(url)
                prefs.saveLastUrl(url)
                prefs.addHistory(url)
                progress.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                this@MainActivity.title = title ?: "Nova Browser"
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                addRequestHeader("User-Agent", userAgent)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                setDestinationInExternalPublicDir(
                    android.os.Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
                )
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            Toast.makeText(this, "دانلود شروع شد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadInput(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val target = if (value.startsWith("http://") || value.startsWith("https://")) {
            value
        } else if (value.contains(".") && !value.contains(" ")) {
            "https://$value"
        } else {
            "https://www.google.com/search?q=" + Uri.encode(value)
        }
        webView.loadUrl(target)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
