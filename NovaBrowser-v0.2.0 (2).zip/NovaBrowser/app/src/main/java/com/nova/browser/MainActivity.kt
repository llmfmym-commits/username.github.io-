package com.nova.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private val C_BG = Color.parseColor("#0B0D26")
private val C_STRIP = Color.parseColor("#080A1E")
private val C_TOOLBAR = Color.parseColor("#13163A")
private val C_TOOLBAR_INCOGNITO = Color.parseColor("#1F1238")
private val C_PILL = Color.parseColor("#1C1F4A")
private val C_PILL_STROKE = Color.parseColor("#2E3270")
private val C_TEXT = Color.parseColor("#E8EAFF")
private val C_MUTED = Color.parseColor("#9AA0D0")
private val C_ACCENT = Color.parseColor("#5B6CFF")
private val C_ACCENT_LIGHT = Color.parseColor("#9FB0FF")
private val C_DIVIDER = Color.parseColor("#2A2E60")
private val C_MENU = Color.parseColor("#202346")
private val C_MENU_STROKE = Color.parseColor("#343974")
private val C_WARN = Color.parseColor("#FFB74D")
private val C_STAR = Color.parseColor("#FFD54F")
private val C_INCOGNITO = Color.parseColor("#C3A6FF")
private val C_TITLE = Color.parseColor("#C9CEFF")
private val C_TAG1 = Color.parseColor("#8EA2FF")
private val C_TAG2 = Color.parseColor("#5CC8FF")
private val C_TAG3 = Color.parseColor("#A98BFF")

private const val REQ_FILE = 1001
private const val REQ_VOICE = 1002
private const val REQ_STORAGE = 1003
private const val MAX_TABS = 20

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

internal class BrowserTab(val incognito: Boolean) {
    var webView: WebView? = null
    var title: String = ""
    var url: String = ""
    var desktop: Boolean = false
    var zoom: Int = 100
}

internal class PendingDownload(
    val url: String,
    val userAgent: String?,
    val contentDisposition: String?,
    val mimeType: String?
)

internal class ShortcutDef(
    val label: String,
    val url: String,
    val glyph: String,
    val bg: Drawable,
    val fg: Int
)

class MainActivity : Activity() {

    private lateinit var prefs: BrowserPrefs
    private val tabs = ArrayList<BrowserTab>()
    private var currentIndex = 0

    private lateinit var rootFrame: FrameLayout
    private lateinit var root: LinearLayout
    private lateinit var tabRow: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var tabCountTop: TextView
    private lateinit var tabCountBottom: TextView
    private lateinit var toolbar: LinearLayout
    private lateinit var address: EditText
    private lateinit var lockIcon: ImageView
    private lateinit var starIcon: ImageView
    private lateinit var progressBar: View
    private lateinit var content: FrameLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var btnBack: ImageView
    private lateinit var btnForward: ImageView
    private lateinit var fullscreenHolder: FrameLayout

    private var menuPopup: PopupWindow? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingDownload: PendingDownload? = null

    private val engines = listOf(
        Pair("Google", "https://www.google.com/search?q="),
        Pair("DuckDuckGo", "https://duckduckgo.com/?q="),
        Pair("Bing", "https://www.bing.com/search?q=")
    )
    private val engineColors = intArrayOf(
        Color.parseColor("#4285F4"),
        Color.parseColor("#DE5833"),
        Color.parseColor("#00897B")
    )

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BrowserPrefs(this)
        styleWindow()
        buildInterface()
        restoreTabs()
        if (savedInstanceState == null) handleIntent(intent)
        showCurrent()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        showCurrent()
    }

    override fun onPause() {
        saveTabs()
        tabs.getOrNull(currentIndex)?.webView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        tabs.getOrNull(currentIndex)?.webView?.onResume()
    }

    override fun onDestroy() {
        for (t in tabs) {
            val wv = t.webView
            if (wv != null) {
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.stopLoading()
                wv.destroy()
            }
            t.webView = null
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (menuPopup?.isShowing == true) {
            menuPopup?.dismiss()
            return
        }
        if (customView != null) {
            hideCustomView()
            return
        }
        val wv = current().webView
        if (wv != null) {
            if (wv.canGoBack()) wv.goBack() else goHome()
            return
        }
        if (tabs.size > 1) {
            closeTab(currentIndex)
            return
        }
        super.onBackPressed()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.isCtrlPressed) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_T -> {
                    newTab(false)
                    return true
                }
                KeyEvent.KEYCODE_W -> {
                    closeTab(currentIndex)
                    return true
                }
                KeyEvent.KEYCODE_L -> {
                    focusAddress()
                    return true
                }
                KeyEvent.KEYCODE_R -> {
                    reload()
                    return true
                }
                KeyEvent.KEYCODE_B -> {
                    showBookmarks()
                    return true
                }
                KeyEvent.KEYCODE_H -> {
                    showHistory()
                    return true
                }
                KeyEvent.KEYCODE_J -> {
                    openDownloads()
                    return true
                }
                else -> {
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun current(): BrowserTab = tabs[currentIndex]

    private fun isCurrent(tab: BrowserTab): Boolean =
        tabs.isNotEmpty() && currentIndex < tabs.size && tabs[currentIndex] === tab

    private fun roundRect(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
        return d
    }

    private fun rippleBg(borderless: Boolean): Drawable? {
        val out = TypedValue()
        val attr = if (borderless) android.R.attr.selectableItemBackgroundBorderless
        else android.R.attr.selectableItemBackground
        return if (theme.resolveAttribute(attr, out, true) && out.resourceId != 0) {
            resources.getDrawable(out.resourceId, theme)
        } else {
            null
        }
    }

    private fun iconButton(res: Int, sizeDp: Int, iconDp: Int, tint: Int, onClick: (View) -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        val pad = dp((sizeDp - iconDp) / 2)
        v.setPadding(pad, pad, pad, pad)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        v.background = rippleBg(true)
        v.setOnClickListener { onClick(it) }
        return v
    }

    private fun makeCountBadge(): TextView {
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(C_ACCENT_LIGHT)
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.includeFontPadding = false
        val bg = GradientDrawable()
        bg.setColor(Color.TRANSPARENT)
        bg.cornerRadius = dp(7).toFloat()
        bg.setStroke(dp(2), C_ACCENT_LIGHT)
        tv.background = bg
        tv.setOnClickListener { showTabSwitcher() }
        return tv
    }

    private fun hostOf(url: String): String {
        val host = Uri.parse(url).host
        return if (host.isNullOrEmpty()) url else host.removePrefix("www.")
    }

    private fun tabTitle(t: BrowserTab): String {
        if (t.title.isNotEmpty()) return t.title
        if (t.url.isNotEmpty()) return hostOf(t.url)
        return if (t.incognito) "Incognito" else "Nova Browser"
    }

    @Suppress("DEPRECATION")
    private fun styleWindow() {
        window.setBackgroundDrawable(ColorDrawable(C_BG))
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_TOOLBAR
    }

    // ------------------------------------------------------------------
    // Interface
    // ------------------------------------------------------------------

    private fun buildInterface() {
        rootFrame = FrameLayout(this)
        rootFrame.setBackgroundColor(C_BG)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.isFocusableInTouchMode = true
        rootFrame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))

        // --- tab strip row ---
        tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.gravity = Gravity.BOTTOM
        tabRow.setBackgroundColor(C_STRIP)

        tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.overScrollMode = View.OVER_SCROLL_NEVER
        tabStrip = LinearLayout(this)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.BOTTOM
        tabScroll.addView(tabStrip, FrameLayout.LayoutParams(WRAP, MATCH))
        tabRow.addView(tabScroll, LinearLayout.LayoutParams(0, dp(46), 1f))

        tabCountTop = makeCountBadge()
        val topBadgeLp = LinearLayout.LayoutParams(dp(26), dp(26))
        topBadgeLp.setMargins(dp(8), 0, dp(8), dp(10))
        tabRow.addView(tabCountTop, topBadgeLp)
        tabRow.addView(iconButton(R.drawable.ic_more, 44, 22, C_TEXT) { showMenu() })
        root.addView(tabRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- toolbar ---
        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setPadding(dp(4), dp(6), dp(4), dp(8))
        toolbar.setBackgroundColor(C_TOOLBAR)
        toolbar.addView(iconButton(R.drawable.ic_home, 44, 24, C_TEXT) { goHome() })

        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = roundRect(C_PILL, 24)

        lockIcon = ImageView(this)
        lockIcon.setImageResource(R.drawable.ic_lock)
        lockIcon.setColorFilter(C_TEXT)
        lockIcon.setPadding(dp(14), 0, dp(6), 0)
        pill.addView(lockIcon, LinearLayout.LayoutParams(dp(40), dp(20)))

        address = EditText(this)
        address.background = null
        address.hint = "Search or type URL"
        address.setHintTextColor(C_MUTED)
        address.setTextColor(C_TEXT)
        address.textSize = 16f
        address.setSingleLine(true)
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.setSelectAllOnFocus(true)
        address.setPadding(0, 0, 0, 0)
        address.textDirection = View.TEXT_DIRECTION_LTR
        address.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                val raw = address.text.toString()
                hideKeyboard()
                navigateInput(raw)
                true
            } else {
                false
            }
        }
        address.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) refreshToolbar()
        }
        pill.addView(address, LinearLayout.LayoutParams(0, MATCH, 1f))

        starIcon = iconButton(R.drawable.ic_star_border, 44, 22, C_TEXT) { toggleBookmark() }
        pill.addView(starIcon)

        val pillLp = LinearLayout.LayoutParams(0, dp(44), 1f)
        pillLp.setMargins(dp(4), 0, dp(4), 0)
        toolbar.addView(pill, pillLp)
        toolbar.addView(iconButton(R.drawable.ic_more, 44, 22, C_TEXT) { showMenu() })
        root.addView(toolbar, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- progress line ---
        val track = FrameLayout(this)
        track.setBackgroundColor(C_TOOLBAR)
        progressBar = View(this)
        progressBar.setBackgroundColor(C_ACCENT)
        progressBar.visibility = View.GONE
        track.addView(progressBar, FrameLayout.LayoutParams(0, dp(2)))
        root.addView(track, LinearLayout.LayoutParams(MATCH, dp(2)))

        // --- content ---
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // --- bottom bar ---
        val divider = View(this)
        divider.setBackgroundColor(C_DIVIDER)
        root.addView(divider, LinearLayout.LayoutParams(MATCH, dp(1)))

        bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.gravity = Gravity.CENTER
        bottomBar.setBackgroundColor(C_TOOLBAR)

        btnBack = iconButton(R.drawable.ic_back, 52, 24, C_TEXT) { goBack() }
        btnForward = iconButton(R.drawable.ic_forward, 52, 24, C_TEXT) { goForward() }
        val homeBtn = iconButton(R.drawable.ic_home, 52, 24, C_TEXT) { goHome() }
        val menuBtn = iconButton(R.drawable.ic_menu, 52, 24, C_TEXT) { showMenu() }

        tabCountBottom = makeCountBadge()
        val badgeHolder = FrameLayout(this)
        badgeHolder.addView(tabCountBottom, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        badgeHolder.setOnClickListener { showTabSwitcher() }

        bottomBar.addView(btnBack, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(btnForward, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(homeBtn, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(badgeHolder, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(menuBtn, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(bottomBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- fullscreen video holder ---
        fullscreenHolder = FrameLayout(this)
        fullscreenHolder.setBackgroundColor(Color.BLACK)
        fullscreenHolder.visibility = View.GONE
        rootFrame.addView(fullscreenHolder, FrameLayout.LayoutParams(MATCH, MATCH))

        // Android 15+ draws edge-to-edge, so pad the bars by the system insets.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { _, insets ->
                val types = WindowInsets.Type.systemBars() or
                    WindowInsets.Type.displayCutout() or
                    WindowInsets.Type.ime()
                val b = insets.getInsets(types)
                tabRow.setPadding(b.left, b.top, b.right, 0)
                bottomBar.setPadding(b.left, 0, b.right, b.bottom)
                WindowInsets.CONSUMED
            }
        }

        setContentView(rootFrame)
        root.requestFocus()
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private fun restoreTabs() {
        val saved = prefs.tabs()
        if (saved.isEmpty()) {
            tabs.add(BrowserTab(false))
            currentIndex = 0
        } else {
            for (u in saved) {
                val t = BrowserTab(false)
                t.url = u
                tabs.add(t)
            }
            currentIndex = prefs.currentTab().coerceIn(0, tabs.size - 1)
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val data = i.data ?: return
        val scheme = data.scheme
        if (scheme != "http" && scheme != "https") return
        if (tabs.size >= MAX_TABS) return
        val t = BrowserTab(false)
        t.url = data.toString()
        tabs.add(t)
        currentIndex = tabs.size - 1
    }

    private fun saveTabs() {
        if (tabs.isEmpty()) return
        val urls = ArrayList<String>()
        var cur = 0
        for (i in tabs.indices) {
            val t = tabs[i]
            if (t.incognito) continue
            if (i == currentIndex) cur = urls.size
            urls.add(t.url)
        }
        prefs.saveTabs(urls, cur)
    }

    private fun newTab(incognito: Boolean) {
        if (tabs.size >= MAX_TABS) {
            toast("Too many tabs")
            return
        }
        tabs.add(BrowserTab(incognito))
        currentIndex = tabs.size - 1
        showCurrent()
        saveTabs()
    }

    private fun selectTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        currentIndex = index
        showCurrent()
        saveTabs()
    }

    private fun destroyWebView(t: BrowserTab) {
        val wv = t.webView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.stopLoading()
        wv.destroy()
        t.webView = null
    }

    private fun closeTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        destroyWebView(tabs[index])
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            tabs.add(BrowserTab(false))
            currentIndex = 0
        } else if (index < currentIndex) {
            currentIndex -= 1
        } else if (currentIndex >= tabs.size) {
            currentIndex = tabs.size - 1
        }
        showCurrent()
        saveTabs()
    }

    private fun showCurrent() {
        for (i in 0 until content.childCount) {
            val c = content.getChildAt(i)
            if (c is WebView) c.onPause()
        }
        content.removeAllViews()
        if (address.hasFocus()) root.requestFocus()
        updateProgress(100)

        val t = current()
        if (t.webView == null && t.url.isNotEmpty()) {
            val created = createWebView(t)
            created.loadUrl(t.url)
        }
        val wv = t.webView
        if (wv != null) {
            wv.onResume()
            content.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            content.addView(buildHome(t.incognito), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        refreshAll()
    }

    private fun refreshAll() {
        refreshTabStrip()
        refreshToolbar()
        refreshNav()
    }

    private fun refreshTabStrip() {
        tabStrip.removeAllViews()
        var selectedChip: View? = null
        for (i in tabs.indices) {
            val t = tabs[i]
            val selected = i == currentIndex
            val chip = LinearLayout(this)
            chip.orientation = LinearLayout.HORIZONTAL
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(10), 0, dp(4), 0)
            if (selected) {
                val r = dp(12).toFloat()
                val bg = GradientDrawable()
                bg.setColor(if (t.incognito) C_TOOLBAR_INCOGNITO else C_TOOLBAR)
                bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                chip.background = bg
                selectedChip = chip
            }

            val fav = ImageView(this)
            fav.setImageResource(if (t.incognito) R.drawable.ic_incognito else R.drawable.ic_globe)
            fav.setColorFilter(if (t.incognito) C_INCOGNITO else C_ACCENT_LIGHT)
            chip.addView(fav, LinearLayout.LayoutParams(dp(20), dp(20)))

            val title = TextView(this)
            title.text = tabTitle(t)
            title.setTextColor(if (selected) C_TEXT else C_MUTED)
            title.textSize = 14f
            title.setSingleLine(true)
            title.ellipsize = TextUtils.TruncateAt.END
            title.setPadding(dp(8), 0, dp(4), 0)
            chip.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

            val close = ImageView(this)
            close.setImageResource(R.drawable.ic_close)
            close.setColorFilter(C_TEXT)
            close.setPadding(dp(6), dp(6), dp(6), dp(6))
            close.setOnClickListener { closeTab(tabs.indexOf(t)) }
            chip.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))

            chip.setOnClickListener { selectTab(tabs.indexOf(t)) }
            val width = if (tabs.size == 1) dp(190) else dp(140)
            tabStrip.addView(chip, LinearLayout.LayoutParams(width, dp(40)))
        }
        val plusLp = LinearLayout.LayoutParams(dp(40), dp(40))
        tabStrip.addView(iconButton(R.drawable.ic_add, 40, 22, C_TEXT) { newTab(false) }, plusLp)

        val sel = selectedChip
        if (sel != null) {
            tabScroll.post { tabScroll.smoothScrollTo(maxOf(0, sel.left - dp(16)), 0) }
        }
    }

    private fun refreshToolbar() {
        val t = current()
        toolbar.setBackgroundColor(if (t.incognito) C_TOOLBAR_INCOGNITO else C_TOOLBAR)
        if (!address.hasFocus()) address.setText(t.url)
        val secure = t.url.isEmpty() || t.url.startsWith("https://")
        lockIcon.setColorFilter(if (secure) C_TEXT else C_WARN)
        val marked = t.url.isNotEmpty() && prefs.isBookmarked(t.url)
        starIcon.setImageResource(if (marked) R.drawable.ic_star else R.drawable.ic_star_border)
        starIcon.setColorFilter(if (marked) C_STAR else C_TEXT)
        val n = tabs.size.toString()
        tabCountTop.text = n
        tabCountBottom.text = n
    }

    private fun refreshNav() {
        val wv = current().webView
        btnBack.alpha = if (wv != null) 1f else 0.35f
        btnForward.alpha = if (wv != null && wv.canGoForward()) 1f else 0.35f
    }

    private fun updateProgress(p: Int) {
        if (p in 1..99) {
            val lp = progressBar.layoutParams
            lp.width = rootFrame.width * p / 100
            progressBar.layoutParams = lp
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------
    // Navigation
    // ------------------------------------------------------------------

    private fun resolveInput(raw: String): String? {
        val v = raw.trim()
        if (v.isEmpty()) return null
        val lower = v.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) return v
        if (!v.contains(" ") && v.contains(".") && !v.contains("://") && !lower.startsWith("javascript:")) {
            return "https://" + v
        }
        val index = prefs.searchEngine().coerceIn(0, engines.size - 1)
        return engines[index].second + Uri.encode(v)
    }

    private fun navigateInput(raw: String) {
        val target = resolveInput(raw) ?: return
        navigate(target)
    }

    private fun navigate(url: String) {
        val t = current()
        t.url = url
        val wv = t.webView ?: createWebView(t)
        wv.loadUrl(url)
        showCurrent()
    }

    private fun goBack() {
        val wv = current().webView ?: return
        if (wv.canGoBack()) wv.goBack() else goHome()
    }

    private fun goForward() {
        val wv = current().webView ?: return
        if (wv.canGoForward()) wv.goForward()
    }

    private fun reload() {
        current().webView?.reload()
    }

    private fun goHome() {
        val t = current()
        destroyWebView(t)
        t.url = ""
        t.title = ""
        showCurrent()
        saveTabs()
    }

    private fun toggleBookmark() {
        val url = current().url
        if (url.isEmpty()) {
            toast("Open a page first")
            return
        }
        if (prefs.isBookmarked(url)) {
            prefs.removeBookmark(url)
            toast("Bookmark removed")
        } else {
            prefs.addBookmark(url)
            toast("Bookmark added")
        }
        refreshToolbar()
    }

    private fun focusAddress() {
        address.requestFocus()
        address.selectAll()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(address, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(address.windowToken, 0)
        root.requestFocus()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: ActivityNotFoundException) {
            toast("Voice search isn't available on this device")
        }
    }

    // ------------------------------------------------------------------
    // WebView
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        val wv = WebView(this)
        tab.webView = wv

        val s = wv.settings
        s.javaScriptEnabled = prefs.javascriptEnabled()
        s.domStorageEnabled = true
        s.loadsImagesAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.textZoom = tab.zoom
        if (tab.incognito) {
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.saveFormData = false
        }
        if (tab.desktop) s.userAgentString = DESKTOP_UA

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !prefs.blockThirdPartyCookies())

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme
                if (scheme == "http" || scheme == "https" || scheme == "about" ||
                    scheme == "data" || scheme == "blob"
                ) {
                    return false
                }
                val external = scheme == "tel" || scheme == "mailto" || scheme == "sms" ||
                    scheme == "geo" || scheme == "market"
                if (external) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: Exception) {
                        toast("No app can open this link")
                    }
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null) return
                tab.url = url
                if (isCurrent(tab)) {
                    refreshToolbar()
                    refreshNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == null) return
                tab.url = url
                if (!tab.incognito && (url.startsWith("http://") || url.startsWith("https://"))) {
                    prefs.addHistory(url)
                }
                saveTabs()
                if (isCurrent(tab)) {
                    refreshToolbar()
                    refreshNav()
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (view == null || request == null || !request.isForMainFrame) return
                val reason = if (error != null) error.description.toString() else "Unknown error"
                showErrorPage(view, request.url.toString(), reason)
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                if (view != null) {
                    val failing = if (error != null) error.url else ""
                    showErrorPage(view, failing ?: "", "This site's security certificate isn't trusted.")
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (isCurrent(tab)) updateProgress(newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: ""
                refreshTabStrip()
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                showCustomView(view, callback)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                val previous = fileCallback
                if (previous != null) previous.onReceiveValue(emptyArray<Uri>())
                fileCallback = filePathCallback
                return try {
                    val intent = if (fileChooserParams != null) {
                        fileChooserParams.createIntent()
                    } else {
                        val fallback = Intent(Intent.ACTION_GET_CONTENT)
                        fallback.type = "*/*"
                        fallback.addCategory(Intent.CATEGORY_OPENABLE)
                        fallback
                    }
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(PendingDownload(url, userAgent, contentDisposition, mimeType))
        }
        return wv
    }

    private fun showErrorPage(view: WebView, failingUrl: String, reason: String) {
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
            "<body style='background:#0B0D26;color:#E8EAFF;font-family:sans-serif;text-align:center;padding:56px 24px'>" +
            "<h2>Can’t open this page</h2>" +
            "<p style='color:#9AA0D0'>" + TextUtils.htmlEncode(reason) + "</p>" +
            "<p style='color:#9AA0D0;word-break:break-all;font-size:13px'>" + TextUtils.htmlEncode(failingUrl) + "</p>" +
            "</body></html>"
        view.loadDataWithBaseURL(failingUrl, html, "text/html", "UTF-8", failingUrl)
    }

    private fun showCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
        if (view == null) return
        if (customView != null) {
            callback?.onCustomViewHidden()
            return
        }
        customView = view
        customCallback = callback
        fullscreenHolder.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        fullscreenHolder.visibility = View.VISIBLE
        applyImmersive(true)
    }

    private fun hideCustomView() {
        val v = customView ?: return
        fullscreenHolder.removeView(v)
        fullscreenHolder.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        applyImmersive(false)
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive(on: Boolean) {
        val flags = if (on) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
        window.decorView.systemUiVisibility = flags
    }

    // ------------------------------------------------------------------
    // Downloads / activity results
    // ------------------------------------------------------------------

    private fun startDownload(d: PendingDownload) {
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = d
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        try {
            val name = URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)
            val req = DownloadManager.Request(Uri.parse(d.url))
            if (!d.mimeType.isNullOrEmpty()) req.setMimeType(d.mimeType)
            if (!d.userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", d.userAgent)
            val cookie = CookieManager.getInstance().getCookie(d.url)
            if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            toast("Download started")
        } catch (e: Exception) {
            toast("Can't download this file")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE) {
            val d = pendingDownload
            pendingDownload = null
            if (d != null && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDownload(d)
            } else {
                toast("Storage permission is needed to download files")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val cb = fileCallback
            fileCallback = null
            if (cb != null) {
                val r = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                if (r != null) cb.onReceiveValue(r) else cb.onReceiveValue(emptyArray<Uri>())
            }
        } else if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            val list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (list != null && list.isNotEmpty()) navigateInput(list[0])
        }
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            toast("Can't open Downloads")
        }
    }

    // ------------------------------------------------------------------
    // Home page
    // ------------------------------------------------------------------

    private fun buildHome(incognito: Boolean): View {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(if (incognito) Color.parseColor("#120B26") else C_BG)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(28), dp(20), dp(24))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        col.addView(LogoView(this), LinearLayout.LayoutParams(dp(150), dp(120)))

        val title = TextView(this)
        title.text = if (incognito) "Incognito" else "Nova Browser"
        title.textSize = 34f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(if (incognito) C_INCOGNITO else C_TITLE)
        title.gravity = Gravity.CENTER
        col.addView(title, LinearLayout.LayoutParams(WRAP, WRAP))

        val tag = TextView(this)
        tag.textSize = 17f
        tag.gravity = Gravity.CENTER
        if (incognito) {
            tag.text = "Pages you view here aren't saved to history"
            tag.setTextColor(C_MUTED)
            tag.textSize = 14f
        } else {
            val sb = SpannableStringBuilder()
            fun part(text: String, color: Int) {
                val start = sb.length
                sb.append(text)
                sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            part("Fast", C_TAG1)
            part("  •  ", C_MUTED)
            part("Secure", C_TAG2)
            part("  •  ", C_MUTED)
            part("Powerful", C_TAG3)
            tag.text = sb
        }
        col.addView(tag, LinearLayout.LayoutParams(WRAP, WRAP))

        // search pill
        val engineIndex = prefs.searchEngine().coerceIn(0, engines.size - 1)
        val search = LinearLayout(this)
        search.orientation = LinearLayout.HORIZONTAL
        search.gravity = Gravity.CENTER_VERTICAL
        search.background = roundRect(C_PILL, 26, C_PILL_STROKE, 1)
        search.setPadding(dp(18), 0, dp(8), 0)

        val g = TextView(this)
        g.text = engines[engineIndex].first.substring(0, 1)
        g.textSize = 22f
        g.typeface = Typeface.DEFAULT_BOLD
        g.setTextColor(engineColors[engineIndex])
        search.addView(g, LinearLayout.LayoutParams(WRAP, WRAP))

        val hint = TextView(this)
        hint.text = "Search with " + engines[engineIndex].first
        hint.textSize = 17f
        hint.setTextColor(C_MUTED)
        hint.setPadding(dp(14), 0, 0, 0)
        search.addView(hint, LinearLayout.LayoutParams(0, WRAP, 1f))

        val mic = ImageView(this)
        mic.setImageResource(R.drawable.ic_mic)
        mic.setColorFilter(C_MUTED)
        mic.setPadding(dp(10), dp(10), dp(10), dp(10))
        mic.setOnClickListener { startVoice() }
        search.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        search.setOnClickListener { focusAddress() }

        val searchLp = LinearLayout.LayoutParams(MATCH, dp(52))
        searchLp.topMargin = dp(26)
        col.addView(search, searchLp)

        if (incognito) return scroll

        // shortcuts
        val tiles = ArrayList<View>()
        val defs = listOf(
            ShortcutDef("Google", "https://www.google.com", "G", roundRect(Color.WHITE, 16), Color.parseColor("#4285F4")),
            ShortcutDef("YouTube", "https://m.youtube.com", "YT", roundRect(Color.parseColor("#EDE7FF"), 16), Color.parseColor("#FF0000")),
            ShortcutDef("Wikipedia", "https://www.wikipedia.org", "W", roundRect(Color.WHITE, 16), Color.BLACK),
            ShortcutDef("Telegram", "https://web.telegram.org", "T", roundRect(Color.parseColor("#229ED9"), 16), Color.WHITE),
            ShortcutDef("GitHub", "https://github.com", "GH", roundRect(Color.parseColor("#0D1117"), 16), Color.WHITE),
            ShortcutDef("Amazon", "https://www.amazon.com", "a", roundRect(Color.WHITE, 16), Color.BLACK),
            ShortcutDef("Instagram", "https://www.instagram.com", "IG", instagramBg(), Color.WHITE)
        )
        for (d in defs) {
            val url = d.url
            tiles.add(makeTile(d.label, d.glyph, d.bg, d.fg, 0) { navigate(url) })
        }
        for (u in prefs.shortcuts()) {
            val host = hostOf(u)
            val cell = makeTile(host, host.substring(0, 1).uppercase(), roundRect(C_PILL, 16), C_TEXT, 0) { navigate(u) }
            cell.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(host)
                    .setMessage("Remove this shortcut?")
                    .setPositiveButton("Remove") { _, _ ->
                        prefs.removeShortcut(u)
                        if (current().webView == null) showCurrent()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
            tiles.add(cell)
        }
        tiles.add(makeTile("Add", "", roundRect(C_PILL, 16), C_TEXT, R.drawable.ic_add) { showAddShortcutDialog() })

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        var start = 0
        while (start < tiles.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val idx = start + k
                val cellView: View = if (idx < tiles.size) tiles[idx] else View(this)
                row.addView(cellView, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            start += 4
        }
        val gridLp = LinearLayout.LayoutParams(MATCH, WRAP)
        gridLp.topMargin = dp(18)
        col.addView(grid, gridLp)

        // news card
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = roundRect(C_PILL, 16, C_PILL_STROKE, 1)

        val earth = GradientDrawable()
        earth.gradientType = GradientDrawable.RADIAL_GRADIENT
        earth.gradientRadius = dp(70).toFloat()
        earth.colors = intArrayOf(Color.parseColor("#3FA9FF"), Color.parseColor("#1C4FB5"), Color.parseColor("#0A1640"))
        val er = dp(16).toFloat()
        earth.cornerRadii = floatArrayOf(er, er, 0f, 0f, 0f, 0f, er, er)
        val earthView = View(this)
        earthView.background = earth
        card.addView(earthView, LinearLayout.LayoutParams(dp(96), dp(80)))

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(16), 0, dp(8), 0)
        val newsTitle = TextView(this)
        newsTitle.text = "Today's top stories"
        newsTitle.textSize = 17f
        newsTitle.setTextColor(C_TEXT)
        newsTitle.setSingleLine(true)
        newsTitle.ellipsize = TextUtils.TruncateAt.END
        texts.addView(newsTitle)
        val newsSub = TextView(this)
        newsSub.text = "News  •  Tap to open"
        newsSub.textSize = 13f
        newsSub.setTextColor(C_MUTED)
        texts.addView(newsSub)
        card.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

        val chev = ImageView(this)
        chev.setImageResource(R.drawable.ic_chevron)
        chev.setColorFilter(C_MUTED)
        card.addView(chev, LinearLayout.LayoutParams(dp(32), dp(32)))
        card.setOnClickListener { navigate("https://news.google.com") }

        val cardLp = LinearLayout.LayoutParams(MATCH, dp(80))
        cardLp.topMargin = dp(14)
        col.addView(card, cardLp)

        return scroll
    }

    private fun instagramBg(): Drawable {
        val d = GradientDrawable(
            GradientDrawable.Orientation.BL_TR,
            intArrayOf(Color.parseColor("#FEDA75"), Color.parseColor("#FA7E1E"), Color.parseColor("#D62976"), Color.parseColor("#4F5BD5"))
        )
        d.cornerRadius = dp(16).toFloat()
        return d
    }

    private fun makeTile(label: String, glyph: String, bg: Drawable, fg: Int, icon: Int, onClick: () -> Unit): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(0, dp(8), 0, dp(8))

        val box = FrameLayout(this)
        box.background = bg
        if (icon != 0) {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(fg)
            iv.setPadding(dp(18), dp(18), dp(18), dp(18))
            box.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            val tv = TextView(this)
            tv.text = glyph
            tv.textSize = if (glyph.length > 1) 20f else 28f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(fg)
            tv.gravity = Gravity.CENTER
            box.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        cell.addView(box, LinearLayout.LayoutParams(dp(60), dp(60)))

        val lb = TextView(this)
        lb.text = label
        lb.textSize = 12f
        lb.setTextColor(C_TEXT)
        lb.setSingleLine(true)
        lb.ellipsize = TextUtils.TruncateAt.END
        lb.gravity = Gravity.CENTER
        lb.setPadding(dp(2), dp(6), dp(2), 0)
        cell.addView(lb, LinearLayout.LayoutParams(MATCH, WRAP))

        cell.setOnClickListener { onClick() }
        return cell
    }

    private fun showAddShortcutDialog() {
        val input = EditText(this)
        input.hint = "example.com"
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val holder = FrameLayout(this)
        holder.setPadding(dp(20), dp(8), dp(20), 0)
        holder.addView(input, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("Add shortcut")
            .setView(holder)
            .setPositiveButton("Add") { _, _ ->
                val raw = input.text.toString().trim()
                if (raw.isNotEmpty()) {
                    val full = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://" + raw
                    prefs.addShortcut(full)
                    if (current().webView == null) showCurrent()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------
    // Menu
    // ------------------------------------------------------------------

    private fun showMenu() {
        menuPopup?.dismiss()
        val screenW = resources.displayMetrics.widthPixels
        val width = minOf(dp(300), screenW - dp(24))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(0, dp(8), 0, dp(8))

        fun dismissMenu() {
            menuPopup?.dismiss()
        }

        fun newRow(icon: Int, label: String): LinearLayout {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), 0, dp(16), 0)
            row.background = rippleBg(false)
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(C_TEXT)
            row.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 16f
            tv.setTextColor(C_TEXT)
            tv.setSingleLine(true)
            tv.setPadding(dp(16), 0, dp(8), 0)
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            card.addView(row, LinearLayout.LayoutParams(MATCH, dp(46)))
            return row
        }

        fun addItem(icon: Int, label: String, hint: String?, action: () -> Unit) {
            val row = newRow(icon, label)
            if (hint != null) {
                val h = TextView(this)
                h.text = hint
                h.textSize = 14f
                h.setTextColor(C_MUTED)
                row.addView(h, LinearLayout.LayoutParams(WRAP, WRAP))
            }
            row.setOnClickListener {
                dismissMenu()
                action()
            }
        }

        fun addDivider() {
            val d = View(this)
            d.setBackgroundColor(C_DIVIDER)
            val lp = LinearLayout.LayoutParams(MATCH, dp(1))
            lp.setMargins(dp(16), dp(4), dp(16), dp(4))
            card.addView(d, lp)
        }

        addItem(R.drawable.ic_add_box, "New Tab", "Ctrl+T") { newTab(false) }
        addItem(R.drawable.ic_incognito, "New Incognito Tab", null) { newTab(true) }
        addDivider()
        addItem(R.drawable.ic_star_border, "Bookmarks", "Ctrl+B") { showBookmarks() }
        addItem(R.drawable.ic_history, "History", "Ctrl+H") { showHistory() }
        addItem(R.drawable.ic_download, "Downloads", "Ctrl+J") { openDownloads() }
        addItem(R.drawable.ic_refresh, "Reload", "Ctrl+R") { reload() }
        addItem(R.drawable.ic_delete, "Clear Browsing Data", null) { confirmClearData() }
        addDivider()
        addItem(R.drawable.ic_settings, "Settings", null) { showSettings() }
        addItem(R.drawable.ic_shield, "Privacy & Security", null) { showPrivacy() }
        addItem(R.drawable.ic_translate, "Translate...", null) { translatePage() }

        val deskRow = newRow(R.drawable.ic_desktop, "Desktop Site")
        val deskCheck = CheckBox(this)
        deskCheck.isChecked = current().desktop
        deskCheck.isClickable = false
        deskCheck.isFocusable = false
        deskCheck.buttonTintList = ColorStateList.valueOf(C_TEXT)
        deskRow.addView(deskCheck, LinearLayout.LayoutParams(WRAP, WRAP))
        deskRow.setOnClickListener {
            dismissMenu()
            toggleDesktop()
        }

        val zoomRow = newRow(R.drawable.ic_search, "Zoom")
        val minus = ImageView(this)
        minus.setImageResource(R.drawable.ic_remove)
        minus.setColorFilter(C_TEXT)
        minus.setPadding(dp(6), dp(6), dp(6), dp(6))
        val pct = TextView(this)
        pct.text = current().zoom.toString() + "%"
        pct.textSize = 16f
        pct.setTextColor(C_TEXT)
        pct.gravity = Gravity.CENTER
        val plus = ImageView(this)
        plus.setImageResource(R.drawable.ic_add)
        plus.setColorFilter(C_TEXT)
        plus.setPadding(dp(6), dp(6), dp(6), dp(6))
        minus.setOnClickListener {
            changeZoom(-10)
            pct.text = current().zoom.toString() + "%"
        }
        plus.setOnClickListener {
            changeZoom(10)
            pct.text = current().zoom.toString() + "%"
        }
        zoomRow.addView(minus, LinearLayout.LayoutParams(dp(36), dp(36)))
        zoomRow.addView(pct, LinearLayout.LayoutParams(dp(56), WRAP))
        zoomRow.addView(plus, LinearLayout.LayoutParams(dp(36), dp(36)))

        addDivider()
        addItem(R.drawable.ic_info, "About Nova Browser", null) { showAbout() }
        addItem(R.drawable.ic_exit, "Exit", null) { finishAffinity() }

        val scroll = ScrollView(this)
        scroll.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        scroll.background = roundRect(C_MENU, 18, C_MENU_STROKE, 1)

        card.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxH = resources.displayMetrics.heightPixels - dp(120)
        val height = minOf(card.measuredHeight, maxH)

        val popup = PopupWindow(scroll, width, height, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(10).toFloat()
        popup.isOutsideTouchable = true
        menuPopup = popup
        popup.showAtLocation(rootFrame, Gravity.TOP or Gravity.END, dp(8), tabRow.paddingTop + dp(46))
    }

    private fun changeZoom(delta: Int) {
        val t = current()
        t.zoom = (t.zoom + delta).coerceIn(50, 300)
        val wv = t.webView
        if (wv != null) wv.settings.textZoom = t.zoom
    }

    private fun toggleDesktop() {
        val t = current()
        t.desktop = !t.desktop
        val wv = t.webView
        if (wv != null) {
            if (t.desktop) {
                wv.settings.userAgentString = DESKTOP_UA
            } else {
                wv.settings.userAgentString = WebSettings.getDefaultUserAgent(this)
            }
            wv.reload()
        }
    }

    private fun translatePage() {
        val url = current().url
        if (url.isEmpty()) {
            toast("Open a page first")
            return
        }
        val lang = java.util.Locale.getDefault().language
        navigate("https://translate.google.com/translate?sl=auto&tl=" + lang + "&u=" + Uri.encode(url))
    }

    // ------------------------------------------------------------------
    // Dialogs
    // ------------------------------------------------------------------

    private fun showUrlList(title: String, urls: List<String>, emptyText: String, clearLabel: String, onClear: () -> Unit) {
        val b = AlertDialog.Builder(this)
        b.setTitle(title)
        if (urls.isEmpty()) {
            b.setMessage(emptyText)
        } else {
            val items = urls.map { it as CharSequence }.toTypedArray()
            b.setItems(items) { _, which -> navigate(urls[which]) }
            b.setNeutralButton(clearLabel) { _, _ -> onClear() }
        }
        b.setPositiveButton("Close", null)
        b.show()
    }

    private fun showBookmarks() {
        showUrlList("Bookmarks", prefs.bookmarks(), "No bookmarks yet. Tap the star in the address bar to add one.", "Clear all") {
            prefs.clearBookmarks()
            refreshToolbar()
        }
    }

    private fun showHistory() {
        showUrlList("History", prefs.history(), "No history yet.", "Clear all") {
            prefs.clearHistory()
        }
    }

    private fun confirmClearData() {
        AlertDialog.Builder(this)
            .setTitle("Clear Browsing Data")
            .setMessage("This clears history, cookies, cache and saved site data.")
            .setPositiveButton("Clear") { _, _ -> clearBrowsingData() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearBrowsingData() {
        prefs.clearHistory()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        for (t in tabs) {
            val wv = t.webView
            if (wv != null) {
                wv.clearCache(true)
                wv.clearFormData()
            }
        }
        toast("Browsing data cleared")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(8))

        val engineTitle = TextView(this)
        engineTitle.text = "Search engine"
        engineTitle.textSize = 14f
        engineTitle.setTextColor(C_ACCENT_LIGHT)
        engineTitle.setPadding(0, dp(8), 0, dp(4))
        box.addView(engineTitle)

        val group = RadioGroup(this)
        for (i in engines.indices) {
            val rb = RadioButton(this)
            rb.text = engines[i].first
            rb.isChecked = i == prefs.searchEngine()
            rb.setOnClickListener {
                prefs.setSearchEngine(i)
                if (current().webView == null) showCurrent()
            }
            group.addView(rb)
        }
        box.addView(group)

        val js = Switch(this)
        js.text = "JavaScript"
        js.isChecked = prefs.javascriptEnabled()
        js.setOnCheckedChangeListener { _, on ->
            prefs.setJavascriptEnabled(on)
            for (t in tabs) {
                val wv = t.webView
                if (wv != null) wv.settings.javaScriptEnabled = on
            }
        }
        box.addView(js, LinearLayout.LayoutParams(MATCH, dp(48)))

        val cookies = Switch(this)
        cookies.text = "Block third-party cookies"
        cookies.isChecked = prefs.blockThirdPartyCookies()
        cookies.setOnCheckedChangeListener { _, on ->
            prefs.setBlockThirdPartyCookies(on)
            for (t in tabs) {
                val wv = t.webView
                if (wv != null) CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !on)
            }
        }
        box.addView(cookies, LinearLayout.LayoutParams(MATCH, dp(48)))

        val scroll = ScrollView(this)
        scroll.addView(box, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(scroll)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showPrivacy() {
        val message = "Protections in this version:\n\n" +
            "• Mixed (http inside https) content is blocked\n" +
            "• Local file and content access is disabled\n" +
            "• Third-party cookies are blocked by default\n" +
            "• Plain http:// sites are blocked (HTTPS only)\n" +
            "• Incognito tabs don't save history or cache\n\n" +
            "Note: incognito tabs share cookies with normal tabs in this version."
        AlertDialog.Builder(this)
            .setTitle("Privacy & Security")
            .setMessage(message)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear data") { _, _ -> confirmClearData() }
            .show()
    }

    private fun showAbout() {
        var version = "0.2.0"
        try {
            val name = packageManager.getPackageInfo(packageName, 0).versionName
            if (name != null) version = name
        } catch (e: Exception) {
            // keep default
        }
        var engine = "Android System WebView"
        if (Build.VERSION.SDK_INT >= 26) {
            val pkg = WebView.getCurrentWebViewPackage()
            if (pkg != null) engine += " " + pkg.versionName
        }
        AlertDialog.Builder(this)
            .setTitle("Nova Browser")
            .setMessage("Version " + version + "\nEngine: " + engine + " (Chromium)\n\nFast • Secure • Powerful")
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showTabSwitcher() {
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Tabs")
            .setView(scroll)
            .setPositiveButton("New tab") { _, _ -> newTab(false) }
            .setNeutralButton("Incognito") { _, _ -> newTab(true) }
            .setNegativeButton("Close", null)
            .create()

        fun fill() {
            list.removeAllViews()
            for (i in tabs.indices) {
                val t = tabs[i]
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(8), dp(8), dp(8))
                if (i == currentIndex) row.setBackgroundColor(Color.parseColor("#22FFFFFF"))

                val icon = ImageView(this)
                icon.setImageResource(if (t.incognito) R.drawable.ic_incognito else R.drawable.ic_globe)
                icon.setColorFilter(if (t.incognito) C_INCOGNITO else C_ACCENT_LIGHT)
                row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))

                val texts = LinearLayout(this)
                texts.orientation = LinearLayout.VERTICAL
                texts.setPadding(dp(12), 0, dp(8), 0)
                val tt = TextView(this)
                tt.text = tabTitle(t)
                tt.textSize = 15f
                tt.setTextColor(Color.WHITE)
                tt.setSingleLine(true)
                tt.ellipsize = TextUtils.TruncateAt.END
                texts.addView(tt)
                val tu = TextView(this)
                tu.text = if (t.url.isEmpty()) "New tab" else t.url
                tu.textSize = 12f
                tu.setTextColor(Color.parseColor("#AAAAAA"))
                tu.setSingleLine(true)
                tu.ellipsize = TextUtils.TruncateAt.END
                texts.addView(tu)
                row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

                val close = ImageView(this)
                close.setImageResource(R.drawable.ic_close)
                close.setColorFilter(Color.WHITE)
                close.setPadding(dp(8), dp(8), dp(8), dp(8))
                close.setOnClickListener {
                    closeTab(tabs.indexOf(t))
                    fill()
                }
                row.addView(close, LinearLayout.LayoutParams(dp(40), dp(40)))

                row.setOnClickListener {
                    dialog.dismiss()
                    selectTab(tabs.indexOf(t))
                }
                list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }

        fill()
        dialog.show()
    }
}
