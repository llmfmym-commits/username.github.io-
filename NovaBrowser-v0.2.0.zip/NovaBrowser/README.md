# Nova Browser — نسخه 0.2.0

مرورگر اندروید (Kotlin + Java) با ظاهر تیره‌ی Nova، مبتنی بر Android System WebView (Chromium).

## تغییرات نسخه 0.2.0
- رابط جدید مطابق طرح: نوار تب‌ها، نوار آدرس با قفل و ستاره، نوار پایین، صفحه‌ی خانه (لوگو، جست‌وجو، میان‌برها، کارت اخبار)
- منوی سه‌نقطه: New Tab / Incognito / Bookmarks / History / Downloads / Clear Browsing Data / Settings / Privacy & Security / Translate / Desktop Site / Zoom / About / Exit
- چند تب واقعی، تب ناشناس (بدون ذخیره‌ی تاریخچه و کش)، ذخیره و بازیابی تب‌ها
- تنظیمات: موتور جست‌وجو (Google / DuckDuckGo / Bing)، JavaScript، کوکی‌های شخص ثالث
- انتخاب فایل (آپلود)، ویدیوی تمام‌صفحه، جست‌وجوی صوتی، صفحه‌ی خطا
- ثبت به‌عنوان مرورگر قابل انتخاب (باز کردن لینک‌های http/https)
- میان‌برهای صفحه‌ی خانه قابل افزودن (دکمه Add) و حذف (نگه داشتن)
- میانبرهای صفحه‌کلید: Ctrl+T / W / L / R / B / H / J
- رفع خطای کامپایل نسخه‌ی قبل (`catch (_: Exception)` در Kotlin 2.0 پشتیبانی نمی‌شود)

## ساخت
پوشه‌ی `NovaBrowser` را با GitHub Actions بسازید (Gradle 8.9+ ، JDK 17، AGP 8.7.3، Kotlin 2.0.21).

## محدودیت‌ها
- تب ناشناس کوکی‌ها را با تب‌های عادی به اشتراک می‌گذارد (جداسازی کامل پروفایل هنوز پیاده نشده).
- فقط HTTPS مجاز است (`usesCleartextTraffic=false`).
