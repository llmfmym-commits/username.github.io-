package com.nova.browser

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast

internal const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
internal const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

internal val C_BG = Color.parseColor("#0B0D26")
internal val C_STRIP = Color.parseColor("#080A1E")
internal val C_TOOLBAR = Color.parseColor("#13163A")
internal val C_TOOLBAR_INCOGNITO = Color.parseColor("#1F1238")
internal val C_PILL = Color.parseColor("#1C1F4A")
internal val C_PILL_STROKE = Color.parseColor("#2E3270")
internal val C_TEXT = Color.parseColor("#E8EAFF")
internal val C_MUTED = Color.parseColor("#9AA0D0")
internal val C_ACCENT = Color.parseColor("#5B6CFF")
internal val C_ACCENT_LIGHT = Color.parseColor("#9FB0FF")
internal val C_DIVIDER = Color.parseColor("#2A2E60")
internal val C_MENU = Color.parseColor("#202346")
internal val C_MENU_STROKE = Color.parseColor("#343974")
internal val C_WARN = Color.parseColor("#FFB74D")
internal val C_STAR = Color.parseColor("#FFD54F")
internal val C_INCOGNITO = Color.parseColor("#C3A6FF")
internal val C_TITLE = Color.parseColor("#C9CEFF")
internal val C_TAG1 = Color.parseColor("#8EA2FF")
internal val C_TAG2 = Color.parseColor("#5CC8FF")
internal val C_TAG3 = Color.parseColor("#A98BFF")
internal val C_DANGER = Color.parseColor("#FF6B7A")

internal val ENGINES = listOf(
    Pair("DuckDuckGo", "https://duckduckgo.com/?q="),
    Pair("Brave Search", "https://search.brave.com/search?q="),
    Pair("Bing", "https://www.bing.com/search?q="),
    Pair("Startpage", "https://www.startpage.com/do/search?q="),
    Pair("Ecosia", "https://www.ecosia.org/search?q=")
)

internal val ENGINE_COLORS = intArrayOf(
    Color.parseColor("#DE5833"),
    Color.parseColor("#FB542B"),
    Color.parseColor("#00897B"),
    Color.parseColor("#6573FF"),
    Color.parseColor("#36ACB5")
)

internal fun faDigits(text: String): String {
    val sb = StringBuilder()
    for (ch in text) {
        if (ch in '0'..'9') sb.append('\u06F0' + (ch - '0')) else sb.append(ch)
    }
    return sb.toString()
}

internal fun hostOf(url: String): String {
    val host = Uri.parse(url).host
    return if (host.isNullOrEmpty()) url else host.removePrefix("www.")
}

internal fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

internal fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

internal fun Context.roundRect(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
    return d
}

internal fun Context.rippleBg(borderless: Boolean): Drawable? {
    val out = TypedValue()
    val attr = if (borderless) android.R.attr.selectableItemBackgroundBorderless
    else android.R.attr.selectableItemBackground
    return if (theme.resolveAttribute(attr, out, true) && out.resourceId != 0) {
        resources.getDrawable(out.resourceId, theme)
    } else {
        null
    }
}

internal fun Context.iconButton(res: Int, sizeDp: Int, iconDp: Int, tint: Int, onClick: (View) -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    val pad = dp((sizeDp - iconDp) / 2)
    v.setPadding(pad, pad, pad, pad)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    v.background = rippleBg(true)
    v.setOnClickListener { onClick(it) }
    return v
}

internal object DataCleaner {
    fun clearCookies() {
        val cm = CookieManager.getInstance()
        cm.removeAllCookies(null)
        cm.flush()
    }

    fun clearSiteData() {
        WebStorage.getInstance().deleteAllData()
    }

    fun clearCache(context: Context) {
        try {
            val wv = WebView(context)
            wv.clearCache(true)
            wv.clearFormData()
            wv.destroy()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun clearAll(context: Context, prefs: BrowserPrefs) {
        prefs.clearHistory()
        clearCookies()
        clearSiteData()
        clearCache(context)
    }
}
