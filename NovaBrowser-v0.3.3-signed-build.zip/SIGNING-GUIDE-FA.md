# راهنمای امضای APK نوا

## ۱) ساخت کلید امضا (فقط یک‌بار)
در Termux یا کامپیوتر دارای JDK، این دستور را اجرا کنید:

```bash
keytool -genkeypair -v -keystore nova-release.jks -alias nova -keyalg RSA -keysize 2048 -validity 10000
```

یک رمز قوی انتخاب کنید و آن را در جای امن نگه دارید. فایل `nova-release.jks` و رمزهایش را گم نکنید؛ برای انتشار نسخه‌های بعدی باید از همین کلید استفاده شود.

## ۲) تبدیل فایل keystore به Base64
در Termux:

```bash
base64 -w 0 nova-release.jks > nova-keystore-base64.txt
```

محتوای فایل متنی را کپی کنید. در بعضی محیط‌ها اگر `-w 0` پشتیبانی نشد:
```bash
base64 nova-release.jks | tr -d '\n' > nova-keystore-base64.txt
```

## ۳) افزودن GitHub Actions Secrets
در مخزن GitHub بروید به:
Settings → Secrets and variables → Actions → New repository secret

این چهار Secret را دقیقاً با این نام‌ها بسازید:
- `NOVA_KEYSTORE_BASE64` = تمام محتوای `nova-keystore-base64.txt`
- `NOVA_KEYSTORE_PASSWORD` = رمز keystore
- `NOVA_KEY_ALIAS` = `nova`
- `NOVA_KEY_PASSWORD` = رمز کلید (اگر هنگام ساخت همان رمز keystore را وارد کردید، همان را بگذارید)

**فایل JKS و رمزها را در مخزن، ZIP عمومی، پیام یا کد قرار ندهید.** آن‌ها را برای کسی ارسال نکنید.

## ۴) ساخت APK امضاشده
کد این پروژه را در مخزن GitHub قرار دهید، سپس:
Actions → Build Signed Nova Browser APK → Run workflow

پس از سبز شدن همه مراحل:
Actions → اجرای موفق → Artifacts → `NovaBrowser-0.3.2-signed-release`
فایل ZIP آرتیفکت را دانلود و APK داخل آن را استخراج کنید.

## نکته مهم
کلید امضا را چند نسخه پشتیبان امن نگه دارید. اگر کلید گم شود، به‌روزرسانی نصب موجود با همان شناسه برنامه ممکن است ممکن نباشد. این Workflow فقط وقتی APK را امضاشده تحویل می‌دهد که هر چهار Secret درست تنظیم شده باشند.
