plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    signingConfigs {
        create("release") {
            val storePath = System.getenv("NOVA_KEYSTORE_PATH")
            val storePass = System.getenv("NOVA_KEYSTORE_PASSWORD")
            val alias = System.getenv("NOVA_KEY_ALIAS")
            val keyPass = System.getenv("NOVA_KEY_PASSWORD")
            if (!storePath.isNullOrBlank() && !storePass.isNullOrBlank() &&
                !alias.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                storeFile = file(storePath)
                storePassword = storePass
                keyAlias = alias
                keyPassword = keyPass
            }
        }
    }

    namespace = "com.nova.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.browser"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "0.3.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // No external libraries needed: the UI uses plain Android views.
}
