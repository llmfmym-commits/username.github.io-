package com.nova.browser

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** Draws the Nova "N" logo with an orbit ring, in a 100x100 coordinate space. */
class LogoView(context: Context) : View(context) {
    private val nPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val nPath = Path()
    private val ringRect = RectF(4f, 50f, 96f, 88f)

    init {
        val colors = intArrayOf(0xFF1CC8FF.toInt(), 0xFF4F6BFF.toInt(), 0xFF8A4DFF.toInt())
        nPaint.style = Paint.Style.FILL
        nPaint.shader = LinearGradient(10f, 90f, 90f, 10f, colors, null, Shader.TileMode.CLAMP)
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 5f
        ringPaint.strokeCap = Paint.Cap.ROUND
        ringPaint.shader = LinearGradient(0f, 80f, 100f, 40f, colors, null, Shader.TileMode.CLAMP)

        nPath.moveTo(22f, 80f)
        nPath.lineTo(22f, 20f)
        nPath.lineTo(38f, 20f)
        nPath.lineTo(62f, 56f)
        nPath.lineTo(62f, 20f)
        nPath.lineTo(78f, 20f)
        nPath.lineTo(78f, 80f)
        nPath.lineTo(62f, 80f)
        nPath.lineTo(38f, 44f)
        nPath.lineTo(38f, 80f)
        nPath.close()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = minOf(width, height).toFloat()
        if (side <= 0f) return
        val scale = side / 100f
        canvas.save()
        canvas.translate((width - side) / 2f, (height - side) / 2f)
        canvas.scale(scale, scale)

        canvas.save()
        canvas.rotate(-16f, 50f, 68f)
        canvas.drawArc(ringRect, 150f, 290f, false, ringPaint)
        canvas.restore()

        canvas.save()
        canvas.translate(11f, 0f)
        canvas.skew(-0.2f, 0f)
        canvas.drawPath(nPath, nPaint)
        canvas.restore()

        canvas.restore()
    }
}
