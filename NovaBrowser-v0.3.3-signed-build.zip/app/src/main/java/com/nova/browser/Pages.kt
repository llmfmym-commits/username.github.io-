package com.nova.browser

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.text.Editable
import android.text.format.Formatter
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView

// ----------------------------------------------------------------------
// Shared list page (bookmarks / history)
// ----------------------------------------------------------------------

abstract class UrlListActivity : PageActivity() {
    protected abstract fun loadUrls(): List<String>
    protected abstract fun removeUrl(url: String)
    protected abstract fun clearAllUrls()
    protected abstract fun emptyText(): String
    protected abstract fun clearLabel(): String
    protected abstract fun rowIcon(): Int
    protected abstract fun rowTint(): Int

    private var query = ""
    private var listHolder: LinearLayout? = null

    override fun render() {
        val input = EditText(this)
        input.hint = "جست‌وجو در فهرست"
        input.setHintTextColor(C_MUTED)
        input.setTextColor(C_TEXT)
        input.textSize = 16f
        input.setSingleLine(true)
        input.background = roundRect(C_PILL, 24, C_PILL_STROKE, 1)
        input.setPadding(dp(18), 0, dp(18), 0)
        input.setText(query)
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                fillList()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
        val lp = LinearLayout.LayoutParams(MATCH, dp(48))
        lp.topMargin = dp(8)
        body.addView(input, lp)

        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        listHolder = holder
        body.addView(holder, LinearLayout.LayoutParams(MATCH, WRAP))
        fillList()
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toast("نشانی کپی شد")
    }

    private fun fillList() {
        val holder = listHolder ?: return
        holder.removeAllViews()
        val all = loadUrls()
        if (all.isEmpty()) {
            val tv = TextView(this)
            tv.text = emptyText()
            tv.textSize = 15f
            tv.setTextColor(C_MUTED)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(8), dp(48), dp(8), dp(48))
            holder.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }
        val q = query.trim().lowercase()
        val shown = ArrayList<String>()
        for (u in all) {
            if (q.isEmpty() || u.lowercase().contains(q)) shown.add(u)
        }

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val count = TextView(this)
        count.text = faDigits(shown.size.toString()) + " مورد"
        count.textSize = 14f
        count.setTextColor(C_MUTED)
        top.addView(count, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = TextView(this)
        clear.text = clearLabel()
        clear.textSize = 14f
        clear.setTextColor(C_DANGER)
        clear.setPadding(dp(8), dp(12), dp(8), dp(12))
        clear.setOnClickListener {
            confirm(clearLabel() + "؟", "تأیید") {
                clearAllUrls()
                fillList()
            }
        }
        top.addView(clear, LinearLayout.LayoutParams(WRAP, WRAP))
        holder.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        if (shown.isEmpty()) {
            val tv = TextView(this)
            tv.text = "نتیجه‌ای پیدا نشد"
            tv.setTextColor(C_MUTED)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(8), dp(32), dp(8), dp(32))
            holder.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }

        for (u in shown) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
            row.setPadding(dp(12), dp(8), dp(4), dp(8))

            val icon = ImageView(this)
            icon.setImageResource(rowIcon())
            icon.setColorFilter(rowTint())
            row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(12), 0, dp(8), 0)
            val host = TextView(this)
            host.text = hostOf(u)
            host.textSize = 16f
            host.setTextColor(C_TEXT)
            host.textDirection = View.TEXT_DIRECTION_LTR
            col.addView(ellipsized(host))
            val full = TextView(this)
            full.text = u
            full.textSize = 12f
            full.setTextColor(C_MUTED)
            full.textDirection = View.TEXT_DIRECTION_LTR
            col.addView(ellipsized(full))
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

            row.addView(iconButton(R.drawable.ic_copy, 40, 20, C_MUTED) { copyToClipboard(u) })
            row.addView(iconButton(R.drawable.ic_add_box, 40, 20, C_MUTED) { openInBrowser(u, true) })
            row.addView(iconButton(R.drawable.ic_delete, 40, 20, C_DANGER) {
                removeUrl(u)
                fillList()
            })
            row.setOnClickListener { openInBrowser(u, false) }

            val rlp = LinearLayout.LayoutParams(MATCH, WRAP)
            rlp.topMargin = dp(8)
            holder.addView(row, rlp)
        }
    }
}

class BookmarksActivity : UrlListActivity() {
    override fun pageTitle(): String = "نشانک‌ها"
    override fun loadUrls(): List<String> = prefs.bookmarks()
    override fun removeUrl(url: String) {
        prefs.removeBookmark(url)
    }

    override fun clearAllUrls() {
        prefs.clearBookmarks()
    }

    override fun emptyText(): String = "هنوز نشانکی ندارید.\nدر نوار آدرس روی ستاره بزنید تا صفحه ذخیره شود."
    override fun clearLabel(): String = "حذف همه‌ی نشانک‌ها"
    override fun rowIcon(): Int = R.drawable.ic_star
    override fun rowTint(): Int = C_STAR
}

class HistoryActivity : UrlListActivity() {
    override fun pageTitle(): String = "تاریخچه"
    override fun loadUrls(): List<String> = prefs.history()
    override fun removeUrl(url: String) {
        // history stores plain urls; rebuild without the removed one
        val rest = ArrayList<String>(prefs.history())
        rest.remove(url)
        prefs.clearHistory()
        for (i in rest.indices.reversed()) prefs.addHistory(rest[i])
    }

    override fun clearAllUrls() {
        prefs.clearHistory()
    }

    override fun emptyText(): String = "تاریخچه خالی است."
    override fun clearLabel(): String = "پاک کردن تاریخچه"
    override fun rowIcon(): Int = R.drawable.ic_history
    override fun rowTint(): Int = C_ACCENT_LIGHT
}

// ----------------------------------------------------------------------
// Downloads
// ----------------------------------------------------------------------

class DownloadsActivity : PageActivity() {
    override fun pageTitle(): String = "دانلودها"

    override fun render() {
        val actions = card()
        actionRow(actions, R.drawable.ic_download, "باز کردن پوشه‌ی دانلودها", "نمایش فایل‌ها در برنامه‌ی دانلود دستگاه", false) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e: Exception) {
                toast("باز کردن دانلودها ممکن نیست")
            }
        }
        actionRow(actions, R.drawable.ic_refresh, "تازه‌سازی فهرست", null, false) { rerender() }

        heading("دانلودهای مرورگر")
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        var found = 0
        val cur = dm.query(DownloadManager.Query())
        if (cur != null) {
            try {
                val iId = cur.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = cur.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iStatus = cur.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val iMime = cur.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
                val iTotal = cur.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iDone = cur.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                while (cur.moveToNext()) {
                    found += 1
                    addDownloadRow(
                        dm,
                        cur.getLong(iId),
                        cur.getString(iTitle),
                        cur.getInt(iStatus),
                        cur.getString(iMime),
                        cur.getLong(iTotal),
                        cur.getLong(iDone)
                    )
                }
            } finally {
                cur.close()
            }
        }
        if (found == 0) note("هنوز فایلی دانلود نشده است.")
    }

    private fun statusText(status: Int, total: Long, done: Long): String {
        return when (status) {
            DownloadManager.STATUS_SUCCESSFUL -> "کامل شد • " + faDigits(Formatter.formatShortFileSize(this, total))
            DownloadManager.STATUS_FAILED -> "ناموفق"
            DownloadManager.STATUS_PAUSED -> "متوقف شد"
            DownloadManager.STATUS_PENDING -> "در صف دانلود"
            else -> {
                if (total > 0) {
                    "در حال دانلود • " + faDigits((done * 100 / total).toString()) + "٪"
                } else {
                    "در حال دانلود…"
                }
            }
        }
    }

    private fun addDownloadRow(dm: DownloadManager, id: Long, title: String?, status: Int, mime: String?, total: Long, done: Long) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
        row.setPadding(dp(12), dp(8), dp(4), dp(8))

        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_file)
        icon.setColorFilter(C_ACCENT_LIGHT)
        row.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        val name = TextView(this)
        name.text = if (title.isNullOrEmpty()) "فایل" else title
        name.textSize = 15f
        name.setTextColor(C_TEXT)
        name.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        col.addView(ellipsized(name))
        val st = TextView(this)
        st.text = statusText(status, total, done)
        st.textSize = 12f
        st.setTextColor(if (status == DownloadManager.STATUS_FAILED) C_DANGER else C_MUTED)
        col.addView(st)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        if (status == DownloadManager.STATUS_SUCCESSFUL) {
            row.addView(iconButton(R.drawable.ic_chevron, 40, 20, C_ACCENT_LIGHT) { openFile(dm, id, mime) })
        }
        row.addView(iconButton(R.drawable.ic_delete, 40, 20, C_DANGER) {
            confirm("این دانلود و فایل آن حذف شود؟", "حذف") {
                dm.remove(id)
                rerender()
            }
        })

        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(8)
        body.addView(row, lp)
    }

    private fun openFile(dm: DownloadManager, id: Long, mime: String?) {
        try {
            val uri = dm.getUriForDownloadedFile(id)
            if (uri == null) {
                toast("فایل پیدا نشد")
                return
            }
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, if (mime.isNullOrEmpty()) "*/*" else mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            toast("برنامه‌ای برای باز کردن این فایل نیست")
        }
    }
}

// ----------------------------------------------------------------------
// Settings
// ----------------------------------------------------------------------

class SettingsActivity : PageActivity() {
    override fun pageTitle(): String = "تنظیمات"

    override fun render() {
        heading("موتور جست‌وجو")
        val engineCard = card()
        val group = RadioGroup(this)
        for (i in ENGINES.indices) {
            val rb = RadioButton(this)
            rb.text = ENGINES[i].first
            rb.setTextColor(C_TEXT)
            rb.textSize = 16f
            rb.isChecked = i == prefs.searchEngine()
            rb.setOnClickListener { prefs.setSearchEngine(i) }
            group.addView(rb)
        }
        engineCard.addView(group)

        heading("مرور")
        val browse = card()
        switchRow(browse, "جاوااسکریپت", "برای کار کردن بیشتر سایت‌ها لازم است", prefs.javascriptEnabled()) {
            prefs.setJavascriptEnabled(it)
        }
        switchRow(browse, "بارگذاری تصاویر", "خاموش کردن آن مصرف اینترنت را کم می‌کند", prefs.imagesEnabled()) {
            prefs.setImagesEnabled(it)
        }
        switchRow(browse, "نسخه‌ی دسکتاپ به‌صورت پیش‌فرض", "برای تب‌های تازه باز شده", prefs.defaultDesktop()) {
            prefs.setDefaultDesktop(it)
        }
        switchRow(browse, "بازیابی تب‌ها هنگام شروع", "تب‌های باز دفعه‌ی قبل دوباره باز می‌شوند", prefs.restoreTabsEnabled()) {
            prefs.setRestoreTabsEnabled(it)
        }

        heading("اندازه‌ی متن صفحه‌ها")
        val sizeCard = card()
        val label = TextView(this)
        label.text = faDigits(prefs.textZoom().toString()) + "٪"
        label.textSize = 16f
        label.setTextColor(C_TEXT)
        label.setPadding(dp(4), dp(10), dp(4), 0)
        sizeCard.addView(label)
        val seek = SeekBar(this)
        seek.max = 15
        seek.progress = ((prefs.textZoom() - 50) / 10).coerceIn(0, 15)
        seek.setPadding(dp(8), dp(8), dp(8), dp(12))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = 50 + progress * 10
                prefs.setTextZoom(value)
                label.text = faDigits(value.toString()) + "٪"
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {
            }

            override fun onStopTrackingTouch(bar: SeekBar?) {
            }
        })
        sizeCard.addView(seek)
        note("اندازه برای تب‌های تازه اعمال می‌شود. برای تب فعلی از منو > بزرگ‌نمایی استفاده کنید.")

        heading("بخش‌های دیگر")
        val links = card()
        actionRow(links, R.drawable.ic_shield, "حریم خصوصی و امنیت", null, false) {
            startActivity(Intent(this, PrivacyActivity::class.java))
        }
        actionRow(links, R.drawable.ic_info, "درباره‌ی مرورگر نوا", null, false) {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }
}

// ----------------------------------------------------------------------
// Privacy & security
// ----------------------------------------------------------------------

class PrivacyActivity : PageActivity() {
    override fun pageTitle(): String = "حریم خصوصی و امنیت"

    override fun render() {
        heading("محافظت‌های فعال")
        val info = card()
        val items = listOf(
            "محتوای ترکیبی (http داخل https) مسدود است",
            "دسترسی به فایل‌ها و محتوای محلی غیرفعال است",
            "فقط سایت‌های HTTPS باز می‌شوند",
            "گواهی نامعتبر سایت‌ها رد می‌شود",
            "تب ناشناس تاریخچه و کش ذخیره نمی‌کند"
        )
        for (text in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(8), dp(4), dp(8))
            val iv = ImageView(this)
            iv.setImageResource(R.drawable.ic_check)
            iv.setColorFilter(C_TAG2)
            row.addView(iv, LinearLayout.LayoutParams(dp(20), dp(20)))
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 15f
            tv.setTextColor(C_TEXT)
            tv.setPadding(dp(12), 0, 0, 0)
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            info.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        note("توجه: تب ناشناس کوکی‌ها را با تب‌های عادی به اشتراک می‌گذارد.")

        heading("گزینه‌ها")
        val options = card()
        switchRow(options, "مسدود کردن کوکی‌های شخص ثالث", "جلوگیری از ردیابی میان سایت‌ها", prefs.blockThirdPartyCookies()) {
            prefs.setBlockThirdPartyCookies(it)
        }
        switchRow(options, "پاک کردن داده‌ها هنگام خروج", "با «خروج» از منو همه‌ی داده‌ی مرور پاک می‌شود", prefs.clearOnExit()) {
            prefs.setClearOnExit(it)
        }

        heading("پاک کردن داده‌ها")
        val clear = card()
        actionRow(clear, R.drawable.ic_history, "تاریخچه", null, false) {
            confirm("تاریخچه پاک شود؟", "پاک کن") {
                prefs.clearHistory()
                toast("تاریخچه پاک شد")
            }
        }
        actionRow(clear, R.drawable.ic_lock, "کوکی‌ها", "از حساب‌های کاربری سایت‌ها خارج می‌شوید", false) {
            confirm("همه‌ی کوکی‌ها پاک شوند؟", "پاک کن") {
                DataCleaner.clearCookies()
                toast("کوکی‌ها پاک شدند")
            }
        }
        actionRow(clear, R.drawable.ic_file, "کش", null, false) {
            confirm("کش مرورگر پاک شود؟", "پاک کن") {
                DataCleaner.clearCache(this)
                toast("کش پاک شد")
            }
        }
        actionRow(clear, R.drawable.ic_globe, "داده‌ی ذخیره‌شده‌ی سایت‌ها", null, false) {
            confirm("داده‌ی ذخیره‌شده‌ی سایت‌ها پاک شود؟", "پاک کن") {
                DataCleaner.clearSiteData()
                toast("داده‌ی سایت‌ها پاک شد")
            }
        }
        actionRow(clear, R.drawable.ic_delete, "پاک کردن همه", "تاریخچه، کوکی‌ها، کش و داده‌ی سایت‌ها", true) {
            confirm("همه‌ی داده‌های مرور پاک شوند؟", "پاک کن") {
                DataCleaner.clearAll(this, prefs)
                toast("همه‌ی داده‌ها پاک شد")
            }
        }
    }
}

// ----------------------------------------------------------------------
// About
// ----------------------------------------------------------------------

class AboutActivity : PageActivity() {
    override fun pageTitle(): String = "درباره‌ی مرورگر نوا"

    override fun render() {
        val logo = LogoView(this)
        val lp = LinearLayout.LayoutParams(dp(130), dp(110))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(16)
        body.addView(logo, lp)

        val name = TextView(this)
        name.text = "مرورگر نوا"
        name.textSize = 28f
        name.typeface = Typeface.DEFAULT_BOLD
        name.setTextColor(C_TITLE)
        name.gravity = Gravity.CENTER
        body.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))

        val tag = TextView(this)
        tag.text = "سریع  •  امن  •  قدرتمند"
        tag.textSize = 16f
        tag.setTextColor(C_TAG1)
        tag.gravity = Gravity.CENTER
        body.addView(tag, LinearLayout.LayoutParams(MATCH, WRAP))

        var version = "0.3.0"
        try {
            val v = packageManager.getPackageInfo(packageName, 0).versionName
            if (v != null) version = v
        } catch (e: Exception) {
            // keep default
        }
        var engine = "Android System WebView"
        if (Build.VERSION.SDK_INT >= 26) {
            val pkg = WebView.getCurrentWebViewPackage()
            if (pkg != null) engine += " " + pkg.versionName
        }

        heading("اطلاعات")
        val info = card()
        addInfo(info, "نسخه", faDigits(version))
        addInfo(info, "موتور مرور", engine + " (Chromium)")
        addInfo(info, "شناسه‌ی برنامه", packageName)

        heading("امکانات")
        val features = card()
        val list = listOf(
            "چند تب و تب ناشناس",
            "نشانک‌ها و تاریخچه با جست‌وجو",
            "مدیریت دانلودها",
            "یافتن در صفحه، اشتراک‌گذاری و کپی نشانی",
            "نسخه‌ی دسکتاپ و تنظیم اندازه‌ی متن",
            "انتخاب موتور جست‌وجو",
            "پاک کردن جداگانه‌ی تاریخچه، کوکی، کش و داده‌ی سایت‌ها"
        )
        for (t in list) {
            val tv = TextView(this)
            tv.text = "• " + t
            tv.textSize = 15f
            tv.setTextColor(C_TEXT)
            tv.setPadding(dp(4), dp(6), dp(4), dp(6))
            features.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun addInfo(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        val l = TextView(this)
        l.text = label
        l.textSize = 15f
        l.setTextColor(C_MUTED)
        row.addView(l, LinearLayout.LayoutParams(WRAP, WRAP))
        val v = TextView(this)
        v.text = value
        v.textSize = 15f
        v.setTextColor(C_TEXT)
        v.gravity = Gravity.END
        v.textDirection = View.TEXT_DIRECTION_LTR
        val vlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        vlp.leftMargin = dp(12)
        row.addView(v, vlp)
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }
}
