plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nova.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.browser"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "0.4.1"
    }

    val novaStorePath = System.getenv("NOVA_KEYSTORE_PATH")
    val novaStorePassword = System.getenv("NOVA_KEYSTORE_PASSWORD")
    val novaKeyAlias = System.getenv("NOVA_KEY_ALIAS")
    val novaKeyPassword = System.getenv("NOVA_KEY_PASSWORD")
    val hasNovaSigning = !novaStorePath.isNullOrBlank() &&
        !novaStorePassword.isNullOrBlank() && !novaKeyAlias.isNullOrBlank() && !novaKeyPassword.isNullOrBlank()

    if (hasNovaSigning) {
        signingConfigs.create("nova") {
            storeFile = file(novaStorePath!!)
            storePassword = novaStorePassword
            keyAlias = novaKeyAlias
            keyPassword = novaKeyPassword
        }
    }

    buildTypes {
        getByName("debug") {
            // Debug builds use Android's standard debug signing key.
        }
        getByName("release") {
            if (hasNovaSigning) signingConfig = signingConfigs.getByName("nova")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // No external libraries needed: the UI uses plain Android views.
}
