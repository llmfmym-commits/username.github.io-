package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader

/** SAF-based file center. Nova only reads files the user explicitly selects. */
class FileCenterActivity : Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("nova_file_center", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C_BG); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(C_STRIP) }
        header.addView(TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(C_TEXT); setPadding(dp(8), 0, dp(16), 0); setOnClickListener { finish() } })
        header.addView(TextView(this).apply { text = "مرکز فایل نوا"; textSize = 20f; setTextColor(C_TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        root.addView(header)
        root.addView(Button(this).apply { text = "انتخاب فایل از گوشی"; setOnClickListener { chooseFile() } })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(20)) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        renderRecent()
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 7001)
    }

    @Deprecated("Activity result API kept dependency-free for this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7001 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        remember(uri)
        openSelected(uri)
        renderRecent()
    }

    private fun remember(uri: Uri) {
        val values = prefs.getString("recent", "")!!.split('\n').filter { it.isNotBlank() && it != uri.toString() }.toMutableList()
        values.add(0, uri.toString())
        prefs.edit().putString("recent", values.take(20).joinToString("\n")).apply()
    }

    private fun renderRecent() {
        list.removeAllViews()
        list.addView(TextView(this).apply { text = "فایل‌های اخیر"; textSize = 18f; setTextColor(C_TITLE); typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, dp(10)) })
        val recent = prefs.getString("recent", "")!!.split('\n').filter { it.isNotBlank() }
        if (recent.isEmpty()) list.addView(TextView(this).apply { text = "هنوز فایلی انتخاب نشده است."; setTextColor(C_MUTED) })
        recent.forEach { raw ->
            val uri = Uri.parse(raw)
            val row = TextView(this).apply {
                text = "📄  ${displayName(uri)}\n${mimeType(uri) ?: "نوع فایل نامشخص"}"
                textSize = 14f; setTextColor(C_TEXT); setPadding(dp(12), dp(12), dp(12), dp(12)); background = roundRect(C_PILL, 12)
                setOnClickListener { openSelected(uri) }
                setOnLongClickListener { AlertDialog.Builder(this@FileCenterActivity).setMessage("این فایل از فهرست اخیرها حذف شود؟").setPositiveButton("حذف") { _, _ -> removeRecent(raw) }.setNegativeButton("انصراف", null).show(); true }
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) }
            list.addView(row, lp)
        }
    }

    private fun removeRecent(raw: String) {
        val values = prefs.getString("recent", "")!!.split('\n').filter { it.isNotBlank() && it != raw }
        prefs.edit().putString("recent", values.joinToString("\n")).apply()
        renderRecent()
    }

    private fun displayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: uri.lastPathSegment ?: "فایل" else "فایل"
            } ?: uri.lastPathSegment ?: "فایل"
        } catch (_: Exception) { uri.lastPathSegment ?: "فایل" }
    }

    private fun mimeType(uri: Uri): String? = contentResolver.getType(uri)

    private fun openSelected(uri: Uri) {
        val mime = mimeType(uri) ?: "application/octet-stream"
        when {
            mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("xml") || displayName(uri).matches(Regex(".*\\.(kt|java|py|html|css|js|txt|md|json|xml)$", RegexOption.IGNORE_CASE)) -> showText(uri)
            mime.startsWith("image/") -> showImage(uri)
            else -> {
                val view = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                try { startActivity(view) } catch (_: Exception) { toast("برای باز کردن این نوع فایل، برنامهٔ سازگار نصب نیست.") }
            }
        }
    }

    private fun showText(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                val out = StringBuilder(); val buffer = CharArray(4096); var total = 0
                while (total < 512 * 1024) {
                    val count = reader.read(buffer)
                    if (count <= 0) break
                    out.append(buffer, 0, count)
                    total += count
                }
                out.toString()
            } ?: "امکان خواندن فایل وجود ندارد."
            val view = TextView(this).apply { this.text = text; textSize = 13f; setTextColor(C_TEXT); setPadding(dp(14), dp(14), dp(14), dp(14)); textDirection = View.TEXT_DIRECTION_LTR; setBackgroundColor(C_BG) }
            val scroll = ScrollView(this).apply { addView(view) }
            AlertDialog.Builder(this).setTitle(displayName(uri)).setView(scroll).setPositiveButton("بستن", null).show()
        } catch (e: Exception) { toast("خطا در خواندن فایل: ${e.message}") }
    }

    private fun showImage(uri: Uri) {
        try {
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("تصویر قابل خواندن نیست")
            val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
            AlertDialog.Builder(this).setTitle(displayName(uri)).setView(image).setPositiveButton("بستن", null).show()
        } catch (e: Exception) { toast("خطا در نمایش تصویر: ${e.message}") }
    }
}
