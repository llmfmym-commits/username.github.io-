package com.nova.browser

import android.content.Context
import android.widget.ImageView

/** The Nova logo (cut from the design screenshot). */
class LogoView(context: Context) : ImageView(context) {
    init {
        setImageResource(R.drawable.nova_logo)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }
}
