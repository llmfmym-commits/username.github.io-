package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Base class for every full-screen section page (bookmarks, history, settings, ...). */
abstract class PageActivity : Activity() {

    protected lateinit var prefs: BrowserPrefs
    protected lateinit var body: LinearLayout

    protected abstract fun pageTitle(): String
    protected abstract fun render()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BrowserPrefs(this)
        window.setBackgroundDrawable(ColorDrawable(C_BG))
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(C_BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setBackgroundColor(C_STRIP)
        header.setPadding(dp(8), dp(6), dp(16), dp(6))
        header.addView(iconButton(R.drawable.ic_back, 48, 24, C_TEXT) { finish() })
        val titleView = TextView(this)
        titleView.text = pageTitle()
        titleView.textSize = 20f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.setTextColor(C_TEXT)
        titleView.setPadding(dp(8), 0, 0, 0)
        header.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val scroll = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(8), dp(16), dp(24))
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { v, insets ->
                val types = WindowInsets.Type.systemBars() or
                    WindowInsets.Type.displayCutout() or
                    WindowInsets.Type.ime()
                val b = insets.getInsets(types)
                v.setPadding(b.left, b.top, b.right, b.bottom)
                WindowInsets.CONSUMED
            }
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        body.removeAllViews()
        render()
    }

    // ---- helpers for subclasses ----

    /** Returns the url to the browser; the main screen opens it. */
    protected fun openInBrowser(url: String, inNewTab: Boolean) {
        val i = Intent()
        i.putExtra("open_url", url)
        i.putExtra("new_tab", inNewTab)
        setResult(RESULT_OK, i)
        finish()
    }

    protected fun heading(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(C_ACCENT_LIGHT)
        tv.setPadding(dp(4), dp(16), dp(4), dp(6))
        body.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    protected fun note(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(C_MUTED)
        tv.setPadding(dp(4), dp(6), dp(4), dp(6))
        body.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    protected fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
        c.setPadding(dp(12), dp(4), dp(12), dp(4))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(4))
        body.addView(c, lp)
        return c
    }

    private fun textColumn(label: String, desc: String?, labelColor: Int): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val l = TextView(this)
        l.text = label
        l.textSize = 16f
        l.setTextColor(labelColor)
        col.addView(l)
        if (desc != null) {
            val d = TextView(this)
            d.text = desc
            d.textSize = 13f
            d.setTextColor(C_MUTED)
            col.addView(d)
        }
        return col
    }

    protected fun actionRow(parent: LinearLayout, icon: Int, label: String, desc: String?, danger: Boolean, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        row.background = rippleBg(false)
        val color = if (danger) C_DANGER else C_TEXT
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(color)
        row.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
        val col = textColumn(label, desc, color)
        col.setPadding(dp(14), 0, dp(8), 0)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.setOnClickListener { onClick() }
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    protected fun switchRow(parent: LinearLayout, label: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        val col = textColumn(label, desc, C_TEXT)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.thumbTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(C_ACCENT, C_MUTED)
        )
        sw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(android.graphics.Color.parseColor("#665B6CFF"), android.graphics.Color.parseColor("#33FFFFFF"))
        )
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
        row.setOnClickListener { sw.toggle() }
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    protected fun confirm(message: String, positive: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton("انصراف", null)
            .show()
    }

    protected fun rerender() {
        body.removeAllViews()
        render()
    }

    protected fun ellipsized(tv: TextView): TextView {
        tv.setSingleLine(true)
        tv.ellipsize = TextUtils.TruncateAt.END
        return tv
    }
}
