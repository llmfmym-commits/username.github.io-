package com.nova.browser

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Lightweight GLB viewer built on Google's model-viewer Web Component. */
class Studio3DActivity : Activity() {
    private lateinit var viewer: WebView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C_BG); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(C_STRIP) }
        header.addView(TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(C_TEXT); setPadding(dp(8), 0, dp(16), 0); setOnClickListener { finish() } })
        header.addView(TextView(this).apply { text = "Nova 3D Studio"; textSize = 19f; setTextColor(C_TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(Button(this).apply { text = "باز کردن GLB"; setOnClickListener { chooseModel() } })
        root.addView(header)
        status = TextView(this).apply { text = "یک فایل GLB انتخاب کن. برای بارگذاری مدل به اینترنت نیاز است."; setTextColor(C_MUTED); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        root.addView(status)
        viewer = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        root.addView(viewer, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(Button(this).apply { text = "بازنشانی دوربین"; setOnClickListener { viewer.evaluateJavascript("document.querySelector('model-viewer')?.resetTurntableRotation();document.querySelector('model-viewer')?.jumpCameraToGoal();", null) } })
        setContentView(root)
        showEmpty()
    }

    private fun chooseModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "model/gltf-binary"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivityForResult(i, 7010)
    }

    @Deprecated("Activity result API kept dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7010 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192); var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        total += count
                        if (total > 30 * 1024 * 1024) throw IllegalArgumentException("حجم فایل باید کمتر از ۳۰ مگابایت باشد")
                        out.write(buffer, 0, count)
                    }
                    out.toByteArray()
                } ?: throw IllegalStateException("فایل قابل خواندن نیست")
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                runOnUiThread { loadModel(b64) }
            } catch (e: Exception) { runOnUiThread { toast("خطا در بارگذاری مدل: ${e.message}") } }
        }.start()
    }

    private fun showEmpty() {
        viewer.loadDataWithBaseURL("https://modelviewer.dev/", """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;background:#090b20;color:#cbd0ff;font:16px sans-serif;display:grid;place-items:center;height:100vh;text-align:center">
            <div>برای شروع، یک فایل <b>GLB</b> انتخاب کن.<br><small>چرخش، بزرگ‌نمایی و تغییر زاویه دوربین پشتیبانی می‌شود.</small></div></body></html>
        """.trimIndent(), "text/html", "UTF-8", null)
    }

    private fun loadModel(base64: String) {
        status.text = "مدل بارگذاری شد • برای چرخش و بزرگ‌نمایی انگشتت را روی مدل حرکت بده"
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
            <script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/4.0.0/model-viewer.min.js"></script>
            <style>html,body{margin:0;width:100%;height:100%;background:#090b20}model-viewer{width:100%;height:100%;--poster-color:transparent}</style></head>
            <body><model-viewer src="data:model/gltf-binary;base64,$base64" camera-controls touch-action="pan-y" auto-rotate shadow-intensity="1" exposure="1" environment-image="neutral" camera-orbit="35deg 70deg 2.5m"></model-viewer></body></html>
        """.trimIndent()
        viewer.loadDataWithBaseURL("https://modelviewer.dev/", html, "text/html", "UTF-8", null)
    }
}
