package com.nova.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

private const val REQ_FILE = 1001
private const val REQ_VOICE = 1002
private const val REQ_STORAGE = 1003
private const val REQ_PAGE = 1004
private const val MAX_TABS = 20

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

internal class BrowserTab(val incognito: Boolean, var desktop: Boolean, var zoom: Int) {
    var webView: WebView? = null
    var title: String = ""
    var url: String = ""
}

internal class PendingDownload(
    val url: String,
    val userAgent: String?,
    val contentDisposition: String?,
    val mimeType: String?
)

internal class ShortcutDef(
    val label: String,
    val url: String,
    val glyph: String,
    val bg: Drawable,
    val fg: Int
)

class MainActivity : Activity() {

    private lateinit var prefs: BrowserPrefs
    private val tabs = ArrayList<BrowserTab>()
    private var currentIndex = 0

    private lateinit var rootFrame: FrameLayout
    private lateinit var root: LinearLayout
    private lateinit var tabRow: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var tabCountTop: TextView
    private lateinit var tabCountBottom: TextView
    private lateinit var toolbar: LinearLayout
    private lateinit var address: EditText
    private lateinit var lockIcon: ImageView
    private lateinit var starIcon: ImageView
    private lateinit var progressBar: View
    private lateinit var content: FrameLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var btnBack: ImageView
    private lateinit var btnForward: ImageView
    private lateinit var fullscreenHolder: FrameLayout

    private var menuPopup: PopupWindow? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingDownload: PendingDownload? = null
    private var appliedZoom = -1
    private var appliedDesktop = false

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = BrowserPrefs(this)
        ensureDefaultShortcuts()
        styleWindow()
        buildInterface()
        restoreTabs()
        if (savedInstanceState == null) handleIntent(intent)
        showCurrent()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        showCurrent()
    }

    override fun onPause() {
        saveTabs()
        tabs.getOrNull(currentIndex)?.webView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        tabs.getOrNull(currentIndex)?.webView?.onResume()
        applySettings()
        if (tabs.isNotEmpty() && current().webView == null) showCurrent()
    }

    override fun onDestroy() {
        for (t in tabs) {
            val wv = t.webView
            if (wv != null) {
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.stopLoading()
                wv.destroy()
            }
            t.webView = null
        }
        if (isFinishing && prefs.clearOnExit()) DataCleaner.clearAll(applicationContext, prefs)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (menuPopup?.isShowing == true) {
            menuPopup?.dismiss()
            return
        }
        if (customView != null) {
            hideCustomView()
            return
        }
        if (findBar.visibility == View.VISIBLE) {
            hideFindBar()
            return
        }
        val wv = current().webView
        if (wv != null) {
            if (wv.canGoBack()) wv.goBack() else goHome()
            return
        }
        if (tabs.size > 1) {
            closeTab(currentIndex)
            return
        }
        super.onBackPressed()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.isCtrlPressed) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_T -> {
                    newTab(false)
                    return true
                }
                KeyEvent.KEYCODE_W -> {
                    closeTab(currentIndex)
                    return true
                }
                KeyEvent.KEYCODE_L -> {
                    focusAddress()
                    return true
                }
                KeyEvent.KEYCODE_R -> {
                    reload()
                    return true
                }
                KeyEvent.KEYCODE_F -> {
                    showFindBar()
                    return true
                }
                KeyEvent.KEYCODE_B -> {
                    startPage(BookmarksActivity::class.java)
                    return true
                }
                KeyEvent.KEYCODE_H -> {
                    startPage(HistoryActivity::class.java)
                    return true
                }
                KeyEvent.KEYCODE_J -> {
                    startPage(DownloadsActivity::class.java)
                    return true
                }
                else -> {
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------

    private fun current(): BrowserTab = tabs[currentIndex]

    private fun isCurrent(tab: BrowserTab): Boolean =
        tabs.isNotEmpty() && currentIndex < tabs.size && tabs[currentIndex] === tab

    private fun makeTab(incognito: Boolean): BrowserTab =
        BrowserTab(incognito, prefs.defaultDesktop(), prefs.textZoom())

    private fun makeCountBadge(): TextView {
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(C_ACCENT_LIGHT)
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.includeFontPadding = false
        val bg = GradientDrawable()
        bg.setColor(Color.TRANSPARENT)
        bg.cornerRadius = dp(7).toFloat()
        bg.setStroke(dp(2), C_ACCENT_LIGHT)
        tv.background = bg
        tv.setOnClickListener { showTabSwitcher() }
        return tv
    }

    private fun tabTitle(t: BrowserTab): String {
        if (t.title.isNotEmpty()) return t.title
        if (t.url.isNotEmpty()) return hostOf(t.url)
        return if (t.incognito) "ناشناس" else "مرورگر نوا"
    }

    @Suppress("DEPRECATION")
    private fun styleWindow() {
        window.setBackgroundDrawable(ColorDrawable(C_BG))
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_TOOLBAR
    }

    private fun startPage(cls: Class<*>) {
        startActivityForResult(Intent(this, cls), REQ_PAGE)
    }

    // ------------------------------------------------------------------
    // Interface
    // ------------------------------------------------------------------

    private fun buildInterface() {
        rootFrame = FrameLayout(this)
        rootFrame.setBackgroundColor(C_BG)
        rootFrame.layoutDirection = View.LAYOUT_DIRECTION_RTL

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.isFocusableInTouchMode = true
        rootFrame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))

        // --- tab strip row ---
        tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.gravity = Gravity.BOTTOM
        tabRow.setBackgroundColor(C_STRIP)

        tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.overScrollMode = View.OVER_SCROLL_NEVER
        tabStrip = LinearLayout(this)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.BOTTOM
        tabScroll.addView(tabStrip, FrameLayout.LayoutParams(WRAP, MATCH))
        tabRow.addView(tabScroll, LinearLayout.LayoutParams(0, dp(46), 1f))

        tabCountTop = makeCountBadge()
        val topBadgeLp = LinearLayout.LayoutParams(dp(26), dp(26))
        topBadgeLp.setMargins(dp(8), 0, dp(8), dp(10))
        tabRow.addView(tabCountTop, topBadgeLp)
        tabRow.addView(iconButton(R.drawable.ic_more, 44, 22, C_TEXT) { showMenu() })
        root.addView(tabRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- toolbar ---
        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setPadding(dp(4), dp(6), dp(4), dp(8))
        toolbar.setBackgroundColor(C_TOOLBAR)
        toolbar.addView(iconButton(R.drawable.ic_home, 44, 24, C_TEXT) { goHome() })

        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = roundRect(C_PILL, 24)

        lockIcon = ImageView(this)
        lockIcon.setImageResource(R.drawable.ic_lock)
        lockIcon.setColorFilter(C_TEXT)
        lockIcon.setPadding(dp(14), 0, dp(6), 0)
        pill.addView(lockIcon, LinearLayout.LayoutParams(dp(40), dp(20)))

        address = EditText(this)
        address.background = null
        address.hint = "جست‌وجو یا وارد کردن نشانی"
        address.setHintTextColor(C_MUTED)
        address.setTextColor(C_TEXT)
        address.textSize = 16f
        address.setSingleLine(true)
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.setSelectAllOnFocus(true)
        address.setPadding(0, 0, 0, 0)
        address.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        address.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                val raw = address.text.toString()
                hideKeyboard()
                navigateInput(raw)
                true
            } else {
                false
            }
        }
        address.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) refreshToolbar()
        }
        pill.addView(address, LinearLayout.LayoutParams(0, MATCH, 1f))

        starIcon = iconButton(R.drawable.ic_star_border, 44, 22, C_TEXT) { toggleBookmark() }
        pill.addView(starIcon)

        val pillLp = LinearLayout.LayoutParams(0, dp(44), 1f)
        pillLp.setMargins(dp(4), 0, dp(4), 0)
        toolbar.addView(pill, pillLp)
        toolbar.addView(iconButton(R.drawable.ic_more, 44, 22, C_TEXT) { showMenu() })
        root.addView(toolbar, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- progress line ---
        val track = FrameLayout(this)
        track.setBackgroundColor(C_TOOLBAR)
        progressBar = View(this)
        progressBar.setBackgroundColor(C_ACCENT)
        progressBar.visibility = View.GONE
        track.addView(progressBar, FrameLayout.LayoutParams(0, dp(2), Gravity.START))
        root.addView(track, LinearLayout.LayoutParams(MATCH, dp(2)))

        // --- content ---
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // --- find in page bar ---
        findBar = LinearLayout(this)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setBackgroundColor(C_TOOLBAR)
        findBar.setPadding(dp(12), dp(4), dp(4), dp(4))
        findBar.visibility = View.GONE

        findInput = EditText(this)
        findInput.background = roundRect(C_PILL, 20)
        findInput.hint = "یافتن در صفحه"
        findInput.setHintTextColor(C_MUTED)
        findInput.setTextColor(C_TEXT)
        findInput.textSize = 15f
        findInput.setSingleLine(true)
        findInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        findInput.setPadding(dp(14), 0, dp(14), 0)
        findInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val wv = current().webView
                val q = s?.toString() ?: ""
                if (wv != null) {
                    if (q.isEmpty()) {
                        wv.clearMatches()
                        findCount.text = ""
                    } else {
                        wv.findAllAsync(q)
                    }
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
        findInput.setOnEditorActionListener { _, _, _ ->
            current().webView?.findNext(true)
            true
        }
        findBar.addView(findInput, LinearLayout.LayoutParams(0, dp(40), 1f))

        findCount = TextView(this)
        findCount.textSize = 13f
        findCount.setTextColor(C_MUTED)
        findCount.setPadding(dp(8), 0, dp(4), 0)
        findBar.addView(findCount, LinearLayout.LayoutParams(WRAP, WRAP))
        findBar.addView(iconButton(R.drawable.ic_up, 40, 22, C_TEXT) { current().webView?.findNext(false) })
        findBar.addView(iconButton(R.drawable.ic_down, 40, 22, C_TEXT) { current().webView?.findNext(true) })
        findBar.addView(iconButton(R.drawable.ic_close, 40, 22, C_TEXT) { hideFindBar() })
        root.addView(findBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- bottom bar ---
        val divider = View(this)
        divider.setBackgroundColor(C_DIVIDER)
        root.addView(divider, LinearLayout.LayoutParams(MATCH, dp(1)))

        bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.gravity = Gravity.CENTER
        bottomBar.setBackgroundColor(C_TOOLBAR)

        btnBack = iconButton(R.drawable.ic_back, 52, 24, C_TEXT) { goBack() }
        btnForward = iconButton(R.drawable.ic_forward, 52, 24, C_TEXT) { goForward() }
        val homeBtn = iconButton(R.drawable.ic_home, 52, 24, C_TEXT) { goHome() }
        val menuBtn = iconButton(R.drawable.ic_menu, 52, 24, C_TEXT) { showMenu() }

        tabCountBottom = makeCountBadge()
        val badgeHolder = FrameLayout(this)
        badgeHolder.addView(tabCountBottom, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        badgeHolder.setOnClickListener { showTabSwitcher() }

        bottomBar.addView(btnBack, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(btnForward, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(homeBtn, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(badgeHolder, LinearLayout.LayoutParams(0, dp(52), 1f))
        bottomBar.addView(menuBtn, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(bottomBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- fullscreen video holder ---
        fullscreenHolder = FrameLayout(this)
        fullscreenHolder.setBackgroundColor(Color.BLACK)
        fullscreenHolder.visibility = View.GONE
        rootFrame.addView(fullscreenHolder, FrameLayout.LayoutParams(MATCH, MATCH))

        // Android 15+ draws edge-to-edge, so pad the bars by the system insets.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { _, insets ->
                val types = WindowInsets.Type.systemBars() or
                    WindowInsets.Type.displayCutout() or
                    WindowInsets.Type.ime()
                val b = insets.getInsets(types)
                tabRow.setPadding(b.left, b.top, b.right, 0)
                bottomBar.setPadding(b.left, 0, b.right, b.bottom)
                WindowInsets.CONSUMED
            }
        }

        setContentView(rootFrame)
        root.requestFocus()
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private fun restoreTabs() {
        val saved = if (prefs.restoreTabsEnabled()) prefs.tabs() else ArrayList<String>()
        if (saved.isEmpty()) {
            tabs.add(makeTab(false))
            currentIndex = 0
        } else {
            for (u in saved) {
                val t = makeTab(false)
                t.url = u
                tabs.add(t)
            }
            currentIndex = prefs.currentTab().coerceIn(0, tabs.size - 1)
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        var target: String? = null
        val action = i.action
        if (action == Intent.ACTION_VIEW) {
            val data = i.data
            if (data != null) {
                val sc = data.scheme
                if (sc == "http" || sc == "https") target = data.toString()
            }
        } else if (action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT)
            if (text != null) {
                val parts = text.trim().split(" ", "\n")
                var picked = text.trim()
                for (p in parts) {
                    if (p.startsWith("http://") || p.startsWith("https://")) {
                        picked = p
                        break
                    }
                }
                target = resolveInput(picked)
            }
        } else if (action == Intent.ACTION_WEB_SEARCH) {
            val q = i.getStringExtra("query")
            if (q != null) target = resolveInput(q)
        }
        if (target == null) return
        if (tabs.size >= MAX_TABS) return
        val t = makeTab(false)
        t.url = upgradeUrl(target)
        tabs.add(t)
        currentIndex = tabs.size - 1
    }

    private fun saveTabs() {
        if (tabs.isEmpty()) return
        val urls = ArrayList<String>()
        var cur = 0
        for (i in tabs.indices) {
            val t = tabs[i]
            if (t.incognito) continue
            if (i == currentIndex) cur = urls.size
            urls.add(t.url)
        }
        prefs.saveTabs(urls, cur)
    }

    private fun newTab(incognito: Boolean) {
        if (tabs.size >= MAX_TABS) {
            toast("تعداد تب‌ها زیاد است")
            return
        }
        tabs.add(makeTab(incognito))
        currentIndex = tabs.size - 1
        showCurrent()
        saveTabs()
    }

    private fun selectTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        currentIndex = index
        showCurrent()
        saveTabs()
    }

    private fun destroyWebView(t: BrowserTab) {
        val wv = t.webView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.stopLoading()
        wv.destroy()
        t.webView = null
    }

    private fun closeTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        destroyWebView(tabs[index])
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            tabs.add(makeTab(false))
            currentIndex = 0
        } else if (index < currentIndex) {
            currentIndex -= 1
        } else if (currentIndex >= tabs.size) {
            currentIndex = tabs.size - 1
        }
        showCurrent()
        saveTabs()
    }

    private fun showCurrent() {
        for (i in 0 until content.childCount) {
            val c = content.getChildAt(i)
            if (c is WebView) c.onPause()
        }
        content.removeAllViews()
        if (address.hasFocus()) root.requestFocus()
        hideFindBar()
        updateProgress(100)

        val t = current()
        if (t.webView == null && t.url.isNotEmpty()) {
            val created = createWebView(t)
            created.loadUrl(t.url)
        }
        val wv = t.webView
        if (wv != null) {
            wv.onResume()
            content.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            content.addView(buildHome(t.incognito), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        refreshAll()
    }

    private fun refreshAll() {
        refreshTabStrip()
        refreshToolbar()
        refreshNav()
    }

    private fun refreshTabStrip() {
        tabStrip.removeAllViews()
        var selectedChip: View? = null
        for (i in tabs.indices) {
            val t = tabs[i]
            val selected = i == currentIndex
            val chip = LinearLayout(this)
            chip.orientation = LinearLayout.HORIZONTAL
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(10), 0, dp(4), 0)
            if (selected) {
                val r = dp(12).toFloat()
                val bg = GradientDrawable()
                bg.setColor(if (t.incognito) C_TOOLBAR_INCOGNITO else C_TOOLBAR)
                bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                chip.background = bg
                selectedChip = chip
            }

            val fav = ImageView(this)
            fav.setImageResource(if (t.incognito) R.drawable.ic_incognito else R.drawable.ic_globe)
            fav.setColorFilter(if (t.incognito) C_INCOGNITO else C_ACCENT_LIGHT)
            chip.addView(fav, LinearLayout.LayoutParams(dp(20), dp(20)))

            val title = TextView(this)
            title.text = tabTitle(t)
            title.setTextColor(if (selected) C_TEXT else C_MUTED)
            title.textSize = 14f
            title.setSingleLine(true)
            title.ellipsize = TextUtils.TruncateAt.END
            title.setPadding(dp(8), 0, dp(4), 0)
            title.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            chip.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

            val close = ImageView(this)
            close.setImageResource(R.drawable.ic_close)
            close.setColorFilter(C_TEXT)
            close.setPadding(dp(6), dp(6), dp(6), dp(6))
            close.setOnClickListener { closeTab(tabs.indexOf(t)) }
            chip.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))

            chip.setOnClickListener { selectTab(tabs.indexOf(t)) }
            val width = if (tabs.size == 1) dp(190) else dp(140)
            tabStrip.addView(chip, LinearLayout.LayoutParams(width, dp(40)))
        }
        val plusLp = LinearLayout.LayoutParams(dp(40), dp(40))
        tabStrip.addView(iconButton(R.drawable.ic_add, 40, 22, C_TEXT) { newTab(false) }, plusLp)

        val sel = selectedChip
        if (sel != null) {
            tabScroll.post { tabScroll.requestChildRectangleOnScreen(sel, android.graphics.Rect(0, 0, sel.width, sel.height), true) }
        }
    }

    private fun refreshToolbar() {
        val t = current()
        toolbar.setBackgroundColor(if (t.incognito) C_TOOLBAR_INCOGNITO else C_TOOLBAR)
        if (!address.hasFocus()) address.setText(t.url)
        val secure = t.url.isEmpty() || t.url.startsWith("https://")
        lockIcon.setColorFilter(if (secure) C_TEXT else C_WARN)
        val marked = t.url.isNotEmpty() && prefs.isBookmarked(t.url)
        starIcon.setImageResource(if (marked) R.drawable.ic_star else R.drawable.ic_star_border)
        starIcon.setColorFilter(if (marked) C_STAR else C_TEXT)
        val n = faDigits(tabs.size.toString())
        tabCountTop.text = n
        tabCountBottom.text = n
    }

    private fun refreshNav() {
        val wv = current().webView
        btnBack.alpha = if (wv != null) 1f else 0.35f
        btnForward.alpha = if (wv != null && wv.canGoForward()) 1f else 0.35f
    }

    private fun updateProgress(p: Int) {
        if (p in 1..99) {
            val lp = progressBar.layoutParams
            lp.width = rootFrame.width * p / 100
            progressBar.layoutParams = lp
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettings() {
        for (t in tabs) {
            val wv = t.webView
            if (wv != null) {
                wv.settings.javaScriptEnabled = prefs.javascriptEnabled()
                wv.settings.loadsImagesAutomatically = prefs.imagesEnabled()
                CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !prefs.blockThirdPartyCookies())
            }
        }
        val zoom = prefs.textZoom()
        val desktop = prefs.defaultDesktop()
        if (appliedZoom != -1 && zoom != appliedZoom) {
            for (t in tabs) {
                t.zoom = zoom
                t.webView?.settings?.textZoom = zoom
            }
        }
        if (appliedZoom != -1 && desktop != appliedDesktop) {
            for (t in tabs) {
                t.desktop = desktop
                val wv = t.webView
                if (wv != null) {
                    wv.settings.userAgentString = if (desktop) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
                    wv.reload()
                }
            }
        }
        appliedZoom = zoom
        appliedDesktop = desktop
    }

    // ------------------------------------------------------------------
    // Navigation
    // ------------------------------------------------------------------

    private fun resolveInput(raw: String): String? {
        val v = raw.trim()
        if (v.isEmpty()) return null
        val lower = v.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) return v
        if (!v.contains(" ") && v.contains(".") && !v.contains("://") && !lower.startsWith("javascript:")) {
            return "https://" + v
        }
        val index = prefs.searchEngine().coerceIn(0, ENGINES.size - 1)
        return ENGINES[index].second + Uri.encode(v)
    }

    private fun upgradeUrl(url: String): String {
        if (prefs.httpsOnly() && url.startsWith("http://", true)) return "https://" + url.substring(7)
        return url
    }

    private fun navigateInput(raw: String) {
        val target = resolveInput(raw) ?: return
        navigate(target)
    }

    private fun navigate(url: String) {
        val t = current()
        val target = upgradeUrl(url)
        t.url = target
        val wv = t.webView ?: createWebView(t)
        wv.loadUrl(target)
        showCurrent()
    }

    private fun goBack() {
        val wv = current().webView ?: return
        if (wv.canGoBack()) wv.goBack() else goHome()
    }

    private fun goForward() {
        val wv = current().webView ?: return
        if (wv.canGoForward()) wv.goForward()
    }

    private fun reload() {
        current().webView?.reload()
    }

    private fun goHome() {
        val t = current()
        destroyWebView(t)
        t.url = ""
        t.title = ""
        showCurrent()
        saveTabs()
    }

    private fun toggleBookmark() {
        val url = current().url
        if (url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        if (prefs.isBookmarked(url)) {
            prefs.removeBookmark(url)
            toast("نشانک حذف شد")
        } else {
            prefs.addBookmark(url)
            toast("نشانک افزوده شد")
        }
        refreshToolbar()
    }

    private fun focusAddress() {
        address.requestFocus()
        address.selectAll()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(address, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(rootFrame.windowToken, 0)
        root.requestFocus()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: ActivityNotFoundException) {
            toast("جست‌وجوی صوتی روی این دستگاه در دسترس نیست")
        }
    }

    private fun showFindBar() {
        if (current().webView == null) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideFindBar() {
        if (findBar.visibility != View.VISIBLE) return
        findBar.visibility = View.GONE
        current().webView?.clearMatches()
        findInput.setText("")
        findCount.text = ""
        hideKeyboard()
    }

    private fun sharePage() {
        val url = current().url
        if (url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(i, "اشتراک‌گذاری صفحه"))
    }

    private fun copyLink() {
        val url = current().url
        if (url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", url))
        toast("نشانی کپی شد")
    }

    private fun addShortcutFromPage() {
        val t = current()
        if (t.url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        val label = if (t.title.isNotEmpty()) t.title.take(16) else hostOf(t.url)
        saveShortcut(label, t.url)
    }

    private fun pinToLauncher() {
        val t = current()
        if (t.url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        if (Build.VERSION.SDK_INT < 26) {
            toast("این قابلیت به اندروید ۸ یا بالاتر نیاز دارد")
            return
        }
        try {
            val sm = getSystemService(ShortcutManager::class.java)
            if (sm == null || !sm.isRequestPinShortcutSupported) {
                toast("لانچر دستگاه از این قابلیت پشتیبانی نمی‌کند")
                return
            }
            val launch = Intent(this, MainActivity::class.java)
            launch.action = Intent.ACTION_VIEW
            launch.data = Uri.parse(t.url)
            val label = if (t.title.isNotEmpty()) t.title.take(20) else hostOf(t.url)
            val info = ShortcutInfo.Builder(this, "nova_" + t.url.hashCode())
                .setShortLabel(label)
                .setIcon(Icon.createWithResource(this, R.drawable.ic_launcher_square))
                .setIntent(launch)
                .build()
            sm.requestPinShortcut(info, null)
        } catch (e: Exception) {
            toast("افزودن به صفحه‌ی گوشی ممکن نشد")
        }
    }

    // ------------------------------------------------------------------
    // WebView
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        val wv = WebView(this)
        tab.webView = wv

        val s = wv.settings
        s.javaScriptEnabled = prefs.javascriptEnabled()
        s.domStorageEnabled = true
        s.loadsImagesAutomatically = prefs.imagesEnabled()
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.textZoom = tab.zoom
        if (tab.incognito) {
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.saveFormData = false
        }
        if (tab.desktop) s.userAgentString = DESKTOP_UA

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !prefs.blockThirdPartyCookies())

        wv.setFindListener { active, total, _ ->
            if (isCurrent(tab)) {
                val shown = if (total == 0) 0 else active + 1
                findCount.text = faDigits(shown.toString() + "/" + total.toString())
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return false
                val uri = request.url
                val scheme = uri.scheme
                if (scheme == "http") {
                    val full = uri.toString()
                    if (prefs.httpsOnly() && request.isForMainFrame && view != null && full.startsWith("http://", true)) {
                        view.loadUrl("https://" + full.substring(7))
                        return true
                    }
                    return false
                }
                if (scheme == "https" || scheme == "about" || scheme == "data" || scheme == "blob") {
                    return false
                }
                if (scheme == "intent") {
                    try {
                        val parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        val fallback = parsed.getStringExtra("browser_fallback_url")
                        if (fallback != null && view != null &&
                            (fallback.startsWith("https://") || fallback.startsWith("http://"))
                        ) {
                            view.loadUrl(fallback)
                        }
                    } catch (e: Exception) {
                        // ignore malformed intent links
                    }
                    return true
                }
                val external = scheme == "tel" || scheme == "mailto" || scheme == "sms" ||
                    scheme == "geo" || scheme == "market"
                if (external) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: Exception) {
                        toast("برنامه‌ای برای باز کردن این پیوند نیست")
                    }
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null) return
                tab.url = url
                if (isCurrent(tab)) {
                    refreshToolbar()
                    refreshNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == null) return
                tab.url = url
                if (!tab.incognito && (url.startsWith("http://") || url.startsWith("https://"))) {
                    prefs.addHistory(url)
                }
                saveTabs()
                if (isCurrent(tab)) {
                    refreshToolbar()
                    refreshNav()
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (view == null || request == null || !request.isForMainFrame) return
                val reason = if (error != null) error.description.toString() else "خطای نامشخص"
                showErrorPage(view, request.url.toString(), reason)
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                if (view != null) {
                    val failing = if (error != null) error.url else ""
                    showErrorPage(view, failing ?: "", "گواهی امنیتی این سایت معتبر نیست.")
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (isCurrent(tab)) updateProgress(newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: ""
                refreshTabStrip()
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                showCustomView(view, callback)
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                if (!isUserGesture || resultMsg == null) return false
                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                newTab(tab.incognito)
                val created = createWebView(current())
                transport.webView = created
                resultMsg.sendToTarget()
                showCurrent()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                val previous = fileCallback
                if (previous != null) previous.onReceiveValue(emptyArray<Uri>())
                fileCallback = filePathCallback
                return try {
                    val intent = if (fileChooserParams != null) {
                        fileChooserParams.createIntent()
                    } else {
                        val fallback = Intent(Intent.ACTION_GET_CONTENT)
                        fallback.type = "*/*"
                        fallback.addCategory(Intent.CATEGORY_OPENABLE)
                        fallback
                    }
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(PendingDownload(url, userAgent, contentDisposition, mimeType))
        }
        return wv
    }

    private fun showErrorPage(view: WebView, failingUrl: String, reason: String) {
        val html = "<html dir='rtl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
            "<body style='background:#0B0D26;color:#E8EAFF;font-family:sans-serif;text-align:center;padding:56px 24px'>" +
            "<h2>باز کردن این صفحه ممکن نیست</h2>" +
            "<p style='color:#9AA0D0'>" + TextUtils.htmlEncode(reason) + "</p>" +
            "<p dir='ltr' style='color:#9AA0D0;word-break:break-all;font-size:13px'>" + TextUtils.htmlEncode(failingUrl) + "</p>" +
            "</body></html>"
        view.loadDataWithBaseURL(failingUrl, html, "text/html", "UTF-8", failingUrl)
    }

    private fun showCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
        if (view == null) return
        if (customView != null) {
            callback?.onCustomViewHidden()
            return
        }
        customView = view
        customCallback = callback
        fullscreenHolder.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        fullscreenHolder.visibility = View.VISIBLE
        applyImmersive(true)
    }

    private fun hideCustomView() {
        val v = customView ?: return
        fullscreenHolder.removeView(v)
        fullscreenHolder.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        applyImmersive(false)
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive(on: Boolean) {
        val flags = if (on) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
        window.decorView.systemUiVisibility = flags
    }

    // ------------------------------------------------------------------
    // Downloads / activity results
    // ------------------------------------------------------------------

    private fun startDownload(d: PendingDownload) {
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = d
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        try {
            val name = URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType)
            val req = DownloadManager.Request(Uri.parse(d.url))
            if (!d.mimeType.isNullOrEmpty()) req.setMimeType(d.mimeType)
            if (!d.userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", d.userAgent)
            val cookie = CookieManager.getInstance().getCookie(d.url)
            if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            toast("دانلود شروع شد")
        } catch (e: Exception) {
            toast("دانلود این فایل ممکن نیست")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE) {
            val d = pendingDownload
            pendingDownload = null
            if (d != null && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDownload(d)
            } else {
                toast("برای دانلود، دسترسی به حافظه لازم است")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val cb = fileCallback
            fileCallback = null
            if (cb != null) {
                val r = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                if (r != null) cb.onReceiveValue(r) else cb.onReceiveValue(emptyArray<Uri>())
            }
        } else if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            val list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (list != null && list.isNotEmpty()) navigateInput(list[0])
        } else if (requestCode == REQ_PAGE && resultCode == RESULT_OK && data != null) {
            val url = data.getStringExtra("open_url")
            if (url != null) {
                if (data.getBooleanExtra("new_tab", false)) newTab(false)
                navigate(url)
            }
        }
    }

    // ------------------------------------------------------------------
    // Home page
    // ------------------------------------------------------------------

    private fun buildHome(incognito: Boolean): View {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(if (incognito) Color.parseColor("#120B26") else C_BG)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(28), dp(20), dp(24))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        col.addView(LogoView(this), LinearLayout.LayoutParams(dp(200), dp(114)))

        val title = TextView(this)
        title.text = if (incognito) "حالت ناشناس" else "مرورگر نوا"
        title.textSize = 32f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(if (incognito) C_INCOGNITO else C_TITLE)
        title.gravity = Gravity.CENTER
        col.addView(title, LinearLayout.LayoutParams(WRAP, WRAP))

        val tag = TextView(this)
        tag.textSize = 17f
        tag.gravity = Gravity.CENTER
        if (incognito) {
            tag.text = "صفحه‌هایی که اینجا می‌بینید در تاریخچه ذخیره نمی‌شوند"
            tag.setTextColor(C_MUTED)
            tag.textSize = 14f
        } else {
            val sb = SpannableStringBuilder()
            fun part(text: String, color: Int) {
                val start = sb.length
                sb.append(text)
                sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            part("سریع", C_TAG1)
            part("  •  ", C_MUTED)
            part("امن", C_TAG2)
            part("  •  ", C_MUTED)
            part("قدرتمند", C_TAG3)
            tag.text = sb
        }
        col.addView(tag, LinearLayout.LayoutParams(WRAP, WRAP))

        // search pill
        val engineIndex = prefs.searchEngine().coerceIn(0, ENGINES.size - 1)
        val search = LinearLayout(this)
        search.orientation = LinearLayout.HORIZONTAL
        search.gravity = Gravity.CENTER_VERTICAL
        search.background = roundRect(C_PILL, 26, C_PILL_STROKE, 1)
        search.setPadding(dp(18), 0, dp(8), 0)

        val g = TextView(this)
        g.text = ENGINES[engineIndex].first.substring(0, 1)
        g.textSize = 22f
        g.typeface = Typeface.DEFAULT_BOLD
        g.setTextColor(ENGINE_COLORS[engineIndex])
        search.addView(g, LinearLayout.LayoutParams(WRAP, WRAP))

        val searchInput = EditText(this)
        searchInput.background = null
        searchInput.hint = "جست‌وجو با " + ENGINES[engineIndex].first
        searchInput.setHintTextColor(C_MUTED)
        searchInput.setTextColor(C_TEXT)
        searchInput.textSize = 17f
        searchInput.setSingleLine(true)
        searchInput.inputType = InputType.TYPE_CLASS_TEXT
        searchInput.imeOptions = EditorInfo.IME_ACTION_GO
        searchInput.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        searchInput.setPadding(dp(14), 0, dp(8), 0)
        searchInput.setOnEditorActionListener { v, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                val raw = v.text.toString()
                hideKeyboard()
                navigateInput(raw)
                true
            } else {
                false
            }
        }
        search.addView(searchInput, LinearLayout.LayoutParams(0, MATCH, 1f))

        val mic = ImageView(this)
        mic.setImageResource(R.drawable.ic_mic)
        mic.setColorFilter(C_MUTED)
        mic.setPadding(dp(10), dp(10), dp(10), dp(10))
        mic.setOnClickListener { startVoice() }
        search.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        search.setOnClickListener {
            searchInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }

        val searchLp = LinearLayout.LayoutParams(MATCH, dp(52))
        searchLp.topMargin = dp(26)
        col.addView(search, searchLp)

        if (!incognito) {
            val featureTitle = TextView(this).apply {
                text = "ابزارهای نوا"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(C_TITLE)
                setPadding(0, dp(18), 0, dp(8))
            }
            col.addView(featureTitle, LinearLayout.LayoutParams(MATCH, WRAP))
            val featureRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun featureButton(label: String, subtitle: String, action: () -> Unit) = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
                setPadding(dp(6), dp(12), dp(6), dp(12))
                isClickable = true
                isFocusable = true
                addView(TextView(this@MainActivity).apply { text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C_TITLE); gravity = Gravity.CENTER })
                addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 11f; setTextColor(C_MUTED); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
                setOnClickListener { action() }
            }
            featureRow.addView(featureButton("Nova AI", "گفت‌وگو و تصویر") { startActivity(Intent(this, NovaAiActivity::class.java)) }, LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginEnd = dp(5) })
            featureRow.addView(featureButton("استودیو ۳D", "نمایش مدل GLB") { startActivity(Intent(this, Studio3DActivity::class.java)) }, LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
            featureRow.addView(featureButton("فایل‌ها", "مدیریت و پیش‌نمایش") { startActivity(Intent(this, FileCenterActivity::class.java)) }, LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginStart = dp(5) })
            col.addView(featureRow, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        if (incognito) return scroll

        // shortcuts
        val tiles = ArrayList<View>()
        for (entry in prefs.shortcuts()) {
            val def = shortcutDef(entry)
            val cell = makeTile(def.label, def.glyph, def.bg, def.fg, 0) { navigate(def.url) }
            cell.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(def.label)
                    .setMessage("این میان‌بر حذف شود؟")
                    .setPositiveButton("حذف") { _, _ ->
                        prefs.removeShortcut(entry)
                        if (current().url.isEmpty()) showCurrent()
                    }
                    .setNegativeButton("انصراف", null)
                    .show()
                true
            }
            tiles.add(cell)
        }
        tiles.add(makeTile("افزودن", "", roundRect(C_PILL, 16), C_TEXT, R.drawable.ic_add) { showAddShortcutDialog() })

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        var start = 0
        while (start < tiles.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 4) {
                val idx = start + k
                val cellView: View = if (idx < tiles.size) tiles[idx] else View(this)
                row.addView(cellView, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            start += 4
        }
        val gridLp = LinearLayout.LayoutParams(MATCH, WRAP)
        gridLp.topMargin = dp(18)
        col.addView(grid, gridLp)

        // recently visited
        val recent = prefs.history().take(3)
        if (recent.isNotEmpty()) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = roundRect(C_PILL, 16, C_PILL_STROKE, 1)
            card.setPadding(dp(14), dp(10), dp(14), dp(10))

            val head = TextView(this)
            head.text = "اخیراً بازدید شده"
            head.textSize = 14f
            head.typeface = Typeface.DEFAULT_BOLD
            head.setTextColor(C_ACCENT_LIGHT)
            card.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

            for (u in recent) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(10), 0, dp(10))
                val icon = ImageView(this)
                icon.setImageResource(R.drawable.ic_history)
                icon.setColorFilter(C_MUTED)
                row.addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)))
                val label = TextView(this)
                label.text = hostOf(u)
                label.textSize = 16f
                label.setTextColor(C_TEXT)
                label.setSingleLine(true)
                label.ellipsize = TextUtils.TruncateAt.END
                label.textDirection = View.TEXT_DIRECTION_LTR
                label.setPadding(dp(12), 0, 0, 0)
                row.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
                row.setOnClickListener { navigate(u) }
                card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
            val cardLp = LinearLayout.LayoutParams(MATCH, WRAP)
            cardLp.topMargin = dp(14)
            col.addView(card, cardLp)
        }

        return scroll
    }

    private fun instagramBg(): Drawable {
        val d = GradientDrawable(
            GradientDrawable.Orientation.BL_TR,
            intArrayOf(Color.parseColor("#FEDA75"), Color.parseColor("#FA7E1E"), Color.parseColor("#D62976"), Color.parseColor("#4F5BD5"))
        )
        d.cornerRadius = dp(16).toFloat()
        return d
    }

    private fun makeTile(label: String, glyph: String, bg: Drawable, fg: Int, icon: Int, onClick: () -> Unit): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(0, dp(8), 0, dp(8))

        val box = FrameLayout(this)
        box.background = bg
        if (icon != 0) {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(fg)
            iv.setPadding(dp(18), dp(18), dp(18), dp(18))
            box.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            val tv = TextView(this)
            tv.text = glyph
            tv.textSize = if (glyph.length > 1) 20f else 28f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(fg)
            tv.gravity = Gravity.CENTER
            box.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        cell.addView(box, LinearLayout.LayoutParams(dp(60), dp(60)))

        val lb = TextView(this)
        lb.text = label
        lb.textSize = 12f
        lb.setTextColor(C_TEXT)
        lb.setSingleLine(true)
        lb.ellipsize = TextUtils.TruncateAt.END
        lb.gravity = Gravity.CENTER
        lb.setPadding(dp(2), dp(6), dp(2), 0)
        cell.addView(lb, LinearLayout.LayoutParams(MATCH, WRAP))

        cell.setOnClickListener { onClick() }
        return cell
    }

    private fun entryUrl(entry: String): String =
        if (entry.contains('\t')) entry.substringAfter('\t') else entry

    private fun entryLabel(entry: String): String {
        val l = entry.substringBefore('\t', "")
        return if (l.isEmpty()) hostOf(entryUrl(entry)) else l
    }

    private fun defaultShortcuts(): List<String> = listOf(
        "دک‌دک‌گو\thttps://duckduckgo.com",
        "گوگل\thttps://www.google.com",
        "ویکی‌پدیا\thttps://fa.wikipedia.org",
        "آپارات\thttps://www.aparat.com",
        "تلگرام\thttps://web.telegram.org",
        "گیت‌هاب\thttps://github.com",
        "اینستاگرام\thttps://www.instagram.com"
    )

    private fun ensureDefaultShortcuts() {
        // Repair empty/corrupt shortcut lists as well as first-run installs.
        if (!prefs.shortcutsInitialized() || prefs.shortcuts().isEmpty()) {
            prefs.setShortcuts(defaultShortcuts())
        }
    }

    private fun shortcutDef(entry: String): ShortcutDef {
        val label = entryLabel(entry)
        val url = entryUrl(entry)
        val host = hostOf(url).lowercase()
        return when {
            host.contains("google") ->
                ShortcutDef(label, url, "G", roundRect(Color.WHITE, 16), Color.parseColor("#4285F4"))
            host.contains("duckduckgo") ->
                ShortcutDef(label, url, "D", roundRect(Color.parseColor("#DE5833"), 16), Color.WHITE)
            host.contains("wikipedia") ->
                ShortcutDef(label, url, "W", roundRect(Color.WHITE, 16), Color.BLACK)
            host.contains("aparat") ->
                ShortcutDef(label, url, "آ", roundRect(Color.parseColor("#E4003A"), 16), Color.WHITE)
            host.contains("telegram") ->
                ShortcutDef(label, url, "T", roundRect(Color.parseColor("#229ED9"), 16), Color.WHITE)
            host.contains("github") ->
                ShortcutDef(label, url, "GH", roundRect(Color.parseColor("#0D1117"), 16), Color.WHITE)
            host.contains("instagram") ->
                ShortcutDef(label, url, "IG", instagramBg(), Color.WHITE)
            else ->
                ShortcutDef(label, url, label.substring(0, 1).uppercase(), roundRect(C_PILL, 16), C_TEXT)
        }
    }

    private fun saveShortcut(label: String, url: String) {
        for (e in prefs.shortcuts()) {
            if (entryUrl(e) == url) {
                toast("این میان‌بر قبلاً افزوده شده است")
                return
            }
        }
        prefs.addShortcut(label + "\t" + url)
        // Rebuild the home screen whenever it is currently visible. A WebView
        // can remain attached to a tab even after returning to the home UI.
        if (current().url.isEmpty()) showCurrent()
        toast("میان‌بر به صفحه‌ی اصلی افزوده شد")
    }

    private fun showAddShortcutDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val nameInput = EditText(this)
        nameInput.hint = "نام (اختیاری)"
        nameInput.setSingleLine(true)
        val urlInput = EditText(this)
        urlInput.hint = "example.com"
        urlInput.setSingleLine(true)
        urlInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        box.addView(nameInput, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(urlInput, LinearLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("افزودن میان‌بر")
            .setView(box)
            .setPositiveButton("افزودن") { _, _ ->
                val raw = urlInput.text.toString().trim()
                if (raw.isEmpty()) {
                    toast("نشانی را وارد کنید")
                } else {
                    val full = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://" + raw
                    val name = nameInput.text.toString().trim()
                    saveShortcut(if (name.isEmpty()) hostOf(full) else name, full)
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ------------------------------------------------------------------
    // Menu
    // ------------------------------------------------------------------

    private fun showMenu() {
        menuPopup?.dismiss()
        val screenW = resources.displayMetrics.widthPixels
        val width = minOf(dp(300), screenW - dp(24))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(0, dp(8), 0, dp(8))

        fun dismissMenu() {
            menuPopup?.dismiss()
        }

        fun newRow(icon: Int, label: String): LinearLayout {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), 0, dp(16), 0)
            row.background = rippleBg(false)
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(C_TEXT)
            row.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 16f
            tv.setTextColor(C_TEXT)
            tv.setSingleLine(true)
            tv.setPadding(dp(16), 0, dp(8), 0)
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            card.addView(row, LinearLayout.LayoutParams(MATCH, dp(46)))
            return row
        }

        fun addItem(icon: Int, label: String, hint: String?, action: () -> Unit) {
            val row = newRow(icon, label)
            if (hint != null) {
                val h = TextView(this)
                h.text = hint
                h.textSize = 13f
                h.setTextColor(C_MUTED)
                h.textDirection = View.TEXT_DIRECTION_LTR
                row.addView(h, LinearLayout.LayoutParams(WRAP, WRAP))
            }
            row.setOnClickListener {
                dismissMenu()
                action()
            }
        }

        fun addDivider() {
            val d = View(this)
            d.setBackgroundColor(C_DIVIDER)
            val lp = LinearLayout.LayoutParams(MATCH, dp(1))
            lp.setMargins(dp(16), dp(4), dp(16), dp(4))
            card.addView(d, lp)
        }

        addItem(R.drawable.ic_add_box, "تب جدید", "Ctrl+T") { newTab(false) }
        addItem(R.drawable.ic_incognito, "تب ناشناس جدید", null) { newTab(true) }
        addDivider()
        addItem(R.drawable.ic_star_border, "نشانک‌ها", "Ctrl+B") { startPage(BookmarksActivity::class.java) }
        addItem(R.drawable.ic_history, "تاریخچه", "Ctrl+H") { startPage(HistoryActivity::class.java) }
        addItem(R.drawable.ic_download, "دانلودها", "Ctrl+J") { startPage(DownloadsActivity::class.java) }
        addItem(R.drawable.ic_file, "مرکز فایل نوا", "پیش‌نمایش فایل‌ها و کدها") { startActivity(Intent(this, FileCenterActivity::class.java)) }
        addItem(R.drawable.ic_desktop, "Nova 3D Studio", "نمایش مدل‌های GLB") { startActivity(Intent(this, Studio3DActivity::class.java)) }
        addItem(R.drawable.ic_info, "دستیار هوشمند Nova AI", "گفت‌وگو و ساخت تصویر") { startActivity(Intent(this, NovaAiActivity::class.java)) }
        addItem(R.drawable.ic_delete, "پاک کردن داده‌های مرور", null) { startPage(PrivacyActivity::class.java) }
        addDivider()
        addItem(R.drawable.ic_refresh, "بارگذاری مجدد", "Ctrl+R") { reload() }
        addItem(R.drawable.ic_share, "اشتراک‌گذاری صفحه", null) { sharePage() }
        addItem(R.drawable.ic_copy, "کپی نشانی", null) { copyLink() }
        addItem(R.drawable.ic_search, "یافتن در صفحه", "Ctrl+F") { showFindBar() }
        addItem(R.drawable.ic_add, "افزودن به میان‌برهای نوا", null) { addShortcutFromPage() }
        addItem(R.drawable.ic_home, "افزودن به صفحه‌ی گوشی", null) { pinToLauncher() }
        addItem(R.drawable.ic_translate, "ترجمه‌ی صفحه…", null) { translatePage() }

        val deskRow = newRow(R.drawable.ic_desktop, "نسخه‌ی دسکتاپ")
        val deskCheck = CheckBox(this)
        deskCheck.isChecked = current().desktop
        deskCheck.isClickable = false
        deskCheck.isFocusable = false
        deskCheck.buttonTintList = ColorStateList.valueOf(C_TEXT)
        deskRow.addView(deskCheck, LinearLayout.LayoutParams(WRAP, WRAP))
        deskRow.setOnClickListener {
            dismissMenu()
            toggleDesktop()
        }

        val zoomRow = newRow(R.drawable.ic_search, "بزرگ‌نمایی")
        val minus = ImageView(this)
        minus.setImageResource(R.drawable.ic_remove)
        minus.setColorFilter(C_TEXT)
        minus.setPadding(dp(6), dp(6), dp(6), dp(6))
        val pct = TextView(this)
        pct.text = faDigits(current().zoom.toString()) + "٪"
        pct.textSize = 16f
        pct.setTextColor(C_TEXT)
        pct.gravity = Gravity.CENTER
        val plus = ImageView(this)
        plus.setImageResource(R.drawable.ic_add)
        plus.setColorFilter(C_TEXT)
        plus.setPadding(dp(6), dp(6), dp(6), dp(6))
        minus.setOnClickListener {
            changeZoom(-10)
            pct.text = faDigits(current().zoom.toString()) + "٪"
        }
        plus.setOnClickListener {
            changeZoom(10)
            pct.text = faDigits(current().zoom.toString()) + "٪"
        }
        zoomRow.addView(minus, LinearLayout.LayoutParams(dp(36), dp(36)))
        zoomRow.addView(pct, LinearLayout.LayoutParams(dp(60), WRAP))
        zoomRow.addView(plus, LinearLayout.LayoutParams(dp(36), dp(36)))

        addDivider()
        addItem(R.drawable.ic_settings, "تنظیمات", null) { startPage(SettingsActivity::class.java) }
        addItem(R.drawable.ic_shield, "حریم خصوصی و امنیت", null) { startPage(PrivacyActivity::class.java) }
        addItem(R.drawable.ic_info, "درباره‌ی مرورگر نوا", null) { startPage(AboutActivity::class.java) }
        addItem(R.drawable.ic_exit, "خروج", null) { finishAffinity() }

        val scroll = ScrollView(this)
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL
        scroll.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        scroll.background = roundRect(C_MENU, 18, C_MENU_STROKE, 1)

        card.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxH = resources.displayMetrics.heightPixels - dp(120)
        val height = minOf(card.measuredHeight, maxH)

        val popup = PopupWindow(scroll, width, height, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(10).toFloat()
        popup.isOutsideTouchable = true
        menuPopup = popup
        popup.showAtLocation(rootFrame, Gravity.TOP or Gravity.LEFT, dp(8), tabRow.paddingTop + dp(46))
    }

    private fun changeZoom(delta: Int) {
        val t = current()
        t.zoom = (t.zoom + delta).coerceIn(50, 300)
        val wv = t.webView
        if (wv != null) wv.settings.textZoom = t.zoom
    }

    private fun toggleDesktop() {
        val t = current()
        t.desktop = !t.desktop
        val wv = t.webView
        if (wv != null) {
            if (t.desktop) {
                wv.settings.userAgentString = DESKTOP_UA
            } else {
                wv.settings.userAgentString = WebSettings.getDefaultUserAgent(this)
            }
            wv.reload()
        }
    }

    private fun translatePage() {
        val url = current().url
        if (url.isEmpty()) {
            toast("ابتدا یک صفحه باز کنید")
            return
        }
        navigate("https://www.translatetheweb.net/?from=&to=fa&a=" + Uri.encode(url))
    }

    // ------------------------------------------------------------------
    // Tab switcher dialog
    // ------------------------------------------------------------------

    private fun showTabSwitcher() {
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))

        val dialog = AlertDialog.Builder(this)
            .setTitle("تب‌ها")
            .setView(scroll)
            .setPositiveButton("تب جدید") { _, _ -> newTab(false) }
            .setNeutralButton("ناشناس") { _, _ -> newTab(true) }
            .setNegativeButton("بستن", null)
            .create()

        fun fill() {
            list.removeAllViews()
            for (i in tabs.indices) {
                val t = tabs[i]
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(8), dp(8), dp(8))
                if (i == currentIndex) row.setBackgroundColor(Color.parseColor("#22FFFFFF"))

                val icon = ImageView(this)
                icon.setImageResource(if (t.incognito) R.drawable.ic_incognito else R.drawable.ic_globe)
                icon.setColorFilter(if (t.incognito) C_INCOGNITO else C_ACCENT_LIGHT)
                row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))

                val texts = LinearLayout(this)
                texts.orientation = LinearLayout.VERTICAL
                texts.setPadding(dp(12), 0, dp(8), 0)
                val tt = TextView(this)
                tt.text = tabTitle(t)
                tt.textSize = 15f
                tt.setTextColor(Color.WHITE)
                tt.setSingleLine(true)
                tt.ellipsize = TextUtils.TruncateAt.END
                texts.addView(tt)
                val tu = TextView(this)
                tu.text = if (t.url.isEmpty()) "برگه‌ی جدید" else t.url
                tu.textSize = 12f
                tu.setTextColor(Color.parseColor("#AAAAAA"))
                tu.setSingleLine(true)
                tu.ellipsize = TextUtils.TruncateAt.END
                tu.textDirection = View.TEXT_DIRECTION_LTR
                texts.addView(tu)
                row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

                val close = ImageView(this)
                close.setImageResource(R.drawable.ic_close)
                close.setColorFilter(Color.WHITE)
                close.setPadding(dp(8), dp(8), dp(8), dp(8))
                close.setOnClickListener {
                    closeTab(tabs.indexOf(t))
                    fill()
                }
                row.addView(close, LinearLayout.LayoutParams(dp(40), dp(40)))

                row.setOnClickListener {
                    dialog.dismiss()
                    selectTab(tabs.indexOf(t))
                }
                list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }

        fill()
        dialog.show()
    }
}
