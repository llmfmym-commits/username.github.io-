package com.nova.browser

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Lightweight GLB viewer built on Google's model-viewer Web Component. */
class Studio3DActivity : Activity() {
    private lateinit var viewer: WebView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C_BG); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(C_STRIP) }
        header.addView(TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(C_TEXT); setPadding(dp(8), 0, dp(16), 0); setOnClickListener { finish() } })
        header.addView(TextView(this).apply { text = "Nova 3D Studio"; textSize = 19f; setTextColor(C_TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(Button(this).apply { text = "باز کردن GLB"; setOnClickListener { chooseModel() } })
        root.addView(header)
        status = TextView(this).apply { text = "یک فایل با پسوند GLB انتخاب کن. برای بارگیری نمایشگر سه‌بعدی اینترنت لازم است."; setTextColor(C_MUTED); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        root.addView(status)
        viewer = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        root.addView(viewer, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(Button(this).apply { text = "بازنشانی دوربین"; setOnClickListener { viewer.evaluateJavascript("document.querySelector('model-viewer')?.resetTurntableRotation();document.querySelector('model-viewer')?.jumpCameraToGoal();", null) } })
        setContentView(root)
        showEmpty()
    }

    private fun chooseModel() {
        // Many Android document providers incorrectly label .glb as
        // application/octet-stream, so a strict model/gltf-binary filter hides it.
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(i, 7010)
    }

    @Deprecated("Activity result API kept dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7010 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val fileName = queryDisplayName(uri).lowercase()
                if (!fileName.endsWith(".glb")) throw IllegalArgumentException("فعلاً فقط فایل‌های .glb پشتیبانی می‌شوند")
                val bytes = contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192); var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count <= 0) break
                        total += count
                        if (total > 30 * 1024 * 1024) throw IllegalArgumentException("حجم فایل باید کمتر از ۳۰ مگابایت باشد")
                        out.write(buffer, 0, count)
                    }
                    out.toByteArray()
                } ?: throw IllegalStateException("فایل قابل خواندن نیست")
                if (bytes.size < 12 || bytes[0] != 0x67.toByte() || bytes[1] != 0x6c.toByte() || bytes[2] != 0x54.toByte() || bytes[3] != 0x46.toByte()) {
                    throw IllegalArgumentException("ساختار فایل GLB معتبر نیست")
                }
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                runOnUiThread { loadModel(b64) }
            } catch (e: Exception) { runOnUiThread { toast("خطا در بارگذاری مدل: ${e.message}") } }
        }.start()
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: uri.lastPathSegment.orEmpty() else uri.lastPathSegment.orEmpty()
            } ?: uri.lastPathSegment.orEmpty()
        } catch (_: Exception) { uri.lastPathSegment.orEmpty() }
    }

    private fun showEmpty() {
        viewer.loadDataWithBaseURL("https://modelviewer.dev/", """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;background:#090b20;color:#cbd0ff;font:16px sans-serif;display:grid;place-items:center;height:100vh;text-align:center">
            <div>برای شروع، یک فایل <b>GLB</b> انتخاب کن.<br><small>چرخش، بزرگ‌نمایی و تغییر زاویه دوربین پشتیبانی می‌شود.</small></div></body></html>
        """.trimIndent(), "text/html", "UTF-8", null)
    }

    private fun loadModel(base64: String) {
        status.text = "در حال آماده‌سازی مدل سه‌بعدی…"
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
            <script type="module">
              const show = (s) => { const e=document.getElementById('msg'); if(e) e.textContent=s; };
              const script=document.createElement('script');
              script.type='module';
              script.src='https://ajax.googleapis.com/ajax/libs/model-viewer/4.0.0/model-viewer.min.js';
              script.onerror=()=>show('بارگیری موتور سه‌بعدی ناموفق بود. اتصال اینترنت را بررسی کن.');
              script.onload=async()=>{
                try {
                  await customElements.whenDefined('model-viewer');
                  const mv=document.createElement('model-viewer');
                  mv.setAttribute('camera-controls',''); mv.setAttribute('touch-action','pan-y');
                  mv.setAttribute('auto-rotate',''); mv.setAttribute('shadow-intensity','1');
                  mv.setAttribute('exposure','1'); mv.setAttribute('environment-image','neutral');
                  mv.style.cssText='width:100%;height:100%;background:#090b20';
                  mv.addEventListener('load',()=>show('مدل آماده است؛ با انگشت بچرخان و بزرگ‌نمایی کن.'));
                  mv.addEventListener('error',()=>show('مدل بارگیری نشد؛ ممکن است فایل GLB خراب یا ناسازگار باشد.'));
                  mv.src='data:model/gltf-binary;base64,$base64';
                  document.body.appendChild(mv);
                } catch(e) { show('خطا در راه‌اندازی نمایشگر سه‌بعدی: '+e); }
              };
              document.head.appendChild(script);
            </script>
            <style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#090b20}#msg{position:absolute;z-index:2;top:8px;left:8px;right:8px;color:#cbd0ff;font:13px sans-serif;text-align:center;pointer-events:none}</style></head>
            <body><div id="msg">در حال بارگیری موتور سه‌بعدی…</div></body></html>
        """.trimIndent()
        viewer.loadDataWithBaseURL("https://modelviewer.dev/", html, "text/html", "UTF-8", null)
    }
}
