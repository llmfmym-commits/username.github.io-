# مرورگر نوا — نسخه 0.4.1

## تغییرات 0.4.0
- لوگوی اصلی طرح (برش‌خورده از اسکرین‌شات) برای آیکون برنامه، صفحه‌ی اصلی و درباره
- کادر جست‌وجوی صفحه‌ی اصلی حالا واقعاً همان‌جا تایپ می‌شود (نه در نوار بالا)
- میان‌برها: همه‌ی میان‌برها (حتی پیش‌فرض‌ها) قابل افزودن و حذف (نگه داشتن) هستند و بلافاصله اعمال می‌شوند؛ افزودن از صفحه‌ی فعلی؛ افزودن به صفحه‌ی گوشی
- گوگل به فهرست موتورهای جست‌وجو و میان‌برها اضافه شد (پیش‌فرض همچنان DuckDuckGo)
- لینک‌ها مستقیم داخل نوا باز می‌شوند: target=_blank در تب جدید نوا، لینک‌های intent:// با آدرس جایگزین، دریافت لینک/متن از «اشتراک‌گذاری» سایر برنامه‌ها، ارتقای خودکار http به https (قابل خاموش شدن)
- تنظیمات اندازه‌ی متن و نسخه‌ی دسکتاپ فوراً روی تب‌های باز اعمال می‌شود

## افزوده‌های توسعه‌یافته پس از 0.4.0
- Nova AI: صفحه‌ی گفت‌وگو با مدل متنی Pollinations و تصویرساز Pollinations؛ کلید کاربر با AES-GCM و Android Keystore روی دستگاه رمزگذاری می‌شود.
- مرکز فایل نوا: انتخاب فایل با Storage Access Framework، فهرست فایل‌های اخیر، پیش‌نمایش متن/کد و تصویر، و باز کردن سایر انواع فایل با برنامه‌ی سازگار.
- Nova 3D Studio: انتخاب و نمایش مدل‌های GLB با model-viewer، چرخش، بزرگ‌نمایی و کنترل دوربین.
- دسترسی به سه بخش جدید از منوی اصلی مرورگر.

### نکات اتصال هوش مصنوعی
- سرویس Pollinations برای درخواست‌های تولیدی احراز هویت می‌خواهد و ممکن است از اعتبار حساب استفاده کند؛ «رایگان و نامحدود» فرض نشده است.
- برای اپ موبایل مسیر رسمی Pollinations Pay / BYOP توصیه می‌شود. این نسخه در حال حاضر دریافت توکن مجاز کاربر را از طریق ورود دستی پشتیبانی می‌کند؛ جریان کامل OAuth/PKCE هنوز در این نسخه پیاده‌سازی نشده است.
- کلید در کد منبع یا APK ثابت نشده و در Android Keystore رمزگذاری می‌شود. از کلید محدود با سقف مصرف استفاده کنید.
- نمایش 3D در این نسخه برای GLB تک‌فایلی است؛ فایل‌های glTF وابسته به چند فایل/بافت جداگانه هنوز پشتیبانی نمی‌شوند.

## وضعیت ساخت
این بسته از نظر ساختار فایل و XML بررسی می‌شود، اما تا زمان اجرای Gradle روی Android SDK، خروجی APK را نباید «ساخته و تست‌شده» دانست.

### امضای امن نسخه‌ی انتشار
فایل کلید خصوصی امضا در این بسته نگهداری نمی‌شود. برای ساخت Release قابل نصب روی نسخه‌ی قبلی، همان فایل JKS که نسخه‌ی قبلی را امضا کرده در GitHub Secrets نگهداری شود:
- `NOVA_KEYSTORE_BASE64`: خروجی Base64 فایل JKS
- `NOVA_KEYSTORE_PASSWORD`
- `NOVA_KEY_ALIAS`
- `NOVA_KEY_PASSWORD`

در Termux، از پوشه‌ای که فایل JKS در آن است دستور `base64 nova-release.jks | tr -d '\n'` را اجرا کن و خروجی را در Secret مربوطه قرار بده.

## 0.4.2 fixes

- Home shortcuts are repaired when the stored list is empty and the home screen is refreshed after adding/removing a shortcut.
- Nova AI, 3D Studio, and File Center are now exposed as visible home-screen launch tiles as well as menu items.
- The GLB picker accepts all document-provider MIME types (Android providers often mislabel `.glb` files), then validates the `.glb` extension and GLB magic header.
- The 3D viewer now reports library-load and model-load failures instead of displaying a false success state. Rendering still requires internet access to load Google's `model-viewer` library.

Build verification note: source/manifest/archive checks only; a full Android Gradle build and on-device test have not yet been run in this environment.


## 0.4.3 hotfixes
- Home shortcuts migrated to a new preference key and rendered immediately below the search field.
- Shortcut writes use synchronous SharedPreferences commit to avoid immediate read-after-write races.
- Pollinations connection uses the official device authorization flow; users do not manually paste an API secret. Generation still consumes the user's own Pollinations balance/allowance.

- The original `app/nova-release.jks` signing identity from the user-provided 0.4.0 project is retained for update compatibility. Keep this ZIP and keystore private; do not commit it to a public repository. CI can override signing values with NOVA_KEYSTORE_* environment variables.
