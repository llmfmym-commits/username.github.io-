plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nova.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.browser"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "0.4.3"
    }

    val novaStorePath = System.getenv("NOVA_KEYSTORE_PATH") ?: "nova-release.jks"
    val novaStorePassword = System.getenv("NOVA_KEYSTORE_PASSWORD") ?: "novabrowser"
    val novaKeyAlias = System.getenv("NOVA_KEY_ALIAS") ?: "nova"
    val novaKeyPassword = System.getenv("NOVA_KEY_PASSWORD") ?: "novabrowser"
    val localKeystore = file(novaStorePath)
    val hasNovaSigning = localKeystore.exists() &&
        novaStorePassword.isNotBlank() && novaKeyAlias.isNotBlank() && novaKeyPassword.isNotBlank()

    if (hasNovaSigning) {
        signingConfigs.create("nova") {
            storeFile = localKeystore
            storePassword = novaStorePassword
            keyAlias = novaKeyAlias
            keyPassword = novaKeyPassword
        }
    }

    buildTypes {
        getByName("debug") {
            if (hasNovaSigning) signingConfig = signingConfigs.getByName("nova")
        }
        getByName("release") {
            if (hasNovaSigning) signingConfig = signingConfigs.getByName("nova")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // No external libraries needed: the UI uses plain Android views.
}
