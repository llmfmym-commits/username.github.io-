package com.nova.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class BrowserPrefs {
    private static final String FILE = "nova_browser";
    private static final int MAX_HISTORY = 200;
    private static final String K_HISTORY = "history_v2";
    private static final String K_BOOKMARKS = "bookmarks_v2";
    private static final String K_SHORTCUTS = "shortcuts_v4";
    private static final String K_SHORTCUTS_OLD = "shortcuts_v3";
    private static final String K_TABS = "tabs_v2";

    private final SharedPreferences store;

    public BrowserPrefs(Context context) {
        store = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        migrateOldBookmarks();
        migrateOldShortcuts();
    }

    // ---- migration from 0.1.0 (bookmarks were a StringSet) ----
    private void migrateOldBookmarks() {
        if (store.contains(K_BOOKMARKS) || !store.contains("bookmarks")) return;
        try {
            Set<String> old = store.getStringSet("bookmarks", null);
            if (old != null) writeList(K_BOOKMARKS, new ArrayList<String>(old));
        } catch (ClassCastException e) {
            // ignore
        }
    }


    // Migrate shortcut data written by older Nova builds. Some early builds
    // stored a JSON string while others stored a StringSet.
    private void migrateOldShortcuts() {
        if (store.contains(K_SHORTCUTS)) return;
        ArrayList<String> migrated = new ArrayList<String>();
        String[] oldKeys = new String[] { K_SHORTCUTS_OLD, "shortcuts_v2", "shortcuts" };
        for (String key : oldKeys) {
            try {
                String raw = store.getString(key, null);
                if (raw != null) {
                    JSONArray arr = new JSONArray(raw);
                    for (int i = 0; i < arr.length(); i++) {
                        String value = arr.optString(i, "").trim();
                        if (!value.isEmpty() && !migrated.contains(value)) migrated.add(value);
                    }
                }
            } catch (Exception ignored) {
                try {
                    Set<String> oldSet = store.getStringSet(key, null);
                    if (oldSet != null) {
                        for (String value : oldSet) {
                            if (value != null && !value.trim().isEmpty() && !migrated.contains(value)) migrated.add(value);
                        }
                    }
                } catch (Exception ignoredAgain) { }
            }
        }
        if (!migrated.isEmpty()) writeList(K_SHORTCUTS, migrated);
    }

    // ---- JSON list helpers ----
    private List<String> readList(String key) {
        ArrayList<String> out = new ArrayList<String>();
        String raw = "[]";
        try { raw = store.getString(key, "[]"); }
        catch (ClassCastException ignored) { return out; }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String value = arr.optString(i, "");
                if (!value.trim().isEmpty()) out.add(value);
            }
        } catch (JSONException e) {
            // ignore broken data
        }
        return out;
    }

    private void writeList(String key, List<String> values) {
        JSONArray arr = new JSONArray();
        for (String v : values) arr.put(v);
        store.edit().putString(key, arr.toString()).commit();
    }

    // ---- last url (kept for compatibility) ----
    public void saveLastUrl(String url) {
        store.edit().putString("last_url", url).apply();
    }

    public String lastUrl() {
        return store.getString("last_url", "");
    }

    // ---- tabs ----
    public void saveTabs(List<String> urls, int current) {
        writeList(K_TABS, urls);
        store.edit().putInt("current_tab", current).apply();
    }

    public List<String> tabs() {
        return readList(K_TABS);
    }

    public int currentTab() {
        return store.getInt("current_tab", 0);
    }

    // ---- history (newest first) ----
    public void addHistory(String url) {
        List<String> values = readList(K_HISTORY);
        values.remove(url);
        values.add(0, url);
        while (values.size() > MAX_HISTORY) values.remove(values.size() - 1);
        writeList(K_HISTORY, values);
    }

    public List<String> history() {
        return readList(K_HISTORY);
    }

    public void clearHistory() {
        store.edit().remove(K_HISTORY).apply();
    }

    // ---- bookmarks ----
    public List<String> bookmarks() {
        return readList(K_BOOKMARKS);
    }

    public boolean isBookmarked(String url) {
        return url != null && readList(K_BOOKMARKS).contains(url);
    }

    public void addBookmark(String url) {
        List<String> values = readList(K_BOOKMARKS);
        if (!values.contains(url)) {
            values.add(0, url);
            writeList(K_BOOKMARKS, values);
        }
    }

    public void removeBookmark(String url) {
        List<String> values = readList(K_BOOKMARKS);
        values.remove(url);
        writeList(K_BOOKMARKS, values);
    }

    public void clearBookmarks() {
        store.edit().remove(K_BOOKMARKS).apply();
    }

    // ---- custom home shortcuts ----
    public List<String> shortcuts() {
        return readList(K_SHORTCUTS);
    }

    public void addShortcut(String url) {
        List<String> values = readList(K_SHORTCUTS);
        if (!values.contains(url)) {
            values.add(url);
            writeList(K_SHORTCUTS, values);
        }
    }

    public void removeShortcut(String url) {
        List<String> values = readList(K_SHORTCUTS);
        values.remove(url);
        writeList(K_SHORTCUTS, values);
    }

    // ---- settings ----
    public int searchEngine() {
        return store.getInt("search_engine_v2", 0);
    }

    public void setSearchEngine(int index) {
        store.edit().putInt("search_engine_v2", index).apply();
    }

    public boolean javascriptEnabled() {
        return store.getBoolean("javascript", true);
    }

    public void setJavascriptEnabled(boolean value) {
        store.edit().putBoolean("javascript", value).apply();
    }

    public boolean blockThirdPartyCookies() {
        return store.getBoolean("block_3p_cookies", true);
    }

    public void setBlockThirdPartyCookies(boolean value) {
        store.edit().putBoolean("block_3p_cookies", value).apply();
    }

    public boolean imagesEnabled() {
        return store.getBoolean("images", true);
    }

    public void setImagesEnabled(boolean value) {
        store.edit().putBoolean("images", value).apply();
    }

    public boolean defaultDesktop() {
        return store.getBoolean("default_desktop", false);
    }

    public void setDefaultDesktop(boolean value) {
        store.edit().putBoolean("default_desktop", value).apply();
    }

    public boolean restoreTabsEnabled() {
        return store.getBoolean("restore_tabs", true);
    }

    public void setRestoreTabsEnabled(boolean value) {
        store.edit().putBoolean("restore_tabs", value).apply();
    }

    public int textZoom() {
        return store.getInt("text_zoom", 100);
    }

    public void setTextZoom(int value) {
        store.edit().putInt("text_zoom", value).apply();
    }

    public boolean clearOnExit() {
        return store.getBoolean("clear_on_exit", false);
    }

    public void setClearOnExit(boolean value) {
        store.edit().putBoolean("clear_on_exit", value).apply();
    }

    public boolean shortcutsInitialized() {
        return store.contains(K_SHORTCUTS);
    }

    public void setShortcuts(List<String> values) {
        writeList(K_SHORTCUTS, values);
    }

    public boolean httpsOnly() {
        return store.getBoolean("https_only", true);
    }

    public void setHttpsOnly(boolean value) {
        store.edit().putBoolean("https_only", value).apply();
    }
}
