package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Nova AI: Pollinations text and image generation. Credentials are encrypted with Android Keystore. */
class NovaAiActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var content: LinearLayout
    private lateinit var chatLog: LinearLayout
    private lateinit var promptInput: EditText
    private lateinit var imagePrompt: EditText
    private lateinit var imagePreview: ImageView
    private var imageBytes: ByteArray? = null
    private lateinit var saveImageButton: Button
    private val conversation = ArrayList<JSONObject>()
    private var imageTab = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_STRIP
        window.navigationBarColor = C_BG
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(C_STRIP)
        }
        val back = TextView(this).apply { text = "‹"; textSize = 32f; setTextColor(C_TEXT); setPadding(dp(8), 0, dp(16), 0); setOnClickListener { finish() } }
        header.addView(back)
        header.addView(TextView(this).apply { text = "Nova AI"; textSize = 21f; setTextColor(C_TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, WRAP, 1f))
        val key = TextView(this).apply { text = if (ApiKeyStore.read(this@NovaAiActivity).isNullOrBlank()) "اتصال" else "متصل"; textSize = 13f; setTextColor(C_ACCENT_LIGHT); setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { showKeyDialog() } }
        header.addView(key)
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        tabs.addView(makeTab("گفت‌وگو", false), LinearLayout.LayoutParams(0, dp(44), 1f))
        tabs.addView(makeTab("ساخت تصویر", true), LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(tabs)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        renderChat()
    }

    private fun makeTab(label: String, isImage: Boolean): Button = Button(this).apply {
        text = label
        setTextColor(C_TEXT)
        setBackgroundColor(if (imageTab == isImage) C_ACCENT else C_PILL)
        setOnClickListener { imageTab = isImage; content.removeAllViews(); if (imageTab) renderImage() else renderChat() }
    }

    private fun renderChat() {
        content.removeAllViews()
        content.addView(TextView(this).apply { text = "دستیار هوشمند نوا"; textSize = 20f; setTextColor(C_TITLE); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        content.addView(TextView(this).apply { text = "برای استفاده، فقط حساب Pollinations را در صفحهٔ رسمی تأیید کن؛ نیازی به کپی یا واردکردن کلید API نیست. مصرف مدل‌ها از اعتبار حساب خودت کم می‌شود."; textSize = 13f; setTextColor(C_MUTED); setPadding(0, dp(4), 0, dp(12)) })
        if (ApiKeyStore.read(this).isNullOrBlank()) {
            content.addView(Button(this).apply { text = "اتصال به Pollinations بدون واردکردن کلید"; setOnClickListener { showKeyDialog() } })
        }
        chatLog = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(chatLog)
        promptInput = EditText(this).apply {
            hint = "پیامت را بنویس…"; setTextColor(C_TEXT); setHintTextColor(C_MUTED)
            setBackground(roundRect(C_PILL, 14, C_PILL_STROKE, 1)); setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 2; maxLines = 5
        }
        content.addView(promptInput, LinearLayout.LayoutParams(MATCH, WRAP))
        val send = Button(this).apply { text = "ارسال پیام"; setOnClickListener { sendChat() } }
        content.addView(send)
        if (conversation.isEmpty()) {
            addBubble("سلام! من دستیار هوشمند نوا هستم. چه کمکی از دستم برمی‌آید؟", false)
        } else {
            conversation.forEach { item -> addBubble(item.optString("content"), item.optString("role") == "user") }
        }
    }

    private fun addBubble(message: String, user: Boolean) {
        val bubble = TextView(this).apply {
            text = message; textSize = 15f; setTextColor(C_TEXT); setPadding(dp(12), dp(10), dp(12), dp(10))
            background = roundRect(if (user) 0xFF303B78.toInt() else C_PILL, 14)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) }
        chatLog.addView(bubble, lp)
    }

    private fun sendChat() {
        val prompt = promptInput.text.toString().trim()
        if (prompt.isEmpty()) return
        val key = ApiKeyStore.read(this)
        if (key.isNullOrBlank()) { showKeyDialog(); return }
        conversation.add(JSONObject().put("role", "user").put("content", prompt))
        addBubble(prompt, true)
        promptInput.setText("")
        val waiting = TextView(this).apply { text = "در حال دریافت پاسخ…"; setTextColor(C_MUTED); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        chatLog.addView(waiting)
        val messages = JSONArray()
        conversation.forEach { messages.put(it) }
        val payload = JSONObject().put("model", "openai/gpt-5.4-nano").put("messages", messages)
        worker.execute {
            val result = try {
                val response = request("https://gen.pollinations.ai/v1/chat/completions", "POST", key, payload.toString().toByteArray(Charsets.UTF_8), "application/json")
                val json = JSONObject(response.toString(Charsets.UTF_8))
                json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "پاسخی دریافت نشد.")
            } catch (e: Exception) { "خطا در ارتباط با سرویس: ${friendlyError(e)}" }
            runOnUiThread {
                chatLog.removeView(waiting)
                conversation.add(JSONObject().put("role", "assistant").put("content", result))
                addBubble(result, false)
            }
        }
    }

    private fun renderImage() {
        content.removeAllViews()
        content.addView(TextView(this).apply { text = "تصویرساز هوش مصنوعی"; textSize = 20f; setTextColor(C_TITLE); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        content.addView(TextView(this).apply { text = "توصیف تصویر را بنویس. مدل‌ها و هزینه/اعتبار مصرفی تابع سرویس Pollinations هستند."; textSize = 13f; setTextColor(C_MUTED); setPadding(0, dp(4), 0, dp(12)) })
        imagePrompt = EditText(this).apply {
            hint = "مثلاً: یک شهر آینده‌نگر در شب، نورهای نئونی، جزئیات سینمایی"; setTextColor(C_TEXT); setHintTextColor(C_MUTED)
            setBackground(roundRect(C_PILL, 14, C_PILL_STROKE, 1)); setPadding(dp(12), dp(12), dp(12), dp(12)); minLines = 3; maxLines = 6
        }
        content.addView(imagePrompt, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(Button(this).apply { text = "تولید تصویر"; setOnClickListener { generateImage() } })
        imagePreview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackground(roundRect(C_PILL, 14)); contentDescription = "تصویر تولیدشده" }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(12), 0, dp(8)) }
        content.addView(imagePreview, lp)
        saveImageButton = Button(this).apply { text = "ذخیره تصویر در گالری"; isEnabled = false; setOnClickListener { saveImage() } }
        content.addView(saveImageButton)
    }

    private fun generateImage() {
        val prompt = imagePrompt.text.toString().trim()
        if (prompt.isEmpty()) { toast("ابتدا توصیف تصویر را بنویس"); return }
        val key = ApiKeyStore.read(this)
        if (key.isNullOrBlank()) { showKeyDialog(); return }
        toast("درخواست تصویر ارسال شد…")
        val model = "black-forest-labs/flux.1-schnell"
        val encoded = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        worker.execute {
            try {
                val bytes = request("https://gen.pollinations.ai/image/$encoded?model=${URLEncoder.encode(model, "UTF-8")}", "GET", key, null, null)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IllegalStateException("خروجی تصویر قابل خواندن نیست")
                runOnUiThread {
                    imageBytes = bytes
                    imagePreview.setImageBitmap(bitmap)
                    saveImageButton.isEnabled = true
                    toast("تصویر آماده شد")
                }
            } catch (e: Exception) { runOnUiThread { toast("خطا: ${friendlyError(e)}") } }
        }
    }

    private fun saveImage() {
        val bytes = imageBytes ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "NovaAI-${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nova AI")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("امکان ساخت فایل نبود")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("امکان ذخیره فایل نبود")
            toast("تصویر در گالری ذخیره شد")
        } catch (e: Exception) { toast("ذخیره ناموفق: ${friendlyError(e)}") }
    }

    private fun showKeyDialog() {
        val status = TextView(this).apply {
            text = "برای اتصال، نوا یک کد یک‌بارمصرف می‌گیرد و صفحهٔ رسمی Pollinations را باز می‌کند. پس از تأیید حساب، اتصال خودکار انجام می‌شود؛ هیچ کلیدی را دستی وارد نمی‌کنی. درخواست‌ها از اعتبار حساب خودت استفاده می‌کنند."
            textSize = 14f; setTextColor(C_MUTED); setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        val dialog = AlertDialog.Builder(this).setTitle("اتصال امن به Pollinations")
            .setView(status).setNegativeButton("بستن", null).create()
        dialog.show()
        status.text = "در حال دریافت کد اتصال…"
        worker.execute {
            try {
                val codeResult = publicPost("https://enter.pollinations.ai/api/device/code", "{}".toByteArray(Charsets.UTF_8))
                if (codeResult.first !in 200..299) throw IllegalStateException("HTTP ${codeResult.first}: ${codeResult.second.toString(Charsets.UTF_8)}")
                val codeJson = JSONObject(codeResult.second.toString(Charsets.UTF_8))
                val deviceCode = codeJson.getString("device_code")
                val verifyUrl = codeJson.optString("verification_uri_complete").ifBlank { "https://enter.pollinations.ai/device" }
                val userCode = codeJson.optString("user_code")
                val interval = codeJson.optInt("interval", 5).coerceAtLeast(3)
                val expires = codeJson.optInt("expires_in", 1800).coerceAtLeast(60)
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    status.text = "کد اتصال: $userCode\n\nصفحهٔ تأیید را باز کن و اجازهٔ اتصال را بده. پس از تأیید، نوا خودکار متصل می‌شود."
                    dialog.setButton(AlertDialog.BUTTON_POSITIVE, "باز کردن صفحهٔ تأیید") { _, _ ->
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(verifyUrl)))
                    }
                    dialog.show()
                }
                val deadline = System.currentTimeMillis() + expires * 1000L
                var waitSeconds = interval
                while (!isFinishing && System.currentTimeMillis() < deadline) {
                    Thread.sleep(waitSeconds * 1000L)
                    val poll = publicPost("https://enter.pollinations.ai/api/device/token", JSONObject().put("device_code", deviceCode).toString().toByteArray(Charsets.UTF_8))
                    val pollJson = try { JSONObject(poll.second.toString(Charsets.UTF_8)) } catch (_: Exception) { JSONObject() }
                    if (poll.first in 200..299 && pollJson.has("access_token")) {
                        val token = pollJson.getString("access_token")
                        ApiKeyStore.write(this, token)
                        runOnUiThread {
                            if (!isFinishing) {
                                status.text = "اتصال با موفقیت برقرار شد."
                                toast("Pollinations متصل شد")
                                content.removeAllViews()
                                if (imageTab) renderImage() else renderChat()
                            }
                        }
                        return@execute
                    }
                    when (pollJson.optString("error")) {
                        "authorization_pending" -> Unit
                        "slow_down" -> waitSeconds += 5
                        "access_denied" -> throw IllegalStateException("درخواست اتصال رد شد")
                        "expired_token", "device_code_expired" -> throw IllegalStateException("کد اتصال منقضی شد؛ دوباره تلاش کن")
                        else -> if (poll.first !in 200..299) throw IllegalStateException(pollJson.optString("error_description", pollJson.optString("error", "HTTP ${poll.first}")))
                    }
                }
                if (System.currentTimeMillis() >= deadline) throw IllegalStateException("زمان کد اتصال تمام شد؛ دوباره تلاش کن")
            } catch (e: Exception) {
                runOnUiThread { if (!isFinishing) { status.text = "اتصال انجام نشد: ${friendlyError(e)}"; toast("اتصال Pollinations ناموفق بود") } }
            }
        }
    }

    private fun publicPost(url: String, body: ByteArray): Pair<Int, ByteArray> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }
        try {
            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            return Pair(code, bytes)
        } finally { conn.disconnect() }
    }

    private fun request(url: String, method: String, key: String, body: ByteArray?, contentType: String?): ByteArray {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 25000; readTimeout = 120000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Accept", if (contentType == null) "image/*" else "application/json")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", contentType); outputStream.use { it.write(body) } }
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) {
                val detail = try { JSONObject(bytes.toString(Charsets.UTF_8)).optString("error", "") } catch (_: Exception) { "" }
                throw IllegalStateException("HTTP $code ${detail.ifBlank { "پاسخ ناموفق سرویس" }}")
            }
            return bytes
        } finally { conn.disconnect() }
    }

    private fun friendlyError(e: Exception): String = when {
        e.message?.contains("HTTP 401") == true -> "مجوز اتصال معتبر نیست؛ دوباره اتصال را تأیید کن."
        e.message?.contains("HTTP 402") == true -> "اعتبار حساب Pollinations یا سقف مصرف تأییدشده تمام شده است."
        e is java.net.UnknownHostException -> "اتصال اینترنت یا DNS در دسترس نیست."
        else -> e.message ?: "خطای ناشناخته"
    }

    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}

/** AES/GCM credential storage backed by a non-exportable Android Keystore key. */
private object ApiKeyStore {
    private const val PREFS = "nova_ai_secure"
    private const val ENTRY = "pollinations_token"
    private const val ALIAS = "nova_ai_keystore_v1"

    fun write(activity: Activity, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        val encoded = android.util.Base64.encodeToString(packed, android.util.Base64.NO_WRAP)
        activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ENTRY, encoded).apply()
    }

    fun read(activity: Activity): String? {
        return try {
            val encoded = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ENTRY, null) ?: return null
            val packed = android.util.Base64.decode(encoded, android.util.Base64.NO_WRAP)
            if (packed.size <= 12) return null
            val iv = packed.copyOfRange(0, 12)
            val encrypted = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            ALIAS, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }
}
