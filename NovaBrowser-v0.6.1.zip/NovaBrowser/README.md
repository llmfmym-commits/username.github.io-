# مرورگر نوا — نسخه 0.6.0

## تازه‌ها
- **استودیوی پایتون ۳بعدی** (منو ← استودیوی پایتون ۳بعدی): کد پایتون بنویسید، مدل سه‌بعدی بسازید، در نمایشگر ببینید و به GLB / STL / OBJ ذخیره کنید.
  - کتابخانه‌ی `nova3d` (پایتون خالص): box, sphere, cylinder, cone, torus, extrude, revolve, tube, surface, heightmap, gear
  - move / rotate / scale / mirror / color، اجتماع و تفریق و اشتراک شکل‌ها (a + b ، a - b ، a & b)، polar و linear
  - ۷ نمونه‌کد، دکمه‌های میان‌بر نوشتن، کنسول، ذخیره و باز کردن فایل .py
  - پایتون با Pyodide داخل WebView اجرا می‌شود. بار اول از اینترنت بارگذاری می‌شود. برای آفلاین: پوشه‌ی Pyodide را در `app/src/main/assets/pyodide/` بگذارید (فایل `pyodide.js` باید همان‌جا باشد).
  - در ویرایشگر کد، فایل‌های .py دکمه‌ی «اجرا در استودیو» دارند.
- شناسه‌ی برنامه (applicationId) به `ir.noornavar.nova` تغییر کرد (برای مایکت). اگر باز هم تکراری بود، در `app/build.gradle.kts` مقدار `applicationId` را عوض کنید؛ کد برنامه تغییری نمی‌خواهد.
