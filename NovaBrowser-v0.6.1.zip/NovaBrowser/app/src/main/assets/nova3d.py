"""nova3d - tiny pure-Python 3D modelling library for Nova Browser.

Axes: X right, Y forward, Z up (units are free, e.g. millimetres).

Shapes:   box(w,d,h)  cube(s)  sphere(r)  cylinder(r,h)  cone(r,h)  torus(R,r)
          extrude(points,h)  revolve(profile)  tube(path,r)  surface(fn)
          heightmap(fn)  gear(teeth)
Move:     m.move(x,y,z)  m.rotate(x,y,z)  m.scale(s)  m.color("#ff8800")
Boolean:  a + b (union)   a - b (difference)   a & b (intersection)
Groups:   combine(a,b,...)  polar(m,n)  linear(m,n,dx,dy,dz)
Output:   scene(a, b, ...)  <- shows the shapes in the 3D viewer
"""
import math
import json
import sys

try:
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 6000))
except Exception:
    pass

_scene = []

_NAMES = {
    "red": (0.90, 0.22, 0.22), "green": (0.25, 0.75, 0.35), "blue": (0.25, 0.45, 0.95),
    "white": (0.95, 0.95, 0.95), "black": (0.08, 0.08, 0.08), "gray": (0.55, 0.55, 0.58),
    "grey": (0.55, 0.55, 0.58), "yellow": (0.98, 0.85, 0.20), "orange": (0.98, 0.55, 0.15),
    "purple": (0.60, 0.30, 0.85), "cyan": (0.20, 0.85, 0.90), "pink": (0.98, 0.50, 0.70),
    "brown": (0.55, 0.35, 0.20), "gold": (0.90, 0.72, 0.25),
}


def _reset():
    global _scene
    _scene = []


def _parse_color(c):
    if isinstance(c, str):
        s = c.strip().lower()
        if s in _NAMES:
            r, g, b = _NAMES[s]
            return (r, g, b, 1.0)
        if s.startswith("#"):
            s = s[1:]
        if len(s) == 3:
            s = "".join(ch * 2 for ch in s)
        if len(s) == 6:
            return (int(s[0:2], 16) / 255.0, int(s[2:4], 16) / 255.0, int(s[4:6], 16) / 255.0, 1.0)
        raise ValueError("unknown color: " + str(c))
    vals = list(c)
    if max(vals) > 1.0:
        vals = [v / 255.0 for v in vals]
    if len(vals) == 3:
        vals.append(1.0)
    return tuple(float(v) for v in vals[:4])


# ----------------------------------------------------------------------
# vector helpers
# ----------------------------------------------------------------------

def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _len(a):
    return math.sqrt(_dot(a, a))


def _norm(a):
    l = _len(a)
    if l < 1e-12:
        return (0.0, 0.0, 1.0)
    return (a[0] / l, a[1] / l, a[2] / l)


def _lerp(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


# ----------------------------------------------------------------------
# Mesh
# ----------------------------------------------------------------------

class Mesh:
    """A triangle mesh. Triangles are counter-clockwise seen from outside."""

    def __init__(self, tris=None, col=None):
        self.tris = tris if tris is not None else []
        self.col = col if col is not None else (0.62, 0.66, 0.95, 1.0)

    def copy(self):
        return Mesh(list(self.tris), self.col)

    def _map(self, f, flip=False):
        out = []
        for a, b, c in self.tris:
            if flip:
                out.append((f(a), f(c), f(b)))
            else:
                out.append((f(a), f(b), f(c)))
        return Mesh(out, self.col)

    def move(self, x=0, y=0, z=0):
        return self._map(lambda p: (p[0] + x, p[1] + y, p[2] + z))

    def scale(self, sx, sy=None, sz=None):
        if sy is None:
            sy = sx
        if sz is None:
            sz = sx
        flip = (sx * sy * sz) < 0
        return self._map(lambda p: (p[0] * sx, p[1] * sy, p[2] * sz), flip)

    def rotate(self, x=0, y=0, z=0):
        """Rotate by angles in degrees (applied in X, then Y, then Z order)."""
        ax, ay, az = math.radians(x), math.radians(y), math.radians(z)
        cx, sx_ = math.cos(ax), math.sin(ax)
        cy, sy_ = math.cos(ay), math.sin(ay)
        cz, sz_ = math.cos(az), math.sin(az)

        def f(p):
            px, py, pz = p
            py, pz = py * cx - pz * sx_, py * sx_ + pz * cx
            px, pz = px * cy + pz * sy_, -px * sy_ + pz * cy
            px, py = px * cz - py * sz_, px * sz_ + py * cz
            return (px, py, pz)

        return self._map(f)

    def color(self, c):
        m = Mesh(self.tris, _parse_color(c))
        return m

    def bounds(self):
        if not self.tris:
            return ((0, 0, 0), (0, 0, 0))
        xs, ys, zs = [], [], []
        for tri in self.tris:
            for p in tri:
                xs.append(p[0])
                ys.append(p[1])
                zs.append(p[2])
        return ((min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs)))

    def size(self):
        lo, hi = self.bounds()
        return (hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2])

    def volume(self):
        v = 0.0
        for a, b, c in self.tris:
            v += _dot(a, _cross(b, c))
        return v / 6.0

    def center(self):
        """Move the mesh so the middle of its bounding box is at the origin."""
        lo, hi = self.bounds()
        return self.move(-(lo[0] + hi[0]) / 2.0, -(lo[1] + hi[1]) / 2.0, -(lo[2] + hi[2]) / 2.0)

    def on_floor(self):
        """Move the mesh so its lowest point sits at z = 0."""
        lo, _ = self.bounds()
        return self.move(0, 0, -lo[2])

    def mirror(self, axis="x"):
        a = axis.lower()
        if a == "x":
            return self.scale(-1, 1, 1)
        if a == "y":
            return self.scale(1, -1, 1)
        return self.scale(1, 1, -1)

    def __add__(self, other):
        return _boolean(self, other, "union")

    def __sub__(self, other):
        return _boolean(self, other, "subtract")

    def __and__(self, other):
        return _boolean(self, other, "intersect")

    def __repr__(self):
        return "<Mesh %d triangles>" % len(self.tris)


# ----------------------------------------------------------------------
# primitives
# ----------------------------------------------------------------------

def _quad(a, b, c, d):
    return [(a, b, c), (a, c, d)]


def _grid(fn, nu, nv):
    """Triangles of a parametric surface fn(u, v), u and v in 0..1.
    Orientation: normal = dP/du x dP/dv."""
    pts = [[fn(i / float(nu), j / float(nv)) for j in range(nv + 1)] for i in range(nu + 1)]
    tris = []
    for i in range(nu):
        for j in range(nv):
            a = pts[i][j]
            b = pts[i + 1][j]
            c = pts[i + 1][j + 1]
            d = pts[i][j + 1]
            for t in ((a, b, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    return tris


def box(w=1.0, d=None, h=None, center=True):
    if d is None:
        d = w
    if h is None:
        h = w
    if center:
        x0, x1, y0, y1, z0, z1 = -w / 2.0, w / 2.0, -d / 2.0, d / 2.0, -h / 2.0, h / 2.0
    else:
        x0, x1, y0, y1, z0, z1 = 0.0, w, 0.0, d, 0.0, h
    t = []
    t += _quad((x0, y0, z0), (x0, y1, z0), (x1, y1, z0), (x1, y0, z0))
    t += _quad((x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1))
    t += _quad((x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1))
    t += _quad((x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0))
    t += _quad((x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0))
    t += _quad((x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1))
    return Mesh(t)


def cube(s=1.0, center=True):
    return box(s, s, s, center)


def sphere(r=1.0, seg=24):
    seg = max(6, int(seg))
    rings = max(3, seg // 2)

    def fn(u, v):
        th = math.pi * u
        ph = 2.0 * math.pi * v
        return (r * math.sin(th) * math.cos(ph), r * math.sin(th) * math.sin(ph), r * math.cos(th))

    return Mesh(_grid(fn, rings, seg))


def frustum(r1=1.0, r2=0.5, h=1.0, seg=32, center=True):
    seg = max(3, int(seg))
    z0 = -h / 2.0 if center else 0.0
    z1 = z0 + h

    def side(u, v):
        ph = 2.0 * math.pi * u
        r = r1 + (r2 - r1) * v
        return (r * math.cos(ph), r * math.sin(ph), z0 + h * v)

    tris = _grid(side, seg, 1)
    for i in range(seg):
        a0 = 2.0 * math.pi * i / seg
        a1 = 2.0 * math.pi * (i + 1) / seg
        if r2 > 1e-9:
            tris.append(((0.0, 0.0, z1), (r2 * math.cos(a0), r2 * math.sin(a0), z1), (r2 * math.cos(a1), r2 * math.sin(a1), z1)))
        if r1 > 1e-9:
            tris.append(((0.0, 0.0, z0), (r1 * math.cos(a1), r1 * math.sin(a1), z0), (r1 * math.cos(a0), r1 * math.sin(a0), z0)))
    return Mesh(tris)


def cylinder(r=1.0, h=1.0, seg=32, center=True):
    return frustum(r, r, h, seg, center)


def cone(r=1.0, h=1.0, seg=32, center=True):
    return frustum(r, 0.0, h, seg, center)


def torus(R=1.0, r=0.3, seg=32, rseg=16):
    def fn(u, v):
        th = 2.0 * math.pi * u
        ph = 2.0 * math.pi * v
        return ((R + r * math.cos(ph)) * math.cos(th), (R + r * math.cos(ph)) * math.sin(th), r * math.sin(ph))

    return Mesh(_grid(fn, int(seg), int(rseg)))


def _area2(poly):
    s = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        s += x0 * y1 - x1 * y0
    return s / 2.0


def _triangulate(poly):
    """Ear clipping for a simple counter-clockwise polygon. Returns index triples."""
    n = len(poly)
    idx = list(range(n))
    out = []

    def cross2(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    def inside(p, a, b, c):
        d1 = cross2(a, b, p)
        d2 = cross2(b, c, p)
        d3 = cross2(c, a, p)
        return d1 >= -1e-12 and d2 >= -1e-12 and d3 >= -1e-12

    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        clipped = False
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[(k - 1) % m], idx[k], idx[(k + 1) % m]
            a, b, c = poly[i0], poly[i1], poly[i2]
            if cross2(a, b, c) <= 1e-12:
                continue
            ok = True
            for j in idx:
                if j in (i0, i1, i2):
                    continue
                if inside(poly[j], a, b, c):
                    ok = False
                    break
            if ok:
                out.append((i0, i1, i2))
                idx.pop(k)
                clipped = True
                break
        if not clipped:
            # degenerate polygon: fall back to a fan
            for k in range(1, len(idx) - 1):
                out.append((idx[0], idx[k], idx[k + 1]))
            return out
    if len(idx) == 3:
        out.append((idx[0], idx[1], idx[2]))
    return out


def extrude(points, h=1.0, center=False):
    """Extrude a 2D polygon [(x, y), ...] upward by h."""
    poly = [(float(p[0]), float(p[1])) for p in points]
    if len(poly) < 3:
        raise ValueError("extrude needs at least 3 points")
    if _area2(poly) < 0:
        poly.reverse()
    z0 = -h / 2.0 if center else 0.0
    z1 = z0 + h
    tris = []
    for i0, i1, i2 in _triangulate(poly):
        a, b, c = poly[i0], poly[i1], poly[i2]
        tris.append(((a[0], a[1], z1), (b[0], b[1], z1), (c[0], c[1], z1)))
        tris.append(((a[0], a[1], z0), (c[0], c[1], z0), (b[0], b[1], z0)))
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        tris += _quad((a[0], a[1], z0), (b[0], b[1], z0), (b[0], b[1], z1), (a[0], a[1], z1))
    return Mesh(tris)


def revolve(profile, seg=48):
    """Spin a profile [(radius, z), ...] (bottom to top) around the Z axis."""
    prof = [(float(p[0]), float(p[1])) for p in profile]
    n = len(prof)
    if n < 2:
        raise ValueError("revolve needs at least 2 points")

    def fn(u, v):
        ph = 2.0 * math.pi * u
        k = v * (n - 1)
        i = min(int(k), n - 2)
        t = k - i
        r = prof[i][0] + (prof[i + 1][0] - prof[i][0]) * t
        z = prof[i][1] + (prof[i + 1][1] - prof[i][1]) * t
        return (r * math.cos(ph), r * math.sin(ph), z)

    # sample exactly on profile vertices
    seg = max(3, int(seg))
    rows = []
    for (r, z) in prof:
        rows.append([(r * math.cos(2.0 * math.pi * j / seg), r * math.sin(2.0 * math.pi * j / seg), z) for j in range(seg + 1)])
    tris = []
    for k in range(n - 1):
        for j in range(seg):
            a = rows[k][j]
            b = rows[k][j + 1]
            c = rows[k + 1][j + 1]
            d = rows[k + 1][j]
            for t in ((a, b, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    # surface above has normal along -(dphi x dprofile) check: build with outward orientation
    if prof[-1][1] < prof[0][1]:
        tris = [(a, c, b) for (a, b, c) in tris]
    # orientation of the generated quads is a,b,c with b = next angle: dphi x dprofile -> outward
    if prof[0][0] > 1e-9:
        z = prof[0][1]
        for j in range(seg):
            tris.append(((0.0, 0.0, z), rows[0][j + 1], rows[0][j]))
    if prof[-1][0] > 1e-9:
        z = prof[-1][1]
        for j in range(seg):
            tris.append(((0.0, 0.0, z), rows[-1][j], rows[-1][j + 1]))
    return Mesh(tris)


def tube(path, r=0.2, seg=12, caps=True):
    """Round pipe following a 3D path [(x, y, z), ...]."""
    pts = [(float(p[0]), float(p[1]), float(p[2])) for p in path]
    n = len(pts)
    if n < 2:
        raise ValueError("tube needs at least 2 points")
    tang = []
    for i in range(n):
        a = pts[max(i - 1, 0)]
        b = pts[min(i + 1, n - 1)]
        tang.append(_norm(_sub(b, a)))
    t0 = tang[0]
    helper = (0.0, 0.0, 1.0) if abs(t0[2]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = _norm(_cross(helper, t0))
    rings = []
    seg = max(3, int(seg))
    for i in range(n):
        t = tang[i]
        nrm = _sub(nrm, _mul(t, _dot(nrm, t)))
        nrm = _norm(nrm)
        b = _cross(t, nrm)
        ring = []
        for j in range(seg + 1):
            ph = 2.0 * math.pi * j / seg
            off = _add(_mul(nrm, r * math.cos(ph)), _mul(b, r * math.sin(ph)))
            ring.append(_add(pts[i], off))
        rings.append(ring)
    tris = []
    for i in range(n - 1):
        for j in range(seg):
            a = rings[i][j]
            b2 = rings[i][j + 1]
            c = rings[i + 1][j + 1]
            d = rings[i + 1][j]
            for t in ((a, b2, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    if caps:
        for j in range(seg):
            tris.append((pts[0], rings[0][j + 1], rings[0][j]))
            tris.append((pts[-1], rings[-1][j], rings[-1][j + 1]))
    return Mesh(tris)


def surface(fn, u=(0.0, 1.0), v=(0.0, 1.0), nu=40, nv=40):
    """Open parametric surface: fn(u, v) -> (x, y, z)."""
    u0, u1 = u
    v0, v1 = v

    def f(a, b):
        return fn(u0 + (u1 - u0) * a, v0 + (v1 - v0) * b)

    return Mesh(_grid(f, int(nu), int(nv)))


def heightmap(fn, x=(-5.0, 5.0), y=(-5.0, 5.0), n=40, base=0.0):
    """Solid terrain / math surface: height z = fn(x, y), flat bottom at z = base."""
    n = max(2, int(n))
    xs = [x[0] + (x[1] - x[0]) * i / n for i in range(n + 1)]
    ys = [y[0] + (y[1] - y[0]) * j / n for j in range(n + 1)]
    top = [[(xs[i], ys[j], float(fn(xs[i], ys[j]))) for j in range(n + 1)] for i in range(n + 1)]
    tris = []
    for i in range(n):
        for j in range(n):
            a, b, c, d = top[i][j], top[i + 1][j], top[i + 1][j + 1], top[i][j + 1]
            tris.append((a, b, c))
            tris.append((a, c, d))
            a0, b0, c0, d0 = (a[0], a[1], base), (b[0], b[1], base), (c[0], c[1], base), (d[0], d[1], base)
            tris.append((a0, c0, b0))
            tris.append((a0, d0, c0))

    def wall(p, q):
        tris.extend(_quad((p[0], p[1], base), (q[0], q[1], base), q, p))

    for i in range(n):
        wall(top[i][0], top[i + 1][0])
        wall(top[i + 1][n], top[i][n])
    for j in range(n):
        wall(top[n][j], top[n][j + 1])
        wall(top[0][j + 1], top[0][j])
    return Mesh(tris)


def gear(teeth=12, module=2.0, thickness=5.0, hole=0.0, pressure=0.25):
    """Simple spur gear with trapezoid teeth (flat on the XY plane)."""
    teeth = max(6, int(teeth))
    pitch_r = module * teeth / 2.0
    tip_r = pitch_r + module
    root_r = max(pitch_r - 1.25 * module, module * 0.5)
    pts = []
    step = 2.0 * math.pi / teeth
    for i in range(teeth):
        a = i * step
        w_root = step * 0.5
        w_tip = step * (0.5 - pressure)
        for (ang, rad) in ((-w_root / 2.0, root_r), (-w_tip / 2.0, tip_r), (w_tip / 2.0, tip_r), (w_root / 2.0, root_r)):
            pts.append(((rad) * math.cos(a + ang), (rad) * math.sin(a + ang)))
    g = extrude(pts, thickness, center=True)
    if hole > 0:
        g = g - cylinder(hole / 2.0, thickness * 2.0, 32)
    return g


# ----------------------------------------------------------------------
# groups
# ----------------------------------------------------------------------

def combine(*meshes):
    """Merge shapes without boolean maths (fast). Colour of the first is kept."""
    items = []
    for m in meshes:
        if isinstance(m, (list, tuple)):
            items.extend(m)
        else:
            items.append(m)
    tris = []
    for m in items:
        tris.extend(m.tris)
    return Mesh(tris, items[0].col if items else None)


def polar(mesh, n, axis="z"):
    """n copies rotated evenly around an axis through the origin."""
    out = []
    for i in range(int(n)):
        a = 360.0 * i / n
        if axis == "x":
            out.append(mesh.rotate(a, 0, 0))
        elif axis == "y":
            out.append(mesh.rotate(0, a, 0))
        else:
            out.append(mesh.rotate(0, 0, a))
    return out


def linear(mesh, n, dx=0.0, dy=0.0, dz=0.0):
    return [mesh.move(dx * i, dy * i, dz * i) for i in range(int(n))]


# ----------------------------------------------------------------------
# boolean operations (BSP trees)
# ----------------------------------------------------------------------

_EPS = 1e-5
_COPLANAR, _FRONT, _BACK, _SPANNING = 0, 1, 2, 3


class _Plane(object):
    __slots__ = ("n", "w")

    def __init__(self, n, w):
        self.n = n
        self.w = w

    def clone(self):
        return _Plane(self.n, self.w)

    def flip(self):
        self.n = (-self.n[0], -self.n[1], -self.n[2])
        self.w = -self.w

    def split(self, poly, cof, cob, front, back):
        ptype = 0
        types = []
        n = self.n
        w = self.w
        for v in poly.v:
            t = n[0] * v[0] + n[1] * v[1] + n[2] * v[2] - w
            typ = _BACK if t < -_EPS else (_FRONT if t > _EPS else _COPLANAR)
            ptype |= typ
            types.append(typ)
        if ptype == _COPLANAR:
            if _dot(n, poly.plane.n) > 0:
                cof.append(poly)
            else:
                cob.append(poly)
        elif ptype == _FRONT:
            front.append(poly)
        elif ptype == _BACK:
            back.append(poly)
        else:
            f = []
            b = []
            cnt = len(poly.v)
            for i in range(cnt):
                j = (i + 1) % cnt
                ti, tj = types[i], types[j]
                vi, vj = poly.v[i], poly.v[j]
                if ti != _BACK:
                    f.append(vi)
                if ti != _FRONT:
                    b.append(vi)
                if (ti | tj) == _SPANNING:
                    den = _dot(n, _sub(vj, vi))
                    t = (w - _dot(n, vi)) / den if abs(den) > 1e-15 else 0.5
                    v = _lerp(vi, vj, t)
                    f.append(v)
                    b.append(v)
            if len(f) >= 3:
                front.append(_Poly(f, poly.plane))
            if len(b) >= 3:
                back.append(_Poly(b, poly.plane))


class _Poly(object):
    __slots__ = ("v", "plane")

    def __init__(self, v, plane=None):
        self.v = v
        if plane is None:
            n = _norm(_cross(_sub(v[1], v[0]), _sub(v[2], v[0])))
            plane = _Plane(n, _dot(n, v[0]))
        self.plane = plane

    def clone(self):
        return _Poly(list(self.v), self.plane.clone())

    def flip(self):
        self.v.reverse()
        self.plane.flip()


class _Node(object):
    def __init__(self, polys=None):
        self.plane = None
        self.front = None
        self.back = None
        self.polys = []
        if polys:
            self.build(polys)

    def clone(self):
        n = _Node()
        n.plane = self.plane.clone() if self.plane else None
        n.front = self.front.clone() if self.front else None
        n.back = self.back.clone() if self.back else None
        n.polys = [p.clone() for p in self.polys]
        return n

    def invert(self):
        stack = [self]
        while stack:
            node = stack.pop()
            for p in node.polys:
                p.flip()
            if node.plane:
                node.plane.flip()
            node.front, node.back = node.back, node.front
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)

    def clip_polys(self, polys):
        if not self.plane:
            return list(polys)
        front = []
        back = []
        for p in polys:
            self.plane.split(p, front, back, front, back)
        if self.front:
            front = self.front.clip_polys(front)
        if self.back:
            back = self.back.clip_polys(back)
        else:
            back = []
        return front + back

    def clip_to(self, bsp):
        stack = [self]
        while stack:
            node = stack.pop()
            node.polys = bsp.clip_polys(node.polys)
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)

    def all_polys(self):
        out = []
        stack = [self]
        while stack:
            node = stack.pop()
            out.extend(node.polys)
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)
        return out

    def build(self, polys):
        stack = [(self, polys)]
        while stack:
            node, plist = stack.pop()
            if not plist:
                continue
            if node.plane is None:
                node.plane = plist[0].plane.clone()
            front = []
            back = []
            for p in plist:
                node.plane.split(p, node.polys, node.polys, front, back)
            if front:
                if node.front is None:
                    node.front = _Node()
                stack.append((node.front, front))
            if back:
                if node.back is None:
                    node.back = _Node()
                stack.append((node.back, back))


def _to_polys(mesh):
    out = []
    for a, b, c in mesh.tris:
        n = _cross(_sub(b, a), _sub(c, a))
        if _len(n) < 1e-12:
            continue
        out.append(_Poly([a, b, c]))
    return out


def _from_polys(polys, col):
    tris = []
    for p in polys:
        v = p.v
        for i in range(1, len(v) - 1):
            a, b, c = v[0], v[i], v[i + 1]
            if _len(_cross(_sub(b, a), _sub(c, a))) > 1e-14:
                tris.append((a, b, c))
    return Mesh(tris, col)


def _boolean(a, b, op):
    if not isinstance(b, Mesh):
        raise TypeError("boolean operations need two shapes")
    A = _Node(_to_polys(a))
    B = _Node(_to_polys(b))
    if op == "union":
        A.clip_to(B)
        B.clip_to(A)
        B.invert()
        B.clip_to(A)
        B.invert()
        A.build(B.all_polys())
    elif op == "subtract":
        A.invert()
        A.clip_to(B)
        B.clip_to(A)
        B.invert()
        B.clip_to(A)
        B.invert()
        A.build(B.all_polys())
        A.invert()
    else:
        A.invert()
        B.clip_to(A)
        B.invert()
        A.clip_to(B)
        B.clip_to(A)
        A.build(B.all_polys())
        A.invert()
    return _from_polys(A.all_polys(), a.col)


# ----------------------------------------------------------------------
# scene + export
# ----------------------------------------------------------------------

def scene(*meshes, **kw):
    """Send shapes to the 3D viewer. Lists are allowed: scene(polar(m, 6))."""
    names = kw.get("name")
    items = []
    for m in meshes:
        if isinstance(m, (list, tuple)):
            items.extend(m)
        else:
            items.append(m)
    for m in items:
        if not isinstance(m, Mesh):
            raise TypeError("scene() only accepts shapes (Mesh objects)")
        _scene.append((m, names if (names and len(items) == 1) else "shape_%d" % (len(_scene) + 1)))
    return None


show = scene


def _smooth_normals(tris, angle=50.0):
    fn = []
    for a, b, c in tris:
        n = _cross(_sub(b, a), _sub(c, a))
        l = _len(n)
        if l < 1e-14:
            fn.append(((0.0, 0.0, 1.0), 0.0))
        else:
            fn.append(((n[0] / l, n[1] / l, n[2] / l), l))

    def key(p):
        return (int(round(p[0] * 1e4)), int(round(p[1] * 1e4)), int(round(p[2] * 1e4)))

    groups = {}
    for i, tri in enumerate(tris):
        for p in tri:
            groups.setdefault(key(p), []).append(i)
    cos_t = math.cos(math.radians(angle))
    out = []
    for i, tri in enumerate(tris):
        ni = fn[i][0]
        for p in tri:
            sx = sy = sz = 0.0
            for j in groups[key(p)]:
                nj, aj = fn[j]
                if ni[0] * nj[0] + ni[1] * nj[1] + ni[2] * nj[2] >= cos_t:
                    sx += nj[0] * aj
                    sy += nj[1] * aj
                    sz += nj[2] * aj
            l = math.sqrt(sx * sx + sy * sy + sz * sz)
            if l < 1e-12:
                out.append(ni)
            else:
                out.append((sx / l, sy / l, sz / l))
    return out


def _export_json():
    meshes = []
    total = 0
    lo = [1e30, 1e30, 1e30]
    hi = [-1e30, -1e30, -1e30]
    vol = 0.0
    for m, name in _scene:
        if not m.tris:
            continue
        nor = _smooth_normals(m.tris)
        pos = []
        nrm = []
        k = 0
        for tri in m.tris:
            for p in tri:
                pos.extend((round(p[0], 4), round(p[1], 4), round(p[2], 4)))
                n = nor[k]
                nrm.extend((round(n[0], 3), round(n[1], 3), round(n[2], 3)))
                k += 1
                for ax in range(3):
                    if p[ax] < lo[ax]:
                        lo[ax] = p[ax]
                    if p[ax] > hi[ax]:
                        hi[ax] = p[ax]
        total += len(m.tris)
        vol += m.volume()
        meshes.append({"name": name, "positions": pos, "normals": nrm, "color": [round(c, 4) for c in m.col]})
    if not meshes:
        lo = [0, 0, 0]
        hi = [0, 0, 0]
    stats = {
        "shapes": len(meshes),
        "triangles": total,
        "size": [round(hi[i] - lo[i], 3) for i in range(3)],
        "volume": round(vol, 3),
    }
    return json.dumps({"meshes": meshes, "stats": stats})
