package com.nova.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * 3D viewer for GLB / GLTF models. Uses Google's <model-viewer> (Three.js / WebGL).
 * The library is loaded from a CDN unless a copy is placed in app/src/main/assets/model-viewer.min.js.
 */
class Viewer3DActivity : Activity() {
    private var webView: WebView? = null
    private var modelUri: Uri? = null
    private var modelMime = "model/gltf-binary"
    private var frame: ToolFrame? = null
    private var bottomBar: LinearLayout? = null
    private var loading: TextView? = null
    private var autoRotate = false
    private var envOn = true
    private var fullscreen = false
    private var bgIndex = 0
    private val backgrounds = listOf("#0B0D26", "#000000", "#FFFFFF", "#2B2B2B", "#1E3A5F")

    private val page = "<!doctype html><html><head><meta charset='utf-8'>" +
        "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<script type='module' src='__LIB__'></script>" +
        "<style>html,body{margin:0;height:100%;background:#0B0D26;overflow:hidden}" +
        "model-viewer{width:100%;height:100%;--progress-bar-color:#5B6CFF}</style></head><body>" +
        "<model-viewer id='mv' src='__SRC__' camera-controls touch-action='pan-y' shadow-intensity='1' " +
        "exposure='1' environment-image='neutral' interaction-prompt='none'></model-viewer>" +
        "<script>" +
        "var mv=document.getElementById('mv');" +
        "mv.addEventListener('error',function(){Nova.onError()});" +
        "mv.addEventListener('load',function(){Nova.onLoaded()});" +
        "setTimeout(function(){if(!customElements.get('model-viewer')){Nova.onNoLib()}},7000);" +
        "function setAuto(v){if(v){mv.setAttribute('auto-rotate','')}else{mv.removeAttribute('auto-rotate')}}" +
        "function setExposure(v){mv.exposure=v}" +
        "function setBg(c){document.body.style.background=c}" +
        "function setEnv(on){if(on){mv.setAttribute('environment-image','neutral')}else{mv.removeAttribute('environment-image')}}" +
        "function resetCam(){mv.cameraOrbit='auto auto auto';mv.cameraTarget='auto auto auto';mv.fieldOfView='auto'}" +
        "</script></body></html>"

    inner class Bridge {
        @JavascriptInterface
        fun onError() {
            runOnUiThread { toast("بارگذاری مدل ناموفق بود. فایل gltf باید همه‌ی منابعش را داخل خودش داشته باشد.") }
        }

        @JavascriptInterface
        fun onLoaded() {
            runOnUiThread { loading?.visibility = View.GONE }
        }

        @JavascriptInterface
        fun onNoLib() {
            runOnUiThread {
                loading?.text = "برای نمایش مدل در این نسخه اینترنت لازم است"
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val remote = intent.getStringExtra("remote_url")
        val local = intent.data
        if (remote == null && local == null) {
            toast("فایلی انتخاب نشده است")
            finish()
            return
        }
        modelUri = if (remote == null) local else null
        val name = intent.getStringExtra("name") ?: (if (local != null) displayName(local) else hostOf(remote ?: ""))
        if (name.lowercase().endsWith(".gltf")) modelMime = "model/gltf+json"

        val f = createToolFrame(name)
        frame = f
        f.header.addView(iconButton(R.drawable.ic_refresh, 44, 22, C_TEXT) {
            autoRotate = !autoRotate
            runJs("setAuto(" + autoRotate + ")")
        })
        f.header.addView(iconButton(R.drawable.ic_moon, 44, 22, C_TEXT) {
            bgIndex = (bgIndex + 1) % backgrounds.size
            runJs("setBg('" + backgrounds[bgIndex] + "')")
        })
        f.header.addView(iconButton(R.drawable.ic_globe, 44, 22, C_TEXT) {
            envOn = !envOn
            runJs("setEnv(" + envOn + ")")
            toast(if (envOn) "نورپردازی محیطی روشن" else "نورپردازی محیطی خاموش")
        })
        f.header.addView(iconButton(R.drawable.ic_home, 44, 22, C_TEXT) { runJs("resetCam()") })
        f.header.addView(iconButton(R.drawable.ic_fullscreen, 44, 22, C_TEXT) { toggleFullscreen() })

        val holder = FrameLayout(this)
        val wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#0B0D26"))
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        wv.addJavascriptInterface(Bridge(), "Nova")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                val u = request.url
                if (u.host != "nova.local") return null
                val path = u.path ?: return null
                val headers = HashMap<String, String>()
                headers["Access-Control-Allow-Origin"] = "*"
                try {
                    if (path == "/model.glb") {
                        val src = modelUri ?: return null
                        val stream = contentResolver.openInputStream(src) ?: return null
                        return WebResourceResponse(modelMime, null, 200, "OK", headers, stream)
                    }
                    if (path == "/model-viewer.min.js") {
                        val stream = assets.open("model-viewer.min.js")
                        return WebResourceResponse("text/javascript", "UTF-8", 200, "OK", headers, stream)
                    }
                } catch (e: Exception) {
                    return null
                }
                return null
            }
        }
        holder.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        val ld = TextView(this)
        ld.text = "در حال بارگذاری مدل…"
        ld.setTextColor(C_MUTED)
        ld.textSize = 15f
        ld.gravity = Gravity.CENTER
        holder.addView(ld, FrameLayout.LayoutParams(MATCH, MATCH))
        loading = ld
        webView = wv
        f.root.addView(holder, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // bottom controls: exposure
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(C_TOOLBAR)
        bar.setPadding(dp(16), dp(6), dp(16), dp(6))
        val label = TextView(this)
        label.text = "روشنایی"
        label.textSize = 14f
        label.setTextColor(C_TEXT)
        bar.addView(label, LinearLayout.LayoutParams(WRAP, WRAP))
        val seek = SeekBar(this)
        seek.max = 200
        seek.progress = 80
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = 0.2f + progress / 100f
                runJs("setExposure(" + v + ")")
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {
            }

            override fun onStopTrackingTouch(bar: SeekBar?) {
            }
        })
        bar.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        bottomBar = bar
        f.root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(f.root)

        val lib = try {
            assets.open("model-viewer.min.js").close()
            "https://nova.local/model-viewer.min.js"
        } catch (e: Exception) {
            "https://cdn.jsdelivr.net/npm/@google/model-viewer@3.5.0/dist/model-viewer.min.js"
        }
        val src = if (remote != null && remote.startsWith("https://")) remote else "https://nova.local/model.glb"
        val html = page.replace("__LIB__", lib).replace("__SRC__", src)
        wv.loadDataWithBaseURL("https://nova.local/", html, "text/html", "UTF-8", null)
    }

    private fun runJs(js: String) {
        webView?.evaluateJavascript(js, null)
    }

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        frame?.header?.visibility = if (fullscreen) View.GONE else View.VISIBLE
        bottomBar?.visibility = if (fullscreen) View.GONE else View.VISIBLE
        if (fullscreen) toast("برای خروج از تمام‌صفحه دکمه‌ی بازگشت را بزنید")
    }

    override fun onBackPressed() {
        if (fullscreen) {
            toggleFullscreen()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        val wv = webView
        if (wv != null) {
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        webView = null
        super.onDestroy()
    }
}
