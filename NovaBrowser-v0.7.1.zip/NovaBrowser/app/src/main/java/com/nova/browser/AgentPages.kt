package com.nova.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.zip.GZIPOutputStream

private const val REQ_TREE = 5001
private const val REQ_PERM = 5002
private const val REQ_ADD_FILES = 5003
private const val REQ_SAVE_SCRIPT = 5004

// ----------------------------------------------------------------------
// Assistant settings
// ----------------------------------------------------------------------

class AgentSettingsActivity : PageActivity() {
    override fun pageTitle(): String = "تنظیمات دستیار"

    override fun render() {
        heading("دستیارهای هوشمند")
        val list = AiStore.load(this)
        val active = AiStore.activeIndex(this).coerceIn(0, maxOf(0, list.size - 1))
        val c = card()
        if (list.isEmpty()) {
            val tv = TextView(this)
            tv.text = "هنوز دستیاری اضافه نشده است."
            tv.textSize = 14f
            tv.setTextColor(C_MUTED)
            tv.setPadding(dp(4), dp(12), dp(4), dp(12))
            c.addView(tv)
        }
        for (i in list.indices) {
            val p = list[i]
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(8), dp(0), dp(8))
            val mark = ImageView(this)
            mark.setImageResource(if (i == active) R.drawable.ic_check else R.drawable.ic_globe)
            mark.setColorFilter(if (i == active) C_TAG2 else C_MUTED)
            row.addView(mark, LinearLayout.LayoutParams(dp(22), dp(22)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(12), 0, dp(8), 0)
            val n = TextView(this)
            n.text = p.name
            n.textSize = 16f
            n.setTextColor(C_TEXT)
            col.addView(n)
            val d = TextView(this)
            d.text = (if (p.model.isEmpty()) "مدل انتخاب نشده" else p.model) + " • " + p.format
            d.textSize = 12f
            d.setTextColor(C_MUTED)
            d.textDirection = View.TEXT_DIRECTION_LTR
            col.addView(d)
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(iconButton(R.drawable.ic_settings, 40, 20, C_MUTED) { providerDialog(p, i) })
            row.addView(iconButton(R.drawable.ic_delete, 40, 20, C_DANGER) {
                confirm("«" + p.name + "» حذف شود؟", "حذف") {
                    list.removeAt(i)
                    AiStore.save(this, list)
                    AiStore.setActive(this, 0)
                    rerender()
                }
            })
            row.setOnClickListener {
                AiStore.setActive(this, i)
                rerender()
            }
            c.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        actionRow(c, R.drawable.ic_add, "افزودن دستیار", "OpenAI، Claude، Gemini، OpenRouter، مدل محلی و …", false) { choosePreset() }
        note("کلید API فقط روی همین گوشی و رمزنگاری‌شده ذخیره می‌شود و فقط به سرویسی که انتخاب کرده‌اید فرستاده می‌شود.")

        heading("پوشه‌ی پروژه")
        val ws = WorkspaceManager.get(this)
        val w = card()
        val label = TextView(this)
        label.text = ws.label()
        label.textSize = 14f
        label.setTextColor(C_TEXT)
        label.setPadding(dp(4), dp(10), dp(4), dp(6))
        w.addView(label)
        actionRow(w, R.drawable.ic_file, "انتخاب پوشه‌ی مشترک با Termux", "مثلاً Documents/NovaProjects", false) { pickTree() }
        if (WorkspaceManager.isShared(this)) {
            actionRow(w, R.drawable.ic_back, "بازگشت به پوشه‌ی داخلی نوا", null, false) {
                WorkspaceManager.setTree(this, null)
                rerender()
            }
        }
        note("در Termux مسیر پوشه‌ی مشترک چیزی شبیه ~/storage/shared/NovaProjects است. بعد از «termux-setup-storage» پوشه‌ها همان‌جا دیده می‌شوند.")

        heading("Termux")
        val t = card()
        val installed = TermuxBridge.isInstalled(this)
        val perm = installed && TermuxBridge.hasPermission(this)
        addStatus(t, "Termux نصب است", installed)
        addStatus(t, "مجوز اجرای دستور داده شده", perm)
        actionRow(t, R.drawable.ic_info, "راهنمای نصب و دستورها", "دستور نصب یک‌خطی، دستورهای nova و …", false) {
            startActivity(Intent(this, TermuxGuideActivity::class.java))
        }
        actionRow(t, R.drawable.ic_check, "درخواست مجوز اجرای دستور", null, false) { requestPerm() }
        actionRow(t, R.drawable.ic_play, "آزمایش اتصال", "یک دستور ساده در Termux اجرا می‌کند", false) { testTermux() }

        heading("رفتار دستیار")
        val b = card()
        switchRow(b, "نوشتن فایل بدون پرسیدن", "برای حذف فایل و دستور Termux همیشه اجازه می‌پرسد", AiStore.autoWrite(this)) {
            AiStore.setAutoWrite(this, it)
        }
    }

    private fun addStatus(parent: LinearLayout, text: String, ok: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(8), dp(4), dp(8))
        val iv = ImageView(this)
        iv.setImageResource(if (ok) R.drawable.ic_check else R.drawable.ic_close)
        iv.setColorFilter(if (ok) C_TAG2 else C_DANGER)
        row.addView(iv, LinearLayout.LayoutParams(dp(20), dp(20)))
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.setTextColor(C_TEXT)
        tv.setPadding(dp(12), 0, 0, 0)
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun pickTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        try {
            startActivityForResult(i, REQ_TREE)
        } catch (e: Exception) {
            toast("انتخاب پوشه ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE && resultCode == RESULT_OK && data != null) {
            val uri = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                WorkspaceManager.setTree(this, uri)
                toast("پوشه‌ی پروژه تنظیم شد")
            } catch (e: Exception) {
                toast("این پوشه قابل استفاده نیست؛ یک زیرپوشه بسازید و انتخاب کنید")
            }
        }
    }

    private fun requestPerm() {
        if (!TermuxBridge.isInstalled(this)) {
            toast("ابتدا Termux را نصب کنید")
            return
        }
        requestPermissions(arrayOf(TermuxBridge.PERMISSION), REQ_PERM)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toast("مجوز داده شد")
            } else {
                toast("اگر پنجره نیامد: تنظیمات اندروید ← برنامه‌ها ← نوا ← مجوزها ← «Run commands in Termux environment»")
            }
            rerender()
        }
    }

    private fun testTermux() {
        if (!TermuxBridge.isInstalled(this)) {
            toast("Termux نصب نیست")
            return
        }
        if (!TermuxBridge.hasPermission(this)) {
            toast("ابتدا مجوز را بدهید")
            return
        }
        toast("در حال آزمایش…")
        TermuxBridge.run(this, "echo nova-ok; python3 --version 2>&1; nova help 2>&1 | head -n 1", 60000L) { r ->
            val msg = if (r.ok) (r.stdout.trim().ifEmpty { "بدون خروجی" }) else ("خطا: " + r.error + "\nدر Termux باید allow-external-apps=true باشد و Termux یک‌بار بسته و باز شود.")
            AlertDialog.Builder(this).setTitle("نتیجه‌ی آزمایش").setMessage(msg).setPositiveButton("بستن", null).show()
        }
    }

    private fun choosePreset() {
        val labels = AI_PRESETS.map { (it.name + "\n" + it.hint) as CharSequence }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("سرویس دستیار")
            .setItems(labels) { _, which ->
                val pr = AI_PRESETS[which]
                providerDialog(AiProvider(pr.name, pr.format, pr.baseUrl, "", ""), -1)
            }
            .show()
    }

    private fun providerDialog(p: AiProvider, index: Int) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        fun field(hint: String, value: String, password: Boolean): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setText(value)
            e.setSingleLine(true)
            e.textDirection = View.TEXT_DIRECTION_LTR
            if (password) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            box.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
            return e
        }

        val name = field("نام نمایشی", p.name, false)
        val base = field("آدرس پایه (Base URL)", p.baseUrl, false)
        val model = field("نام مدل (یا «فهرست مدل‌ها» را بزنید)", p.model, false)
        val key = field(if (index >= 0 && p.encKey.isNotEmpty()) "کلید API (خالی = بدون تغییر)" else "کلید API", "", true)
        var format = p.format

        val fmtView = TextView(this)
        fmtView.textSize = 14f
        fmtView.setTextColor(C_ACCENT)
        fmtView.setPadding(0, dp(12), 0, dp(4))
        fun showFormat() {
            fmtView.text = "قالب API: " + format + "  (برای تغییر لمس کنید)"
        }
        showFormat()
        fmtView.setOnClickListener {
            format = if (format == "openai") "anthropic" else if (format == "anthropic") "gemini" else "openai"
            showFormat()
        }
        box.addView(fmtView, LinearLayout.LayoutParams(MATCH, WRAP))

        val listBtn = TextView(this)
        listBtn.text = "دریافت فهرست مدل‌ها از سرویس"
        listBtn.textSize = 14f
        listBtn.setTextColor(C_TAG2)
        listBtn.setPadding(0, dp(8), 0, dp(8))
        listBtn.setOnClickListener {
            val temp = AiProvider(name.text.toString(), format, base.text.toString(), model.text.toString(), "")
            val typed = key.text.toString().trim()
            if (typed.isNotEmpty()) temp.setKey(typed) else temp.encKey = p.encKey
            toast("در حال دریافت…")
            Thread {
                try {
                    val models = AiClient.listModels(temp)
                    runOnUiThread {
                        if (models.isEmpty()) {
                            toast("مدلی پیدا نشد")
                        } else {
                            val items = models.map { it as CharSequence }.toTypedArray()
                            AlertDialog.Builder(this)
                                .setTitle("مدل را انتخاب کنید")
                                .setItems(items) { _, w -> model.setText(models[w]) }
                                .show()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread { toast("خطا: " + (e.message ?: "")) }
                }
            }.start()
        }
        box.addView(listBtn, LinearLayout.LayoutParams(MATCH, WRAP))

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle(if (index >= 0) "ویرایش دستیار" else "دستیار تازه")
            .setView(scroll)
            .setPositiveButton("ذخیره") { _, _ ->
                val list = AiStore.load(this)
                val np = AiProvider(name.text.toString().trim().ifEmpty { "دستیار" }, format, base.text.toString().trim(), model.text.toString().trim(), p.encKey)
                val typed = key.text.toString().trim()
                if (typed.isNotEmpty()) np.setKey(typed)
                if (np.baseUrl.isEmpty()) {
                    toast("آدرس پایه لازم است")
                } else {
                    if (index >= 0 && index < list.size) {
                        list[index] = np
                    } else {
                        list.add(np)
                        AiStore.setActive(this, list.size - 1)
                    }
                    AiStore.save(this, list)
                    rerender()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}

// ----------------------------------------------------------------------
// Project files
// ----------------------------------------------------------------------

class ProjectActivity : PageActivity() {
    private var cwd = ""
    override fun pageTitle(): String = "پروژه"

    private fun join(dir: String, name: String): String = if (dir.isEmpty()) name else dir + "/" + name

    override fun render() {
        val ws = WorkspaceManager.get(this)
        heading(ws.label() + (if (cwd.isEmpty()) "" else "  /  " + cwd))
        val top = card()
        actionRow(top, R.drawable.ic_add, "فایل تازه", null, false) { newFileDialog(ws) }
        actionRow(top, R.drawable.ic_download, "افزودن فایل از گوشی", "فایل‌های دلخواه را به پروژه کپی می‌کند", false) { pickFiles() }
        val names = ws.list(cwd)
        if (names.contains("index.html")) {
            actionRow(top, R.drawable.ic_play, "اجرای index.html", "پیش‌نمایش در نوا", false) { preview(join(cwd, "index.html")) }
        }
        if (cwd.isNotEmpty()) {
            actionRow(top, R.drawable.ic_back, "پوشه‌ی بالاتر", null, false) {
                val i = cwd.lastIndexOf('/')
                cwd = if (i >= 0) cwd.substring(0, i) else ""
                rerender()
            }
        }
        if (names.isEmpty()) {
            note("این پوشه خالی است. از دستیار بخواهید پروژه بسازد یا فایل اضافه کنید.")
            return
        }
        for (n in names) {
            val isDir = n.endsWith("/")
            val clean = n.removeSuffix("/")
            val path = join(cwd, clean)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = roundRect(C_PILL, 12, C_PILL_STROKE, 1)
            row.setPadding(dp(12), dp(4), dp(2), dp(4))
            val icon = ImageView(this)
            icon.setImageResource(if (isDir) R.drawable.ic_file else R.drawable.ic_code)
            icon.setColorFilter(if (isDir) C_STAR else C_ACCENT_LIGHT)
            row.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tv = TextView(this)
            tv.text = n
            tv.textSize = 15f
            tv.setTextColor(C_TEXT)
            tv.textDirection = View.TEXT_DIRECTION_LTR
            tv.setPadding(dp(12), 0, dp(8), 0)
            row.addView(ellipsized(tv), LinearLayout.LayoutParams(0, WRAP, 1f))
            if (!isDir && (clean.endsWith(".html") || clean.endsWith(".htm"))) {
                row.addView(iconButton(R.drawable.ic_play, 40, 20, C_TAG2) { preview(path) })
            }
            row.addView(iconButton(R.drawable.ic_delete, 40, 20, C_DANGER) {
                confirm("«" + path + "» حذف شود؟", "حذف") {
                    toast(if (ws.delete(path)) "حذف شد" else "حذف ناموفق بود")
                    rerender()
                }
            })
            row.setOnClickListener {
                if (isDir) {
                    cwd = path
                    rerender()
                } else {
                    openFile(ws, path, clean)
                }
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            body.addView(row, lp)
        }
    }

    private fun preview(path: String) {
        val i = Intent(this, ProjectPreviewActivity::class.java)
        i.putExtra("entry", path)
        startActivity(i)
    }

    private fun openFile(ws: Workspace, path: String, name: String) {
        val uri = ws.uriOf(path)
        if (uri == null) {
            toast("فایل پیدا نشد")
            return
        }
        FileOpener.open(this, uri, name, null, null)
    }

    private fun newFileDialog(ws: Workspace) {
        val input = EditText(this)
        input.hint = "نام فایل، مثل game/index.html"
        input.setSingleLine(true)
        input.textDirection = View.TEXT_DIRECTION_LTR
        val holder = FrameLayout(this)
        holder.setPadding(dp(20), dp(8), dp(20), 0)
        holder.addView(input, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("فایل تازه")
            .setView(holder)
            .setPositiveButton("ساخت") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    toast(if (ws.writeText(join(cwd, n), "")) "ساخته شد" else "ساخت ناموفق بود")
                    rerender()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(i, REQ_ADD_FILES)
        } catch (e: Exception) {
            toast("انتخاب فایل ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_ADD_FILES || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            val single = data.data
            if (single != null) uris.add(single)
        }
        val ws = WorkspaceManager.get(this)
        val dir = cwd
        Thread {
            var ok = 0
            for (u in uris) {
                try {
                    val bytes = contentResolver.openInputStream(u)?.use { it.readBytes() }
                    if (bytes != null && bytes.size < 30000000 && ws.write(join(dir, displayName(u)), bytes)) ok += 1
                } catch (e: Exception) {
                    // skip
                }
            }
            runOnUiThread {
                toast(faDigits(ok.toString()) + " فایل اضافه شد")
                rerender()
            }
        }.start()
    }
}

// ----------------------------------------------------------------------
// Preview of a web project / game from the workspace
// ----------------------------------------------------------------------

class ProjectPreviewActivity : android.app.Activity() {
    private var webView: WebView? = null
    private var consoleView: TextView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val entry = intent.getStringExtra("entry") ?: "index.html"
        val ws = WorkspaceManager.get(this)
        val f = createToolFrame("اجرا: " + entry)
        f.header.addView(iconButton(R.drawable.ic_refresh, 44, 22, C_TEXT) { webView?.reload() })

        val wv = WebView(this)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                val u = request.url
                if (u.host != "project.local") return null
                var path = Uri.decode(u.path ?: "").removePrefix("/")
                if (path.isEmpty() || path.endsWith("/")) path += "index.html"
                val bytes = ws.read(path)
                val headers = HashMap<String, String>()
                headers["Access-Control-Allow-Origin"] = "*"
                headers["Cache-Control"] = "no-store"
                return if (bytes == null) {
                    WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers, java.io.ByteArrayInputStream(ByteArray(0)))
                } else {
                    WebResourceResponse(mimeFor(path), if (isText(path)) "UTF-8" else null, 200, "OK", headers, java.io.ByteArrayInputStream(bytes))
                }
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (consoleMessage != null && consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    val cv = consoleView
                    if (cv != null) {
                        cv.text = "⚠ " + consoleMessage.message() + "  (خط " + consoleMessage.lineNumber() + ")"
                        cv.visibility = View.VISIBLE
                    }
                }
                return true
            }
        }
        webView = wv
        f.root.addView(wv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val cv = TextView(this)
        cv.setBackgroundColor(Color.parseColor("#3A1020"))
        cv.setTextColor(Color.WHITE)
        cv.textSize = 12f
        cv.typeface = Typeface.MONOSPACE
        cv.setPadding(dp(10), dp(6), dp(10), dp(6))
        cv.visibility = View.GONE
        cv.setOnClickListener { cv.visibility = View.GONE }
        consoleView = cv
        f.root.addView(cv, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(f.root)
        wv.loadUrl("https://project.local/" + Uri.encode(entry, "/"))
    }

    private fun isText(path: String): Boolean {
        val e = FileOpener.extOf(path)
        return e == "html" || e == "htm" || e == "js" || e == "css" || e == "json" || e == "svg" || e == "txt" || e == "xml"
    }

    private fun mimeFor(path: String): String {
        return when (FileOpener.extOf(path)) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "text/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "mp3" -> "audio/mpeg"
            "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            "wasm" -> "application/wasm"
            "glb" -> "model/gltf-binary"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    override fun onDestroy() {
        val wv = webView
        if (wv != null) {
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        webView = null
        super.onDestroy()
    }
}

// ----------------------------------------------------------------------
// Termux guide with copyable commands
// ----------------------------------------------------------------------

internal object InstallerBuilder {
    private fun asset(ctx: Context, path: String): String? {
        return try {
            ctx.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    fun script(ctx: Context): String? {
        val setup = asset(ctx, "termux/setup.sh") ?: return null
        val cli = asset(ctx, "termux/nova_cli.py") ?: return null
        val n3 = asset(ctx, "nova3d.py") ?: return null
        return setup.replace("__NOVA3D__", n3.trimEnd('\n')).replace("__NOVA_CLI__", cli.trimEnd('\n'))
    }

    fun oneLiner(ctx: Context): String? {
        val s = script(ctx) ?: return null
        val bos = java.io.ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(s.toByteArray(Charsets.UTF_8)) }
        val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
        return "echo '" + b64 + "' | base64 -d | gzip -dc | bash"
    }
}

class TermuxGuideActivity : PageActivity() {
    override fun pageTitle(): String = "راهنمای Termux و دستورها"

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
        toast("کپی شد")
    }

    private fun codeCard(title: String, text: String, preview: String?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundRect(Color.parseColor("#080A1E"), 12, C_PILL_STROKE, 1)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(12), dp(2), dp(2), 0)
        val t = TextView(this)
        t.text = title
        t.textSize = 13f
        t.setTextColor(C_MUTED)
        head.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(iconButton(R.drawable.ic_copy, 40, 20, C_TAG2) { copy(text) })
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val tv = TextView(this)
        tv.text = preview ?: text
        tv.textSize = 12.5f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(C_TEXT)
        tv.setTextIsSelectable(true)
        tv.textDirection = View.TEXT_DIRECTION_LTR
        tv.setPadding(dp(12), dp(2), dp(12), dp(10))
        box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(4), 0, dp(8))
        body.addView(box, lp)
    }

    override fun render() {
        note("با Termux، نوا یک محیط کامل برنامه‌نویسی می‌شود: دستیار می‌تواند دستور اجرا کند، مدل سه‌بعدی بسازد، فایل تبدیل کند و APK امضا کند. همه‌ی دستورها قابل کپی‌اند.")

        heading("۱) نصب Termux")
        note("Termux را از F-Droid یا GitHub نصب کنید (نسخه‌ی گوگل‌پلی قدیمی است).")
        codeCard("آدرس", "https://f-droid.org/packages/com.termux/", null)

        heading("۲) دستور نصب نوا (یک خط)")
        note("این دستور خودش همه‌چیز را در Termux نصب می‌کند: پایتون، git، دستور nova، کتابخانه‌ی مدل‌سازی و اجازه‌ی اتصال نوا. فقط کپی کنید، در Termux بچسبانید و Enter بزنید. به اینترنت نیاز دارد.")
        val one = InstallerBuilder.oneLiner(this)
        if (one != null) {
            codeCard("دستور نصب (حدود " + faDigits((one.length / 1000).toString()) + " هزار نویسه)", one, one.substring(0, minOf(140, one.length)) + " …")
        } else {
            note("ساخت دستور ناموفق بود.")
        }
        val a = card()
        actionRow(a, R.drawable.ic_save, "ذخیره‌ی اسکریپت نصب به‌صورت فایل", "اگر چسباندن دستور بلند مشکل داشت", false) { saveScript() }
        note("بعد از ذخیره‌ی فایل در پوشه‌ی Download، در Termux این دو دستور را بزنید:")
        codeCard("Termux", "termux-setup-storage\nbash ~/storage/downloads/nova-setup.sh", null)

        heading("۳) اتصال نوا به Termux")
        note("بعد از نصب، Termux را یک‌بار کامل ببندید و دوباره باز کنید. سپس در نوا: تنظیمات دستیار ← «درخواست مجوز اجرای دستور» و بعد «آزمایش اتصال».")
        val b = card()
        actionRow(b, R.drawable.ic_check, "درخواست مجوز", null, false) {
            if (TermuxBridge.isInstalled(this)) requestPermissions(arrayOf(TermuxBridge.PERMISSION), 1) else toast("Termux نصب نیست")
        }
        note("اگر نصب خودکار تنظیمات را ننوشت، این دو دستور را دستی بزنید:")
        codeCard("Termux", "mkdir -p ~/.termux\necho \"allow-external-apps=true\" >> ~/.termux/termux.properties", null)

        heading("۴) دستورهای nova")
        codeCard("بررسی محیط", "nova doctor", null)
        codeCard("ساخت مدل سه‌بعدی از اسکریپت پایتون", "nova model script.py out.glb\nnova model script.py out.stl", null)
        codeCard("تبدیل فایل‌های سه‌بعدی (OBJ، STL، GLB)", "nova convert in.obj out.glb\nnova convert in.glb out.stl", null)
        codeCard("ساخت پروژه‌ی بازی HTML5", "nova game mygame\nnova serve ~/storage/shared/NovaProjects/mygame", null)
        codeCard("امضای APK", "pkg install openjdk-17 apksigner\nnova sign app.apk", null)
        note("برای هر برنامه یک کلید ثابت نگه دارید: همه‌ی نسخه‌های بعدی باید با همان کلید امضا شوند. nova کلید را در ~/.nova می‌سازد؛ از آن نسخه‌ی پشتیبان بگیرید.")

        heading("۵) مدل هوش مصنوعی روی خود گوشی (اختیاری)")
        note("اگر اینترنت یا API ندارید، می‌توانید مدل کوچک را داخل Termux اجرا کنید و در نوا پیش‌تنظیم «Ollama» یا «llama.cpp» را اضافه کنید. این بسته‌ها ممکن است روی دستگاه شما موجود نباشند؛ ابتدا بررسی کنید. مدل‌ها حجیم‌اند و روی گوشی کند.")
        codeCard("Ollama", "pkg search ollama\npkg install ollama\nollama serve &\nollama pull <model-name>", null)
        codeCard("llama.cpp", "pkg search llama-cpp\npkg install llama-cpp\nllama-server -m model.gguf --port 8080", null)

        heading("۶) ساخت APK")
        note("ساخت کامل پروژه‌ی Gradle اندروید داخل گوشی سنگین و شکننده است. روش مطمئن: پروژه را با دستیار بسازید، به GitHub بفرستید و با GitHub Actions بسازید، سپس با دستور بالا (یا ابزار امضا) امضا کنید. دستیار می‌تواند فایل workflow را برایتان بنویسد.")

        heading("۷) نکته‌ها")
        note("• هر دستوری که دستیار بخواهد در Termux اجرا کند، قبل از اجرا به شما نشان داده می‌شود و باید اجازه بدهید.\n• دستورهایی را که از جای نامطمئن گرفته‌اید در Termux نچسبانید.\n• نوا برنامه‌ی اندروید است و روی آیفون اجرا نمی‌شود؛ روی آیفون برنامه‌هایی مثل a-Shell یا iSH بخشی از این کارها را می‌دهند، اما اتصال خودکار وجود ندارد.")
    }

    private fun saveScript() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/x-shellscript"
        i.putExtra(Intent.EXTRA_TITLE, "nova-setup.sh")
        try {
            startActivityForResult(i, REQ_SAVE_SCRIPT)
        } catch (e: Exception) {
            toast("ذخیره ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE_SCRIPT && resultCode == RESULT_OK && data != null) {
            val u = data.data ?: return
            val text = InstallerBuilder.script(this)
            if (text == null) {
                toast("ساخت اسکریپت ناموفق بود")
                return
            }
            try {
                contentResolver.openOutputStream(u, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("ذخیره شد")
            } catch (e: Exception) {
                toast("ذخیره ناموفق بود")
            }
        }
    }
}
