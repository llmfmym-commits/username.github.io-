package com.nova.browser

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper

internal class TermuxResult(val ok: Boolean, val stdout: String, val stderr: String, val exitCode: Int, val error: String)

/** Runs commands inside Termux through its RUN_COMMAND service (needs allow-external-apps=true). */
internal object TermuxBridge {
    const val PKG = "com.termux"
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    const val RESULT_ACTION = "ir.noornavar.nova.TERMUX_RESULT"

    private val callbacks = HashMap<Int, (TermuxResult) -> Unit>()
    private var nextId = 1
    private val handler = Handler(Looper.getMainLooper())

    fun isInstalled(ctx: Context): Boolean {
        return try {
            ctx.packageManager.getPackageInfo(PKG, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    fun run(ctx: Context, command: String, timeoutMs: Long, cb: (TermuxResult) -> Unit) {
        val id = synchronized(this) {
            val v = nextId
            nextId += 1
            v
        }
        callbacks[id] = cb
        val ri = Intent(ctx, TermuxResultReceiver::class.java)
        ri.action = RESULT_ACTION
        ri.putExtra("req", id)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
        val pi = PendingIntent.getBroadcast(ctx, id, ri, flags)

        val i = Intent()
        i.setClassName(PKG, "com.termux.app.RunCommandService")
        i.action = "com.termux.RUN_COMMAND"
        i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
        i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
        i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
        i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
        i.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        try {
            ctx.startService(i)
        } catch (e: Exception) {
            callbacks.remove(id)
            cb(TermuxResult(false, "", "", -1, "اجرای دستور ممکن نشد: " + (e.message ?: e.javaClass.simpleName)))
            return
        }
        handler.postDelayed({
            val c = callbacks.remove(id)
            if (c != null) c(TermuxResult(false, "", "", -1, "زمان اجرا تمام شد"))
        }, timeoutMs)
    }

    fun deliver(id: Int, r: TermuxResult) {
        val c = callbacks.remove(id)
        if (c != null) c(r)
    }
}

class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return
        val id = intent.getIntExtra("req", -1)
        val b = intent.getBundleExtra("result")
        if (b == null) {
            TermuxBridge.deliver(id, TermuxResult(false, "", "", -1, "نتیجه‌ای از Termux نرسید"))
            return
        }
        val err = b.getInt("err", -1)
        val code = b.getInt("exitCode", -1)
        val out = b.getString("stdout") ?: ""
        val errText = b.getString("stderr") ?: ""
        val errMsg = b.getString("errmsg") ?: ""
        val failed = err != -1 && err != 0
        TermuxBridge.deliver(id, TermuxResult(!failed, out, errText, code, errMsg))
    }
}
