#!/data/data/com.termux/files/usr/bin/bash
# Nova installer for Termux (also works on a normal Linux/macOS shell without pkg).
set -e
echo "== Nova setup =="
if command -v pkg >/dev/null 2>&1; then
  pkg update -y
  pkg install -y python git curl zip unzip
fi
mkdir -p "$HOME/.termux" "$HOME/.nova"
touch "$HOME/.termux/termux.properties"
if grep -q '^allow-external-apps' "$HOME/.termux/termux.properties"; then
  sed -i 's/^allow-external-apps.*/allow-external-apps=true/' "$HOME/.termux/termux.properties"
else
  echo 'allow-external-apps=true' >> "$HOME/.termux/termux.properties"
fi
command -v termux-reload-settings >/dev/null 2>&1 && termux-reload-settings || true

cat > "$HOME/.nova/nova3d.py" <<'NOVA_EOF_3D'
"""nova3d - tiny pure-Python 3D modelling library for Nova Browser.

Axes: X right, Y forward, Z up (units are free, e.g. millimetres).

Shapes:   polyhedron(vertices, faces)  box(w,d,h)  cube(s)  sphere(r)  cylinder(r,h)  cone(r,h)  torus(R,r)
          extrude(points,h)  revolve(profile)  tube(path,r)  surface(fn)
          heightmap(fn)  gear(teeth)
Move:     m.move(x,y,z)  m.rotate(x,y,z)  m.scale(s)  m.color("#ff8800")
Boolean:  a + b (union)   a - b (difference)   a & b (intersection)
Groups:   combine(a,b,...)  polar(m,n)  linear(m,n,dx,dy,dz)
Output:   scene(a, b, ...)  <- shows the shapes in the 3D viewer
"""
import math
import json
import sys

try:
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 6000))
except Exception:
    pass

_scene = []

_NAMES = {
    "red": (0.90, 0.22, 0.22), "green": (0.25, 0.75, 0.35), "blue": (0.25, 0.45, 0.95),
    "white": (0.95, 0.95, 0.95), "black": (0.08, 0.08, 0.08), "gray": (0.55, 0.55, 0.58),
    "grey": (0.55, 0.55, 0.58), "yellow": (0.98, 0.85, 0.20), "orange": (0.98, 0.55, 0.15),
    "purple": (0.60, 0.30, 0.85), "cyan": (0.20, 0.85, 0.90), "pink": (0.98, 0.50, 0.70),
    "brown": (0.55, 0.35, 0.20), "gold": (0.90, 0.72, 0.25),
}


def _reset():
    global _scene
    _scene = []


def _parse_color(c):
    if isinstance(c, str):
        s = c.strip().lower()
        if s in _NAMES:
            r, g, b = _NAMES[s]
            return (r, g, b, 1.0)
        if s.startswith("#"):
            s = s[1:]
        if len(s) == 3:
            s = "".join(ch * 2 for ch in s)
        if len(s) == 6:
            return (int(s[0:2], 16) / 255.0, int(s[2:4], 16) / 255.0, int(s[4:6], 16) / 255.0, 1.0)
        raise ValueError("unknown color: " + str(c))
    vals = list(c)
    if max(vals) > 1.0:
        vals = [v / 255.0 for v in vals]
    if len(vals) == 3:
        vals.append(1.0)
    return tuple(float(v) for v in vals[:4])


# ----------------------------------------------------------------------
# vector helpers
# ----------------------------------------------------------------------

def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _len(a):
    return math.sqrt(_dot(a, a))


def _norm(a):
    l = _len(a)
    if l < 1e-12:
        return (0.0, 0.0, 1.0)
    return (a[0] / l, a[1] / l, a[2] / l)


def _lerp(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


# ----------------------------------------------------------------------
# Mesh
# ----------------------------------------------------------------------

class Mesh:
    """A triangle mesh. Triangles are counter-clockwise seen from outside."""

    def __init__(self, tris=None, col=None):
        self.tris = tris if tris is not None else []
        self.col = col if col is not None else (0.62, 0.66, 0.95, 1.0)

    def copy(self):
        return Mesh(list(self.tris), self.col)

    def _map(self, f, flip=False):
        out = []
        for a, b, c in self.tris:
            if flip:
                out.append((f(a), f(c), f(b)))
            else:
                out.append((f(a), f(b), f(c)))
        return Mesh(out, self.col)

    def move(self, x=0, y=0, z=0):
        return self._map(lambda p: (p[0] + x, p[1] + y, p[2] + z))

    def scale(self, sx, sy=None, sz=None):
        if sy is None:
            sy = sx
        if sz is None:
            sz = sx
        flip = (sx * sy * sz) < 0
        return self._map(lambda p: (p[0] * sx, p[1] * sy, p[2] * sz), flip)

    def rotate(self, x=0, y=0, z=0):
        """Rotate by angles in degrees (applied in X, then Y, then Z order)."""
        ax, ay, az = math.radians(x), math.radians(y), math.radians(z)
        cx, sx_ = math.cos(ax), math.sin(ax)
        cy, sy_ = math.cos(ay), math.sin(ay)
        cz, sz_ = math.cos(az), math.sin(az)

        def f(p):
            px, py, pz = p
            py, pz = py * cx - pz * sx_, py * sx_ + pz * cx
            px, pz = px * cy + pz * sy_, -px * sy_ + pz * cy
            px, py = px * cz - py * sz_, px * sz_ + py * cz
            return (px, py, pz)

        return self._map(f)

    def color(self, c):
        m = Mesh(self.tris, _parse_color(c))
        return m

    def bounds(self):
        if not self.tris:
            return ((0, 0, 0), (0, 0, 0))
        xs, ys, zs = [], [], []
        for tri in self.tris:
            for p in tri:
                xs.append(p[0])
                ys.append(p[1])
                zs.append(p[2])
        return ((min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs)))

    def size(self):
        lo, hi = self.bounds()
        return (hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2])

    def volume(self):
        v = 0.0
        for a, b, c in self.tris:
            v += _dot(a, _cross(b, c))
        return v / 6.0

    def center(self):
        """Move the mesh so the middle of its bounding box is at the origin."""
        lo, hi = self.bounds()
        return self.move(-(lo[0] + hi[0]) / 2.0, -(lo[1] + hi[1]) / 2.0, -(lo[2] + hi[2]) / 2.0)

    def on_floor(self):
        """Move the mesh so its lowest point sits at z = 0."""
        lo, _ = self.bounds()
        return self.move(0, 0, -lo[2])

    def mirror(self, axis="x"):
        a = axis.lower()
        if a == "x":
            return self.scale(-1, 1, 1)
        if a == "y":
            return self.scale(1, -1, 1)
        return self.scale(1, 1, -1)

    def __add__(self, other):
        return _boolean(self, other, "union")

    def __sub__(self, other):
        return _boolean(self, other, "subtract")

    def __and__(self, other):
        return _boolean(self, other, "intersect")

    def __repr__(self):
        return "<Mesh %d triangles>" % len(self.tris)


# ----------------------------------------------------------------------
# primitives
# ----------------------------------------------------------------------

def _quad(a, b, c, d):
    return [(a, b, c), (a, c, d)]


def _grid(fn, nu, nv):
    """Triangles of a parametric surface fn(u, v), u and v in 0..1.
    Orientation: normal = dP/du x dP/dv."""
    pts = [[fn(i / float(nu), j / float(nv)) for j in range(nv + 1)] for i in range(nu + 1)]
    tris = []
    for i in range(nu):
        for j in range(nv):
            a = pts[i][j]
            b = pts[i + 1][j]
            c = pts[i + 1][j + 1]
            d = pts[i][j + 1]
            for t in ((a, b, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    return tris


def box(w=1.0, d=None, h=None, center=True):
    if d is None:
        d = w
    if h is None:
        h = w
    if center:
        x0, x1, y0, y1, z0, z1 = -w / 2.0, w / 2.0, -d / 2.0, d / 2.0, -h / 2.0, h / 2.0
    else:
        x0, x1, y0, y1, z0, z1 = 0.0, w, 0.0, d, 0.0, h
    t = []
    t += _quad((x0, y0, z0), (x0, y1, z0), (x1, y1, z0), (x1, y0, z0))
    t += _quad((x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1))
    t += _quad((x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1))
    t += _quad((x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0))
    t += _quad((x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0))
    t += _quad((x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1))
    return Mesh(t)


def cube(s=1.0, center=True):
    return box(s, s, s, center)


def sphere(r=1.0, seg=24):
    seg = max(6, int(seg))
    rings = max(3, seg // 2)

    def fn(u, v):
        th = math.pi * u
        ph = 2.0 * math.pi * v
        return (r * math.sin(th) * math.cos(ph), r * math.sin(th) * math.sin(ph), r * math.cos(th))

    return Mesh(_grid(fn, rings, seg))


def frustum(r1=1.0, r2=0.5, h=1.0, seg=32, center=True):
    seg = max(3, int(seg))
    z0 = -h / 2.0 if center else 0.0
    z1 = z0 + h

    def side(u, v):
        ph = 2.0 * math.pi * u
        r = r1 + (r2 - r1) * v
        return (r * math.cos(ph), r * math.sin(ph), z0 + h * v)

    tris = _grid(side, seg, 1)
    for i in range(seg):
        a0 = 2.0 * math.pi * i / seg
        a1 = 2.0 * math.pi * (i + 1) / seg
        if r2 > 1e-9:
            tris.append(((0.0, 0.0, z1), (r2 * math.cos(a0), r2 * math.sin(a0), z1), (r2 * math.cos(a1), r2 * math.sin(a1), z1)))
        if r1 > 1e-9:
            tris.append(((0.0, 0.0, z0), (r1 * math.cos(a1), r1 * math.sin(a1), z0), (r1 * math.cos(a0), r1 * math.sin(a0), z0)))
    return Mesh(tris)


def cylinder(r=1.0, h=1.0, seg=32, center=True):
    return frustum(r, r, h, seg, center)


def cone(r=1.0, h=1.0, seg=32, center=True):
    return frustum(r, 0.0, h, seg, center)


def torus(R=1.0, r=0.3, seg=32, rseg=16):
    def fn(u, v):
        th = 2.0 * math.pi * u
        ph = 2.0 * math.pi * v
        return ((R + r * math.cos(ph)) * math.cos(th), (R + r * math.cos(ph)) * math.sin(th), r * math.sin(ph))

    return Mesh(_grid(fn, int(seg), int(rseg)))


def _area2(poly):
    s = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        s += x0 * y1 - x1 * y0
    return s / 2.0


def _triangulate(poly):
    """Ear clipping for a simple counter-clockwise polygon. Returns index triples."""
    n = len(poly)
    idx = list(range(n))
    out = []

    def cross2(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    def inside(p, a, b, c):
        d1 = cross2(a, b, p)
        d2 = cross2(b, c, p)
        d3 = cross2(c, a, p)
        return d1 >= -1e-12 and d2 >= -1e-12 and d3 >= -1e-12

    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        clipped = False
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[(k - 1) % m], idx[k], idx[(k + 1) % m]
            a, b, c = poly[i0], poly[i1], poly[i2]
            if cross2(a, b, c) <= 1e-12:
                continue
            ok = True
            for j in idx:
                if j in (i0, i1, i2):
                    continue
                if inside(poly[j], a, b, c):
                    ok = False
                    break
            if ok:
                out.append((i0, i1, i2))
                idx.pop(k)
                clipped = True
                break
        if not clipped:
            # degenerate polygon: fall back to a fan
            for k in range(1, len(idx) - 1):
                out.append((idx[0], idx[k], idx[k + 1]))
            return out
    if len(idx) == 3:
        out.append((idx[0], idx[1], idx[2]))
    return out


def extrude(points, h=1.0, center=False):
    """Extrude a 2D polygon [(x, y), ...] upward by h."""
    poly = [(float(p[0]), float(p[1])) for p in points]
    if len(poly) < 3:
        raise ValueError("extrude needs at least 3 points")
    if _area2(poly) < 0:
        poly.reverse()
    z0 = -h / 2.0 if center else 0.0
    z1 = z0 + h
    tris = []
    for i0, i1, i2 in _triangulate(poly):
        a, b, c = poly[i0], poly[i1], poly[i2]
        tris.append(((a[0], a[1], z1), (b[0], b[1], z1), (c[0], c[1], z1)))
        tris.append(((a[0], a[1], z0), (c[0], c[1], z0), (b[0], b[1], z0)))
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        tris += _quad((a[0], a[1], z0), (b[0], b[1], z0), (b[0], b[1], z1), (a[0], a[1], z1))
    return Mesh(tris)


def revolve(profile, seg=48):
    """Spin a profile [(radius, z), ...] (bottom to top) around the Z axis."""
    prof = [(float(p[0]), float(p[1])) for p in profile]
    n = len(prof)
    if n < 2:
        raise ValueError("revolve needs at least 2 points")

    def fn(u, v):
        ph = 2.0 * math.pi * u
        k = v * (n - 1)
        i = min(int(k), n - 2)
        t = k - i
        r = prof[i][0] + (prof[i + 1][0] - prof[i][0]) * t
        z = prof[i][1] + (prof[i + 1][1] - prof[i][1]) * t
        return (r * math.cos(ph), r * math.sin(ph), z)

    # sample exactly on profile vertices
    seg = max(3, int(seg))
    rows = []
    for (r, z) in prof:
        rows.append([(r * math.cos(2.0 * math.pi * j / seg), r * math.sin(2.0 * math.pi * j / seg), z) for j in range(seg + 1)])
    tris = []
    for k in range(n - 1):
        for j in range(seg):
            a = rows[k][j]
            b = rows[k][j + 1]
            c = rows[k + 1][j + 1]
            d = rows[k + 1][j]
            for t in ((a, b, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    # surface above has normal along -(dphi x dprofile) check: build with outward orientation
    if prof[-1][1] < prof[0][1]:
        tris = [(a, c, b) for (a, b, c) in tris]
    # orientation of the generated quads is a,b,c with b = next angle: dphi x dprofile -> outward
    if prof[0][0] > 1e-9:
        z = prof[0][1]
        for j in range(seg):
            tris.append(((0.0, 0.0, z), rows[0][j + 1], rows[0][j]))
    if prof[-1][0] > 1e-9:
        z = prof[-1][1]
        for j in range(seg):
            tris.append(((0.0, 0.0, z), rows[-1][j], rows[-1][j + 1]))
    return Mesh(tris)


def tube(path, r=0.2, seg=12, caps=True):
    """Round pipe following a 3D path [(x, y, z), ...]."""
    pts = [(float(p[0]), float(p[1]), float(p[2])) for p in path]
    n = len(pts)
    if n < 2:
        raise ValueError("tube needs at least 2 points")
    tang = []
    for i in range(n):
        a = pts[max(i - 1, 0)]
        b = pts[min(i + 1, n - 1)]
        tang.append(_norm(_sub(b, a)))
    t0 = tang[0]
    helper = (0.0, 0.0, 1.0) if abs(t0[2]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = _norm(_cross(helper, t0))
    rings = []
    seg = max(3, int(seg))
    for i in range(n):
        t = tang[i]
        nrm = _sub(nrm, _mul(t, _dot(nrm, t)))
        nrm = _norm(nrm)
        b = _cross(t, nrm)
        ring = []
        for j in range(seg + 1):
            ph = 2.0 * math.pi * j / seg
            off = _add(_mul(nrm, r * math.cos(ph)), _mul(b, r * math.sin(ph)))
            ring.append(_add(pts[i], off))
        rings.append(ring)
    tris = []
    for i in range(n - 1):
        for j in range(seg):
            a = rings[i][j]
            b2 = rings[i][j + 1]
            c = rings[i + 1][j + 1]
            d = rings[i + 1][j]
            for t in ((a, b2, c), (a, c, d)):
                if _len(_cross(_sub(t[1], t[0]), _sub(t[2], t[0]))) > 1e-12:
                    tris.append(t)
    if caps:
        for j in range(seg):
            tris.append((pts[0], rings[0][j + 1], rings[0][j]))
            tris.append((pts[-1], rings[-1][j], rings[-1][j + 1]))
    return Mesh(tris)


def surface(fn, u=(0.0, 1.0), v=(0.0, 1.0), nu=40, nv=40):
    """Open parametric surface: fn(u, v) -> (x, y, z)."""
    u0, u1 = u
    v0, v1 = v

    def f(a, b):
        return fn(u0 + (u1 - u0) * a, v0 + (v1 - v0) * b)

    return Mesh(_grid(f, int(nu), int(nv)))


def heightmap(fn, x=(-5.0, 5.0), y=(-5.0, 5.0), n=40, base=0.0):
    """Solid terrain / math surface: height z = fn(x, y), flat bottom at z = base."""
    n = max(2, int(n))
    xs = [x[0] + (x[1] - x[0]) * i / n for i in range(n + 1)]
    ys = [y[0] + (y[1] - y[0]) * j / n for j in range(n + 1)]
    top = [[(xs[i], ys[j], float(fn(xs[i], ys[j]))) for j in range(n + 1)] for i in range(n + 1)]
    tris = []
    for i in range(n):
        for j in range(n):
            a, b, c, d = top[i][j], top[i + 1][j], top[i + 1][j + 1], top[i][j + 1]
            tris.append((a, b, c))
            tris.append((a, c, d))
            a0, b0, c0, d0 = (a[0], a[1], base), (b[0], b[1], base), (c[0], c[1], base), (d[0], d[1], base)
            tris.append((a0, c0, b0))
            tris.append((a0, d0, c0))

    def wall(p, q):
        tris.extend(_quad((p[0], p[1], base), (q[0], q[1], base), q, p))

    for i in range(n):
        wall(top[i][0], top[i + 1][0])
        wall(top[i + 1][n], top[i][n])
    for j in range(n):
        wall(top[n][j], top[n][j + 1])
        wall(top[0][j + 1], top[0][j])
    return Mesh(tris)


def polyhedron(vertices, faces, convex=True):
    """Solid from a list of vertices [(x,y,z),...] and faces [[i,j,k,...],...] (indices).
    convex=True fixes the face orientation automatically (works for convex shapes);
    for other shapes keep faces counter-clockwise seen from outside."""
    verts = [(float(v[0]), float(v[1]), float(v[2])) for v in vertices]
    cx = sum(v[0] for v in verts) / len(verts)
    cy = sum(v[1] for v in verts) / len(verts)
    cz = sum(v[2] for v in verts) / len(verts)
    tris = []
    for f in faces:
        idx = list(f)
        pts = [verts[i] for i in idx]
        if convex:
            nx = ny = nz = 0.0
            for k in range(len(pts)):
                a = pts[k]
                b = pts[(k + 1) % len(pts)]
                nx += (a[1] - b[1]) * (a[2] + b[2])
                ny += (a[2] - b[2]) * (a[0] + b[0])
                nz += (a[0] - b[0]) * (a[1] + b[1])
            fx = sum(p[0] for p in pts) / len(pts) - cx
            fy = sum(p[1] for p in pts) / len(pts) - cy
            fz = sum(p[2] for p in pts) / len(pts) - cz
            if nx * fx + ny * fy + nz * fz < 0:
                idx.reverse()
        for i in range(1, len(idx) - 1):
            tris.append((verts[idx[0]], verts[idx[i]], verts[idx[i + 1]]))
    m = Mesh(tris)
    if not convex and m.volume() < 0:
        m = Mesh([(a, c, b) for a, b, c in tris])
    return m


def gear(teeth=12, module=2.0, thickness=5.0, hole=0.0, pressure=0.25):
    """Simple spur gear with trapezoid teeth (flat on the XY plane)."""
    teeth = max(6, int(teeth))
    pitch_r = module * teeth / 2.0
    tip_r = pitch_r + module
    root_r = max(pitch_r - 1.25 * module, module * 0.5)
    pts = []
    step = 2.0 * math.pi / teeth
    for i in range(teeth):
        a = i * step
        w_root = step * 0.5
        w_tip = step * (0.5 - pressure)
        for (ang, rad) in ((-w_root / 2.0, root_r), (-w_tip / 2.0, tip_r), (w_tip / 2.0, tip_r), (w_root / 2.0, root_r)):
            pts.append(((rad) * math.cos(a + ang), (rad) * math.sin(a + ang)))
    g = extrude(pts, thickness, center=True)
    if hole > 0:
        g = g - cylinder(hole / 2.0, thickness * 2.0, 32)
    return g


# ----------------------------------------------------------------------
# groups
# ----------------------------------------------------------------------

def combine(*meshes):
    """Merge shapes without boolean maths (fast). Colour of the first is kept."""
    items = []
    for m in meshes:
        if isinstance(m, (list, tuple)):
            items.extend(m)
        else:
            items.append(m)
    tris = []
    for m in items:
        tris.extend(m.tris)
    return Mesh(tris, items[0].col if items else None)


def polar(mesh, n, axis="z"):
    """n copies rotated evenly around an axis through the origin."""
    out = []
    for i in range(int(n)):
        a = 360.0 * i / n
        if axis == "x":
            out.append(mesh.rotate(a, 0, 0))
        elif axis == "y":
            out.append(mesh.rotate(0, a, 0))
        else:
            out.append(mesh.rotate(0, 0, a))
    return out


def linear(mesh, n, dx=0.0, dy=0.0, dz=0.0):
    return [mesh.move(dx * i, dy * i, dz * i) for i in range(int(n))]


# ----------------------------------------------------------------------
# boolean operations (BSP trees)
# ----------------------------------------------------------------------

_EPS = 1e-5
_COPLANAR, _FRONT, _BACK, _SPANNING = 0, 1, 2, 3


class _Plane(object):
    __slots__ = ("n", "w")

    def __init__(self, n, w):
        self.n = n
        self.w = w

    def clone(self):
        return _Plane(self.n, self.w)

    def flip(self):
        self.n = (-self.n[0], -self.n[1], -self.n[2])
        self.w = -self.w

    def split(self, poly, cof, cob, front, back):
        ptype = 0
        types = []
        n = self.n
        w = self.w
        for v in poly.v:
            t = n[0] * v[0] + n[1] * v[1] + n[2] * v[2] - w
            typ = _BACK if t < -_EPS else (_FRONT if t > _EPS else _COPLANAR)
            ptype |= typ
            types.append(typ)
        if ptype == _COPLANAR:
            if _dot(n, poly.plane.n) > 0:
                cof.append(poly)
            else:
                cob.append(poly)
        elif ptype == _FRONT:
            front.append(poly)
        elif ptype == _BACK:
            back.append(poly)
        else:
            f = []
            b = []
            cnt = len(poly.v)
            for i in range(cnt):
                j = (i + 1) % cnt
                ti, tj = types[i], types[j]
                vi, vj = poly.v[i], poly.v[j]
                if ti != _BACK:
                    f.append(vi)
                if ti != _FRONT:
                    b.append(vi)
                if (ti | tj) == _SPANNING:
                    den = _dot(n, _sub(vj, vi))
                    t = (w - _dot(n, vi)) / den if abs(den) > 1e-15 else 0.5
                    v = _lerp(vi, vj, t)
                    f.append(v)
                    b.append(v)
            if len(f) >= 3:
                front.append(_Poly(f, poly.plane))
            if len(b) >= 3:
                back.append(_Poly(b, poly.plane))


class _Poly(object):
    __slots__ = ("v", "plane")

    def __init__(self, v, plane=None):
        self.v = v
        if plane is None:
            n = _norm(_cross(_sub(v[1], v[0]), _sub(v[2], v[0])))
            plane = _Plane(n, _dot(n, v[0]))
        self.plane = plane

    def clone(self):
        return _Poly(list(self.v), self.plane.clone())

    def flip(self):
        self.v.reverse()
        self.plane.flip()


class _Node(object):
    def __init__(self, polys=None):
        self.plane = None
        self.front = None
        self.back = None
        self.polys = []
        if polys:
            self.build(polys)

    def clone(self):
        n = _Node()
        n.plane = self.plane.clone() if self.plane else None
        n.front = self.front.clone() if self.front else None
        n.back = self.back.clone() if self.back else None
        n.polys = [p.clone() for p in self.polys]
        return n

    def invert(self):
        stack = [self]
        while stack:
            node = stack.pop()
            for p in node.polys:
                p.flip()
            if node.plane:
                node.plane.flip()
            node.front, node.back = node.back, node.front
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)

    def clip_polys(self, polys):
        if not self.plane:
            return list(polys)
        front = []
        back = []
        for p in polys:
            self.plane.split(p, front, back, front, back)
        if self.front:
            front = self.front.clip_polys(front)
        if self.back:
            back = self.back.clip_polys(back)
        else:
            back = []
        return front + back

    def clip_to(self, bsp):
        stack = [self]
        while stack:
            node = stack.pop()
            node.polys = bsp.clip_polys(node.polys)
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)

    def all_polys(self):
        out = []
        stack = [self]
        while stack:
            node = stack.pop()
            out.extend(node.polys)
            if node.front:
                stack.append(node.front)
            if node.back:
                stack.append(node.back)
        return out

    def build(self, polys):
        stack = [(self, polys)]
        while stack:
            node, plist = stack.pop()
            if not plist:
                continue
            if node.plane is None:
                node.plane = plist[0].plane.clone()
            front = []
            back = []
            for p in plist:
                node.plane.split(p, node.polys, node.polys, front, back)
            if front:
                if node.front is None:
                    node.front = _Node()
                stack.append((node.front, front))
            if back:
                if node.back is None:
                    node.back = _Node()
                stack.append((node.back, back))


def _to_polys(mesh):
    out = []
    for a, b, c in mesh.tris:
        n = _cross(_sub(b, a), _sub(c, a))
        if _len(n) < 1e-12:
            continue
        out.append(_Poly([a, b, c]))
    return out


def _from_polys(polys, col):
    tris = []
    for p in polys:
        v = p.v
        for i in range(1, len(v) - 1):
            a, b, c = v[0], v[i], v[i + 1]
            if _len(_cross(_sub(b, a), _sub(c, a))) > 1e-14:
                tris.append((a, b, c))
    return Mesh(tris, col)


def _boolean(a, b, op):
    if not isinstance(b, Mesh):
        raise TypeError("boolean operations need two shapes")
    A = _Node(_to_polys(a))
    B = _Node(_to_polys(b))
    if op == "union":
        A.clip_to(B)
        B.clip_to(A)
        B.invert()
        B.clip_to(A)
        B.invert()
        A.build(B.all_polys())
    elif op == "subtract":
        A.invert()
        A.clip_to(B)
        B.clip_to(A)
        B.invert()
        B.clip_to(A)
        B.invert()
        A.build(B.all_polys())
        A.invert()
    else:
        A.invert()
        B.clip_to(A)
        B.invert()
        A.clip_to(B)
        B.clip_to(A)
        A.build(B.all_polys())
        A.invert()
    return _from_polys(A.all_polys(), a.col)


# ----------------------------------------------------------------------
# scene + export
# ----------------------------------------------------------------------

def scene(*meshes, **kw):
    """Send shapes to the 3D viewer. Lists are allowed: scene(polar(m, 6))."""
    names = kw.get("name")
    items = []
    for m in meshes:
        if isinstance(m, (list, tuple)):
            items.extend(m)
        else:
            items.append(m)
    for m in items:
        if not isinstance(m, Mesh):
            raise TypeError("scene() only accepts shapes (Mesh objects)")
        _scene.append((m, names if (names and len(items) == 1) else "shape_%d" % (len(_scene) + 1)))
    return None


show = scene


def _smooth_normals(tris, angle=50.0):
    fn = []
    for a, b, c in tris:
        n = _cross(_sub(b, a), _sub(c, a))
        l = _len(n)
        if l < 1e-14:
            fn.append(((0.0, 0.0, 1.0), 0.0))
        else:
            fn.append(((n[0] / l, n[1] / l, n[2] / l), l))

    def key(p):
        return (int(round(p[0] * 1e4)), int(round(p[1] * 1e4)), int(round(p[2] * 1e4)))

    groups = {}
    for i, tri in enumerate(tris):
        for p in tri:
            groups.setdefault(key(p), []).append(i)
    cos_t = math.cos(math.radians(angle))
    out = []
    for i, tri in enumerate(tris):
        ni = fn[i][0]
        for p in tri:
            sx = sy = sz = 0.0
            for j in groups[key(p)]:
                nj, aj = fn[j]
                if ni[0] * nj[0] + ni[1] * nj[1] + ni[2] * nj[2] >= cos_t:
                    sx += nj[0] * aj
                    sy += nj[1] * aj
                    sz += nj[2] * aj
            l = math.sqrt(sx * sx + sy * sy + sz * sz)
            if l < 1e-12:
                out.append(ni)
            else:
                out.append((sx / l, sy / l, sz / l))
    return out


def _export_json():
    meshes = []
    total = 0
    lo = [1e30, 1e30, 1e30]
    hi = [-1e30, -1e30, -1e30]
    vol = 0.0
    for m, name in _scene:
        if not m.tris:
            continue
        nor = _smooth_normals(m.tris)
        pos = []
        nrm = []
        k = 0
        for tri in m.tris:
            for p in tri:
                pos.extend((round(p[0], 4), round(p[1], 4), round(p[2], 4)))
                n = nor[k]
                nrm.extend((round(n[0], 3), round(n[1], 3), round(n[2], 3)))
                k += 1
                for ax in range(3):
                    if p[ax] < lo[ax]:
                        lo[ax] = p[ax]
                    if p[ax] > hi[ax]:
                        hi[ax] = p[ax]
        total += len(m.tris)
        vol += m.volume()
        meshes.append({"name": name, "positions": pos, "normals": nrm, "color": [round(c, 4) for c in m.col]})
    if not meshes:
        lo = [0, 0, 0]
        hi = [0, 0, 0]
    stats = {
        "shapes": len(meshes),
        "triangles": total,
        "size": [round(hi[i] - lo[i], 3) for i in range(3)],
        "volume": round(vol, 3),
    }
    return json.dumps({"meshes": meshes, "stats": stats})
NOVA_EOF_3D

cat > "$HOME/.nova/nova_cli.py" <<'NOVA_EOF_CLI'
#!/usr/bin/env python3
"""nova - helper command line for Nova Browser (works in Termux, Linux, macOS).

  nova doctor                         check the environment
  nova model  script.py out.glb       run a nova3d Python script and export GLB / STL / OBJ
  nova convert in.obj out.glb         convert between OBJ, STL and GLB
  nova sign   app.apk [options]       sign an APK (needs: pkg install openjdk-17 apksigner)
  nova serve  [folder] [port]         serve a web project (HTML5 game) on http://127.0.0.1:8000
  nova game   name                    create an HTML5 canvas game project
  nova projects                       show the shared project folder

Axes: scripts use Z-up (like CAD). GLB files are Y-up; nova rotates automatically
(use --keep-axes to disable).
"""
import json
import math
import os
import shutil
import struct
import subprocess
import sys

HOME = os.path.expanduser("~")
NOVA_DIR = os.path.join(HOME, ".nova")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, NOVA_DIR)


def projects_dir():
    shared = os.path.join(HOME, "storage", "shared", "NovaProjects")
    if os.path.isdir(os.path.join(HOME, "storage", "shared")):
        os.makedirs(shared, exist_ok=True)
        return shared
    path = os.path.join(HOME, "NovaProjects")
    os.makedirs(path, exist_ok=True)
    return path


# ---------------------------------------------------------------- mesh data
# A "scene" is {"meshes": [{"name", "positions": flat Z-up floats, "normals", "color"}]}

def _face_normals(pos):
    nor = []
    for i in range(0, len(pos), 9):
        ax, ay, az, bx, by, bz, cx, cy, cz = pos[i:i + 9]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nor.extend([nx / l, ny / l, nz / l] * 3)
    return nor


def build_glb(scene):
    meshes = scene["meshes"]
    chunks = []
    offset = 0
    views, accessors, gmeshes, materials, nodes = [], [], [], [], []
    for i, m in enumerate(meshes):
        pos = m["positions"]
        nor = m["normals"]
        n = len(pos) // 3
        pf, nf = [], []
        mn = [1e30] * 3
        mx = [-1e30] * 3
        for k in range(n):
            x, y, z = pos[3 * k], pos[3 * k + 1], pos[3 * k + 2]
            p = (x, z, -y)
            pf.extend(p)
            nf.extend((nor[3 * k], nor[3 * k + 2], -nor[3 * k + 1]))
            for a in range(3):
                mn[a] = min(mn[a], p[a])
                mx[a] = max(mx[a], p[a])
        pb = struct.pack("<%df" % len(pf), *pf)
        nb = struct.pack("<%df" % len(nf), *nf)
        v0 = len(views)
        views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(pb), "target": 34962})
        chunks.append(pb)
        offset += len(pb)
        views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(nb), "target": 34962})
        chunks.append(nb)
        offset += len(nb)
        a0 = len(accessors)
        accessors.append({"bufferView": v0, "componentType": 5126, "count": n, "type": "VEC3", "min": mn, "max": mx})
        accessors.append({"bufferView": v0 + 1, "componentType": 5126, "count": n, "type": "VEC3"})
        materials.append({"name": m["name"], "doubleSided": True,
                          "pbrMetallicRoughness": {"baseColorFactor": m.get("color", [0.62, 0.66, 0.95, 1.0]),
                                                   "metallicFactor": 0.15, "roughnessFactor": 0.55}})
        gmeshes.append({"name": m["name"], "primitives": [{"attributes": {"POSITION": a0, "NORMAL": a0 + 1}, "material": i, "mode": 4}]})
        nodes.append({"mesh": i, "name": m["name"]})
    doc = {"asset": {"version": "2.0", "generator": "Nova CLI"}, "scene": 0,
           "scenes": [{"nodes": list(range(len(nodes)))}], "nodes": nodes, "meshes": gmeshes,
           "materials": materials, "accessors": accessors, "bufferViews": views,
           "buffers": [{"byteLength": offset}]}
    js = json.dumps(doc, separators=(",", ":")).encode("utf-8")
    js += b" " * ((4 - len(js) % 4) % 4)
    binb = b"".join(chunks)
    total = 12 + 8 + len(js) + 8 + len(binb)
    out = struct.pack("<III", 0x46546C67, 2, total)
    out += struct.pack("<II", len(js), 0x4E4F534A) + js
    out += struct.pack("<II", len(binb), 0x004E4942) + binb
    return out


def build_stl(scene):
    tris = sum(len(m["positions"]) // 9 for m in scene["meshes"])
    out = bytearray(b"Nova CLI STL".ljust(80, b" "))
    out += struct.pack("<I", tris)
    for m in scene["meshes"]:
        p = m["positions"]
        for i in range(0, len(p), 9):
            ax, ay, az, bx, by, bz, cx, cy, cz = p[i:i + 9]
            ux, uy, uz = bx - ax, by - ay, bz - az
            vx, vy, vz = cx - ax, cy - ay, cz - az
            nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            out += struct.pack("<12fH", nx / l, ny / l, nz / l, ax, ay, az, bx, by, bz, cx, cy, cz, 0)
    return bytes(out)


def build_obj(scene):
    lines = ["# Nova CLI OBJ"]
    base = 1
    for m in scene["meshes"]:
        lines.append("o " + str(m["name"]))
        p = m["positions"]
        n = len(p) // 3
        for k in range(n):
            lines.append("v %g %g %g" % (p[3 * k], p[3 * k + 1], p[3 * k + 2]))
        for t in range(0, n, 3):
            lines.append("f %d %d %d" % (base + t, base + t + 1, base + t + 2))
        base += n
    return ("\n".join(lines) + "\n").encode("utf-8")


# ---------------------------------------------------------------- readers
def read_obj(path):
    verts, pos = [], []
    for line in open(path, encoding="utf-8", errors="replace"):
        parts = line.split()
        if not parts:
            continue
        if parts[0] == "v":
            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
        elif parts[0] == "f":
            idx = []
            for tok in parts[1:]:
                i = int(tok.split("/")[0])
                idx.append(i - 1 if i > 0 else len(verts) + i)
            for k in range(1, len(idx) - 1):
                for j in (idx[0], idx[k], idx[k + 1]):
                    pos.extend(verts[j])
    return {"meshes": [{"name": os.path.basename(path), "positions": pos, "normals": _face_normals(pos)}]}


def read_stl(path):
    data = open(path, "rb").read()
    pos = []
    if data[:5].lower() == b"solid" and b"facet" in data[:400]:
        for line in data.decode("utf-8", "replace").splitlines():
            parts = line.split()
            if parts and parts[0] == "vertex":
                pos.extend([float(parts[1]), float(parts[2]), float(parts[3])])
    else:
        n = struct.unpack_from("<I", data, 80)[0]
        off = 84
        for _ in range(n):
            vals = struct.unpack_from("<12f", data, off)
            pos.extend(vals[3:])
            off += 50
    return {"meshes": [{"name": os.path.basename(path), "positions": pos, "normals": _face_normals(pos)}]}


def read_glb(path):
    data = open(path, "rb").read()
    if data[:4] != b"glTF":
        raise ValueError("not a GLB file")
    jlen, _ = struct.unpack_from("<II", data, 12)
    doc = json.loads(data[20:20 + jlen].decode("utf-8"))
    boff = 20 + jlen
    blen, _ = struct.unpack_from("<II", data, boff)
    binb = data[boff + 8:boff + 8 + blen]
    comp_fmt = {5126: "f", 5125: "I", 5123: "H", 5121: "B"}
    comp_size = {5126: 4, 5125: 4, 5123: 2, 5121: 1}

    def accessor(i):
        a = doc["accessors"][i]
        v = doc["bufferViews"][a["bufferView"]]
        ncomp = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[a["type"]]
        size = comp_size[a["componentType"]]
        stride = v.get("byteStride", ncomp * size)
        base = v.get("byteOffset", 0) + a.get("byteOffset", 0)
        out = []
        for k in range(a["count"]):
            out.append(struct.unpack_from("<" + comp_fmt[a["componentType"]] * ncomp, binb, base + k * stride))
        return out

    meshes = []
    for m in doc.get("meshes", []):
        pos = []
        for prim in m["primitives"]:
            if prim.get("mode", 4) != 4:
                continue
            P = accessor(prim["attributes"]["POSITION"])
            if "indices" in prim:
                idx = [t[0] for t in accessor(prim["indices"])]
                tri = [P[i] for i in idx]
            else:
                tri = P
            for (x, y, z) in tri:
                pos.extend((x, -z, y))      # Y-up -> Z-up
        meshes.append({"name": m.get("name", "mesh"), "positions": pos, "normals": _face_normals(pos)})
    return {"meshes": meshes}


def write_scene(scene, out_path, keep_axes=False):
    ext = os.path.splitext(out_path)[1].lower()
    if ext == ".glb":
        data = build_glb(scene)
    elif ext == ".stl":
        data = build_stl(scene)
    elif ext == ".obj":
        data = build_obj(scene)
    else:
        raise SystemExit("output must end with .glb, .stl or .obj")
    with open(out_path, "wb") as f:
        f.write(data)
    tris = sum(len(m["positions"]) // 9 for m in scene["meshes"])
    print("saved %s  (%d triangles, %d KB)" % (out_path, tris, len(data) // 1024))


# ---------------------------------------------------------------- commands
def cmd_model(args):
    if len(args) < 2:
        raise SystemExit("usage: nova model script.py out.glb|stl|obj")
    script, out = args[0], args[1]
    import nova3d
    nova3d._reset()
    code = open(script, encoding="utf-8").read()
    ns = {"__name__": "__main__"}
    exec(compile(code, script, "exec"), ns)
    scene = json.loads(nova3d._export_json())
    if not scene["meshes"]:
        raise SystemExit("the script did not call scene(...)")
    print("stats:", scene["stats"])
    write_scene(scene, out)


def cmd_convert(args):
    if len(args) < 2:
        raise SystemExit("usage: nova convert in.(obj|stl|glb) out.(obj|stl|glb)")
    src, out = args[0], args[1]
    ext = os.path.splitext(src)[1].lower()
    readers = {".obj": read_obj, ".stl": read_stl, ".glb": read_glb}
    if ext not in readers:
        raise SystemExit("input must be .obj, .stl or .glb")
    write_scene(readers[ext](src), out)


def _run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def cmd_sign(args):
    apk = None
    ks = os.path.join(NOVA_DIR, "nova.jks")
    alias = "nova"
    pw = None
    out = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--ks":
            ks = args[i + 1]
            i += 2
        elif a == "--alias":
            alias = args[i + 1]
            i += 2
        elif a == "--pass":
            pw = args[i + 1]
            i += 2
        elif a == "--out":
            out = args[i + 1]
            i += 2
        else:
            apk = a
            i += 1
    if not apk or not os.path.isfile(apk):
        raise SystemExit("usage: nova sign app.apk [--ks file.jks --alias name --pass password --out signed.apk]")
    signer = shutil.which("apksigner")
    keytool = shutil.which("keytool")
    if not signer:
        raise SystemExit("apksigner not found. Install: pkg install openjdk-17 apksigner")
    pass_file = os.path.join(NOVA_DIR, "keystore.pass")
    if not os.path.isfile(ks):
        if not keytool:
            raise SystemExit("keytool not found. Install: pkg install openjdk-17")
        import secrets
        pw = secrets.token_hex(12)
        os.makedirs(os.path.dirname(ks), exist_ok=True)
        r = _run([keytool, "-genkeypair", "-keystore", ks, "-alias", alias, "-keyalg", "RSA", "-keysize", "2048",
                  "-validity", "36500", "-storepass", pw, "-keypass", pw, "-dname", "CN=Nova, O=Nova, C=US"])
        if r.returncode != 0:
            raise SystemExit("keytool failed: " + r.stderr)
        with open(pass_file, "w") as f:
            f.write(pw)
        os.chmod(pass_file, 0o600)
        print("created a new key: %s  (password saved in %s) - BACK IT UP, every update must use the same key" % (ks, pass_file))
    if pw is None:
        if os.path.isfile(pass_file):
            pw = open(pass_file).read().strip()
        else:
            raise SystemExit("give the keystore password with --pass")
    if out is None:
        out = os.path.splitext(apk)[0] + "-signed.apk"
    r = _run([signer, "sign", "--ks", ks, "--ks-key-alias", alias, "--ks-pass", "pass:" + pw,
              "--key-pass", "pass:" + pw, "--out", out, apk])
    if r.returncode != 0:
        raise SystemExit("apksigner failed: " + r.stdout + r.stderr)
    v = _run([signer, "verify", "-v", out])
    print(v.stdout.strip() or "signed")
    print("signed APK:", out)


class _Quiet:
    pass


def cmd_serve(args):
    import http.server
    import functools
    folder = args[0] if args else "."
    port = int(args[1]) if len(args) > 1 else 8000
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=folder)
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), handler)
    print("serving %s at http://127.0.0.1:%d  (Ctrl+C to stop)" % (os.path.abspath(folder), port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


GAME_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>__NAME__</title>
<style>html,body{margin:0;height:100%;background:#0B0D26;overflow:hidden;touch-action:none}
canvas{display:block;width:100%;height:100%}</style></head>
<body><canvas id="c"></canvas>
<script>
// __NAME__ - tiny touch game: drag to move, collect the stars.
var c = document.getElementById('c'), g = c.getContext('2d');
function fit(){ c.width = innerWidth; c.height = innerHeight; }
addEventListener('resize', fit); fit();
var player = {x: c.width/2, y: c.height/2, r: 22};
var stars = [], score = 0;
function spawn(){ stars.push({x: Math.random()*c.width, y: Math.random()*c.height, r: 10}); }
for (var i = 0; i < 6; i++) spawn();
function move(e){ var t = e.touches ? e.touches[0] : e; player.x = t.clientX; player.y = t.clientY; }
c.addEventListener('touchmove', move); c.addEventListener('mousemove', move);
function loop(){
  g.fillStyle = '#0B0D26'; g.fillRect(0, 0, c.width, c.height);
  stars = stars.filter(function(s){
    var hit = Math.hypot(s.x - player.x, s.y - player.y) < s.r + player.r;
    if (hit) { score++; spawn(); }
    return !hit;
  });
  g.fillStyle = '#FFD54F'; stars.forEach(function(s){ g.beginPath(); g.arc(s.x, s.y, s.r, 0, 6.3); g.fill(); });
  g.fillStyle = '#5B6CFF'; g.beginPath(); g.arc(player.x, player.y, player.r, 0, 6.3); g.fill();
  g.fillStyle = '#E8EAFF'; g.font = '20px sans-serif'; g.fillText('Score: ' + score, 16, 32);
  requestAnimationFrame(loop);
}
loop();
</script></body></html>
"""


def cmd_game(args):
    if not args:
        raise SystemExit("usage: nova game <name>")
    name = args[0]
    folder = os.path.join(projects_dir(), name)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "index.html")
    if os.path.exists(path):
        raise SystemExit("already exists: " + path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(GAME_TEMPLATE.replace("__NAME__", name))
    print("created", path)
    print("preview: Nova app > AI assistant > project > preview, or: nova serve", folder)


def cmd_doctor(args):
    print("python      :", sys.version.split()[0])
    for tool in ("git", "curl", "java", "keytool", "apksigner", "zip", "ollama", "llama-server"):
        print("%-12s: %s" % (tool, shutil.which(tool) or "-"))
    try:
        import nova3d
        print("nova3d      : ok")
    except Exception as e:
        print("nova3d      : missing (%s)" % e)
    print("projects    :", projects_dir())
    print("storage     :", "linked" if os.path.isdir(os.path.join(HOME, "storage", "shared")) else "run: termux-setup-storage")


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("help", "-h", "--help"):
        print(__doc__)
        return
    cmd, rest = argv[0], argv[1:]
    table = {"model": cmd_model, "convert": cmd_convert, "sign": cmd_sign, "serve": cmd_serve,
             "game": cmd_game, "doctor": cmd_doctor, "projects": lambda a: print(projects_dir())}
    if cmd not in table:
        raise SystemExit("unknown command: %s (try: nova help)" % cmd)
    table[cmd](rest)


if __name__ == "__main__":
    main()
NOVA_EOF_CLI

BIN="${PREFIX:-$HOME/.local}/bin"
mkdir -p "$BIN"
cat > "$BIN/nova" <<'NOVA_EOF_BIN'
#!/usr/bin/env sh
exec python3 "$HOME/.nova/nova_cli.py" "$@"
NOVA_EOF_BIN
chmod +x "$BIN/nova"

if [ -d "$HOME/storage" ]; then :; else command -v termux-setup-storage >/dev/null 2>&1 && termux-setup-storage || true; fi
echo
echo "Nova is ready. Try:  nova doctor"
echo "If this is your first time, close and reopen Termux once so that external apps are allowed."
