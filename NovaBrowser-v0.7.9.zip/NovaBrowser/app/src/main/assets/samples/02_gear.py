# چرخ‌دنده‌ی ساده با سوراخ وسط
from nova3d import *

g1 = gear(teeth=16, module=2, thickness=6, hole=6).color("orange")
g2 = gear(teeth=10, module=2, thickness=6, hole=4).rotate(0, 0, 18).move(26, 0, 0).color("cyan")

scene(g1, g2)
