# فنر مارپیچی با تابع tube
import math
from nova3d import *

path = []
for i in range(0, 241):
    a = math.radians(i * 6)
    path.append((10 * math.cos(a), 10 * math.sin(a), i * 0.15))

spring = tube(path, r=1.2, seg=10).color("#9FB0FF")
scene(spring)
