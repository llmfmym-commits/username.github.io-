# سطح ریاضی: موج
import math
from nova3d import *

def f(x, y):
    r = math.sqrt(x * x + y * y)
    return 2.0 * math.cos(r * 1.2) / (1 + 0.25 * r)

terrain = heightmap(f, x=(-10, 10), y=(-10, 10), n=48, base=-3).color("#5CC8FF")
scene(terrain)
