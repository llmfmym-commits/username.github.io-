# ترکیب شکل‌ها: مکعب سوراخ‌دار (توجه: seg را کم نگه دارید تا سریع اجرا شود)
from nova3d import *

cube_ = box(30, 30, 30)
ball = sphere(19, 24)
hx = cylinder(6, 40, 20)
hy = hx.rotate(90, 0, 0)
hz = hx.rotate(0, 90, 0)

result = (cube_ & ball) - hx - hy - hz
scene(result.color("#A98BFF"))
print("حجم:", round(result.volume(), 1))
