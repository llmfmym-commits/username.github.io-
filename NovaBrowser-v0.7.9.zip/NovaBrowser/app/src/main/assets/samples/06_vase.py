# گلدان با revolve: نیم‌رخ را بچرخانید
import math
from nova3d import *

profile = [(0, 0), (8, 0)]
for i in range(1, 21):
    t = i / 20.0
    profile.append((8 + 5 * math.sin(t * math.pi * 1.6), t * 40))
profile.append((6, 42))

vase = revolve(profile, seg=48).color("#FF9E7A")
scene(vase)
