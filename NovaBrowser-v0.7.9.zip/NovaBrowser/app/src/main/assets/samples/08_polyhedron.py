# ساخت جسم از نقطه‌ها و وجه‌ها (مثل کدهای matplotlib: vertices و faces)
from nova3d import *

vertices = [(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
            (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]
faces = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4],
         [2, 3, 7, 6], [1, 2, 6, 5], [0, 3, 7, 4]]

cube_ = polyhedron(vertices, faces).scale(10).color("cyan")
scene(cube_)
print("حجم:", cube_.volume())
