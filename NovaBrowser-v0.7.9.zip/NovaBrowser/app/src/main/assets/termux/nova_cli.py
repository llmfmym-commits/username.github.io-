#!/usr/bin/env python3
"""nova - helper command line for Nova Browser (works in Termux, Linux, macOS).

  nova doctor                         check the environment
  nova model  script.py out.glb       run a nova3d Python script and export GLB / STL / OBJ
  nova convert in.obj out.glb         convert between OBJ, STL and GLB
  nova sign   app.apk [options]       sign an APK (needs: pkg install openjdk-17 apksigner)
  nova serve  [folder] [port]         serve a web project (HTML5 game) on http://127.0.0.1:8000
  nova game   name                    create an HTML5 canvas game project
  nova projects                       show the shared project folder
  nova link   <code>                  link with the Nova app (code is shown in Nova)
  nova daemon [folder]                let Nova run commands here (no Android permission needed)

Axes: scripts use Z-up (like CAD). GLB files are Y-up; nova rotates automatically
(use --keep-axes to disable).
"""
import json
import math
import os
import shutil
import struct
import subprocess
import sys

HOME = os.path.expanduser("~")
NOVA_DIR = os.path.join(HOME, ".nova")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, NOVA_DIR)


def projects_dir():
    shared = os.path.join(HOME, "storage", "shared", "NovaProjects")
    if os.path.isdir(os.path.join(HOME, "storage", "shared")):
        os.makedirs(shared, exist_ok=True)
        return shared
    path = os.path.join(HOME, "NovaProjects")
    os.makedirs(path, exist_ok=True)
    return path


# ---------------------------------------------------------------- mesh data
# A "scene" is {"meshes": [{"name", "positions": flat Z-up floats, "normals", "color"}]}

def _face_normals(pos):
    nor = []
    for i in range(0, len(pos), 9):
        ax, ay, az, bx, by, bz, cx, cy, cz = pos[i:i + 9]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nor.extend([nx / l, ny / l, nz / l] * 3)
    return nor


def build_glb(scene):
    meshes = scene["meshes"]
    chunks = []
    offset = 0
    views, accessors, gmeshes, materials, nodes = [], [], [], [], []
    for i, m in enumerate(meshes):
        pos = m["positions"]
        nor = m["normals"]
        n = len(pos) // 3
        pf, nf = [], []
        mn = [1e30] * 3
        mx = [-1e30] * 3
        for k in range(n):
            x, y, z = pos[3 * k], pos[3 * k + 1], pos[3 * k + 2]
            p = (x, z, -y)
            pf.extend(p)
            nf.extend((nor[3 * k], nor[3 * k + 2], -nor[3 * k + 1]))
            for a in range(3):
                mn[a] = min(mn[a], p[a])
                mx[a] = max(mx[a], p[a])
        pb = struct.pack("<%df" % len(pf), *pf)
        nb = struct.pack("<%df" % len(nf), *nf)
        v0 = len(views)
        views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(pb), "target": 34962})
        chunks.append(pb)
        offset += len(pb)
        views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(nb), "target": 34962})
        chunks.append(nb)
        offset += len(nb)
        a0 = len(accessors)
        accessors.append({"bufferView": v0, "componentType": 5126, "count": n, "type": "VEC3", "min": mn, "max": mx})
        accessors.append({"bufferView": v0 + 1, "componentType": 5126, "count": n, "type": "VEC3"})
        materials.append({"name": m["name"], "doubleSided": True,
                          "pbrMetallicRoughness": {"baseColorFactor": m.get("color", [0.62, 0.66, 0.95, 1.0]),
                                                   "metallicFactor": 0.15, "roughnessFactor": 0.55}})
        gmeshes.append({"name": m["name"], "primitives": [{"attributes": {"POSITION": a0, "NORMAL": a0 + 1}, "material": i, "mode": 4}]})
        nodes.append({"mesh": i, "name": m["name"]})
    doc = {"asset": {"version": "2.0", "generator": "Nova CLI"}, "scene": 0,
           "scenes": [{"nodes": list(range(len(nodes)))}], "nodes": nodes, "meshes": gmeshes,
           "materials": materials, "accessors": accessors, "bufferViews": views,
           "buffers": [{"byteLength": offset}]}
    js = json.dumps(doc, separators=(",", ":")).encode("utf-8")
    js += b" " * ((4 - len(js) % 4) % 4)
    binb = b"".join(chunks)
    total = 12 + 8 + len(js) + 8 + len(binb)
    out = struct.pack("<III", 0x46546C67, 2, total)
    out += struct.pack("<II", len(js), 0x4E4F534A) + js
    out += struct.pack("<II", len(binb), 0x004E4942) + binb
    return out


def build_stl(scene):
    tris = sum(len(m["positions"]) // 9 for m in scene["meshes"])
    out = bytearray(b"Nova CLI STL".ljust(80, b" "))
    out += struct.pack("<I", tris)
    for m in scene["meshes"]:
        p = m["positions"]
        for i in range(0, len(p), 9):
            ax, ay, az, bx, by, bz, cx, cy, cz = p[i:i + 9]
            ux, uy, uz = bx - ax, by - ay, bz - az
            vx, vy, vz = cx - ax, cy - ay, cz - az
            nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            out += struct.pack("<12fH", nx / l, ny / l, nz / l, ax, ay, az, bx, by, bz, cx, cy, cz, 0)
    return bytes(out)


def build_obj(scene):
    lines = ["# Nova CLI OBJ"]
    base = 1
    for m in scene["meshes"]:
        lines.append("o " + str(m["name"]))
        p = m["positions"]
        n = len(p) // 3
        for k in range(n):
            lines.append("v %g %g %g" % (p[3 * k], p[3 * k + 1], p[3 * k + 2]))
        for t in range(0, n, 3):
            lines.append("f %d %d %d" % (base + t, base + t + 1, base + t + 2))
        base += n
    return ("\n".join(lines) + "\n").encode("utf-8")


# ---------------------------------------------------------------- readers
def read_obj(path):
    verts, pos = [], []
    for line in open(path, encoding="utf-8", errors="replace"):
        parts = line.split()
        if not parts:
            continue
        if parts[0] == "v":
            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
        elif parts[0] == "f":
            idx = []
            for tok in parts[1:]:
                i = int(tok.split("/")[0])
                idx.append(i - 1 if i > 0 else len(verts) + i)
            for k in range(1, len(idx) - 1):
                for j in (idx[0], idx[k], idx[k + 1]):
                    pos.extend(verts[j])
    return {"meshes": [{"name": os.path.basename(path), "positions": pos, "normals": _face_normals(pos)}]}


def read_stl(path):
    data = open(path, "rb").read()
    pos = []
    if data[:5].lower() == b"solid" and b"facet" in data[:400]:
        for line in data.decode("utf-8", "replace").splitlines():
            parts = line.split()
            if parts and parts[0] == "vertex":
                pos.extend([float(parts[1]), float(parts[2]), float(parts[3])])
    else:
        n = struct.unpack_from("<I", data, 80)[0]
        off = 84
        for _ in range(n):
            vals = struct.unpack_from("<12f", data, off)
            pos.extend(vals[3:])
            off += 50
    return {"meshes": [{"name": os.path.basename(path), "positions": pos, "normals": _face_normals(pos)}]}


def read_glb(path):
    data = open(path, "rb").read()
    if data[:4] != b"glTF":
        raise ValueError("not a GLB file")
    jlen, _ = struct.unpack_from("<II", data, 12)
    doc = json.loads(data[20:20 + jlen].decode("utf-8"))
    boff = 20 + jlen
    blen, _ = struct.unpack_from("<II", data, boff)
    binb = data[boff + 8:boff + 8 + blen]
    comp_fmt = {5126: "f", 5125: "I", 5123: "H", 5121: "B"}
    comp_size = {5126: 4, 5125: 4, 5123: 2, 5121: 1}

    def accessor(i):
        a = doc["accessors"][i]
        v = doc["bufferViews"][a["bufferView"]]
        ncomp = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[a["type"]]
        size = comp_size[a["componentType"]]
        stride = v.get("byteStride", ncomp * size)
        base = v.get("byteOffset", 0) + a.get("byteOffset", 0)
        out = []
        for k in range(a["count"]):
            out.append(struct.unpack_from("<" + comp_fmt[a["componentType"]] * ncomp, binb, base + k * stride))
        return out

    meshes = []
    for m in doc.get("meshes", []):
        pos = []
        for prim in m["primitives"]:
            if prim.get("mode", 4) != 4:
                continue
            P = accessor(prim["attributes"]["POSITION"])
            if "indices" in prim:
                idx = [t[0] for t in accessor(prim["indices"])]
                tri = [P[i] for i in idx]
            else:
                tri = P
            for (x, y, z) in tri:
                pos.extend((x, -z, y))      # Y-up -> Z-up
        meshes.append({"name": m.get("name", "mesh"), "positions": pos, "normals": _face_normals(pos)})
    return {"meshes": meshes}


def write_scene(scene, out_path, keep_axes=False):
    ext = os.path.splitext(out_path)[1].lower()
    if ext == ".glb":
        data = build_glb(scene)
    elif ext == ".stl":
        data = build_stl(scene)
    elif ext == ".obj":
        data = build_obj(scene)
    else:
        raise SystemExit("output must end with .glb, .stl or .obj")
    with open(out_path, "wb") as f:
        f.write(data)
    tris = sum(len(m["positions"]) // 9 for m in scene["meshes"])
    print("saved %s  (%d triangles, %d KB)" % (out_path, tris, len(data) // 1024))


# ---------------------------------------------------------------- commands
def cmd_model(args):
    if len(args) < 2:
        raise SystemExit("usage: nova model script.py out.glb|stl|obj")
    script, out = args[0], args[1]
    import nova3d
    nova3d._reset()
    code = open(script, encoding="utf-8").read()
    ns = {"__name__": "__main__"}
    exec(compile(code, script, "exec"), ns)
    scene = json.loads(nova3d._export_json())
    if not scene["meshes"]:
        raise SystemExit("the script did not call scene(...)")
    print("stats:", scene["stats"])
    write_scene(scene, out)


def cmd_convert(args):
    if len(args) < 2:
        raise SystemExit("usage: nova convert in.(obj|stl|glb) out.(obj|stl|glb)")
    src, out = args[0], args[1]
    ext = os.path.splitext(src)[1].lower()
    readers = {".obj": read_obj, ".stl": read_stl, ".glb": read_glb}
    if ext not in readers:
        raise SystemExit("input must be .obj, .stl or .glb")
    write_scene(readers[ext](src), out)


def _run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def cmd_sign(args):
    apk = None
    ks = os.path.join(NOVA_DIR, "nova.jks")
    alias = "nova"
    pw = None
    out = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--ks":
            ks = args[i + 1]
            i += 2
        elif a == "--alias":
            alias = args[i + 1]
            i += 2
        elif a == "--pass":
            pw = args[i + 1]
            i += 2
        elif a == "--out":
            out = args[i + 1]
            i += 2
        else:
            apk = a
            i += 1
    if not apk or not os.path.isfile(apk):
        raise SystemExit("usage: nova sign app.apk [--ks file.jks --alias name --pass password --out signed.apk]")
    signer = shutil.which("apksigner")
    keytool = shutil.which("keytool")
    if not signer:
        raise SystemExit("apksigner not found. Install: pkg install openjdk-17 apksigner")
    pass_file = os.path.join(NOVA_DIR, "keystore.pass")
    if not os.path.isfile(ks):
        if not keytool:
            raise SystemExit("keytool not found. Install: pkg install openjdk-17")
        import secrets
        pw = secrets.token_hex(12)
        os.makedirs(os.path.dirname(ks), exist_ok=True)
        r = _run([keytool, "-genkeypair", "-keystore", ks, "-alias", alias, "-keyalg", "RSA", "-keysize", "2048",
                  "-validity", "36500", "-storepass", pw, "-keypass", pw, "-dname", "CN=Nova, O=Nova, C=US"])
        if r.returncode != 0:
            raise SystemExit("keytool failed: " + r.stderr)
        with open(pass_file, "w") as f:
            f.write(pw)
        os.chmod(pass_file, 0o600)
        print("created a new key: %s  (password saved in %s) - BACK IT UP, every update must use the same key" % (ks, pass_file))
    if pw is None:
        if os.path.isfile(pass_file):
            pw = open(pass_file).read().strip()
        else:
            raise SystemExit("give the keystore password with --pass")
    if out is None:
        out = os.path.splitext(apk)[0] + "-signed.apk"
    r = _run([signer, "sign", "--ks", ks, "--ks-key-alias", alias, "--ks-pass", "pass:" + pw,
              "--key-pass", "pass:" + pw, "--out", out, apk])
    if r.returncode != 0:
        raise SystemExit("apksigner failed: " + r.stdout + r.stderr)
    v = _run([signer, "verify", "-v", out])
    print(v.stdout.strip() or "signed")
    print("signed APK:", out)


class _Quiet:
    pass


def cmd_serve(args):
    import http.server
    import functools
    folder = args[0] if args else "."
    port = int(args[1]) if len(args) > 1 else 8000
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=folder)
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), handler)
    print("serving %s at http://127.0.0.1:%d  (Ctrl+C to stop)" % (os.path.abspath(folder), port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


GAME_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>__NAME__</title>
<style>html,body{margin:0;height:100%;background:#0B0D26;overflow:hidden;touch-action:none}
canvas{display:block;width:100%;height:100%}</style></head>
<body><canvas id="c"></canvas>
<script>
// __NAME__ - tiny touch game: drag to move, collect the stars.
var c = document.getElementById('c'), g = c.getContext('2d');
function fit(){ c.width = innerWidth; c.height = innerHeight; }
addEventListener('resize', fit); fit();
var player = {x: c.width/2, y: c.height/2, r: 22};
var stars = [], score = 0;
function spawn(){ stars.push({x: Math.random()*c.width, y: Math.random()*c.height, r: 10}); }
for (var i = 0; i < 6; i++) spawn();
function move(e){ var t = e.touches ? e.touches[0] : e; player.x = t.clientX; player.y = t.clientY; }
c.addEventListener('touchmove', move); c.addEventListener('mousemove', move);
function loop(){
  g.fillStyle = '#0B0D26'; g.fillRect(0, 0, c.width, c.height);
  stars = stars.filter(function(s){
    var hit = Math.hypot(s.x - player.x, s.y - player.y) < s.r + player.r;
    if (hit) { score++; spawn(); }
    return !hit;
  });
  g.fillStyle = '#FFD54F'; stars.forEach(function(s){ g.beginPath(); g.arc(s.x, s.y, s.r, 0, 6.3); g.fill(); });
  g.fillStyle = '#5B6CFF'; g.beginPath(); g.arc(player.x, player.y, player.r, 0, 6.3); g.fill();
  g.fillStyle = '#E8EAFF'; g.font = '20px sans-serif'; g.fillText('Score: ' + score, 16, 32);
  requestAnimationFrame(loop);
}
loop();
</script></body></html>
"""


def cmd_game(args):
    if not args:
        raise SystemExit("usage: nova game <name>")
    name = args[0]
    folder = os.path.join(projects_dir(), name)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "index.html")
    if os.path.exists(path):
        raise SystemExit("already exists: " + path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(GAME_TEMPLATE.replace("__NAME__", name))
    print("created", path)
    print("preview: Nova app > AI assistant > project > preview, or: nova serve", folder)


SECRET_FILE = os.path.join(NOVA_DIR, "secret")


def cmd_link(args):
    if not args:
        raise SystemExit("usage: nova link <code shown in the Nova app>")
    os.makedirs(NOVA_DIR, exist_ok=True)
    with open(SECRET_FILE, "w") as f:
        f.write(args[0].strip())
    os.chmod(SECRET_FILE, 0o600)
    print("linked. Now run:  termux-wake-lock ; nova daemon")


def cmd_daemon(args):
    import hmac
    import hashlib
    import re
    import time
    if not os.path.isfile(SECRET_FILE):
        raise SystemExit("not linked yet. In the Nova app copy the link command and run it here:  nova link <code>")
    secret = open(SECRET_FILE).read().strip()
    folder = args[0] if args else os.path.join(projects_dir(), "_nova_bridge")
    inbox = os.path.join(folder, "inbox")
    outbox = os.path.join(folder, "outbox")
    os.makedirs(inbox, exist_ok=True)
    os.makedirs(outbox, exist_ok=True)
    seen = set()

    def reply(cid, code, out, err):
        data = json.dumps({"id": cid, "exit": code, "stdout": out[-60000:], "stderr": err[-20000:]})
        tmp = os.path.join(outbox, cid + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(data)
        os.replace(tmp, os.path.join(outbox, cid + ".json"))

    def handle(data):
        cid = str(data.get("id", ""))
        if not re.fullmatch(r"[0-9a-f]{8,32}", cid):
            return
        cmd = str(data.get("cmd", ""))
        ts = str(data.get("ts", ""))
        sig = str(data.get("sig", ""))
        expected = hmac.new(secret.encode("utf-8"), (cid + "\n" + ts + "\n" + cmd).encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, sig):
            print("[rejected] bad signature (wrong link code?)")
            reply(cid, -1, "", "bad signature: run nova link again with the code shown in Nova")
            return
        try:
            age = abs(time.time() - int(ts))
        except ValueError:
            age = 1e9
        if age > 600 or cid in seen:
            print("[rejected] old or repeated command")
            reply(cid, -1, "", "rejected: expired or repeated command")
            return
        seen.add(cid)
        print("[%s] run: %s" % (time.strftime("%H:%M:%S"), cmd[:300]))
        try:
            r = subprocess.run(["bash", "-lc", cmd], capture_output=True, text=True, timeout=240, cwd=HOME)
            reply(cid, r.returncode, r.stdout, r.stderr)
        except subprocess.TimeoutExpired:
            reply(cid, -1, "", "timeout after 240 s")
        except Exception as e:
            reply(cid, -1, "", str(e))

    print("Nova daemon is running. Folder: %s" % folder)
    print("Keep this Termux session open (tip: run termux-wake-lock). Press Ctrl+C to stop.")
    try:
        while True:
            try:
                names = sorted(os.listdir(inbox))
            except OSError:
                names = []
            for n in names:
                if not n.endswith(".json"):
                    continue
                path = os.path.join(inbox, n)
                try:
                    with open(path, encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    continue
                try:
                    os.remove(path)
                except OSError:
                    pass
                handle(data)
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nstopped")


def cmd_doctor(args):
    print("python      :", sys.version.split()[0])
    for tool in ("git", "curl", "java", "keytool", "apksigner", "zip", "ollama", "llama-server"):
        print("%-12s: %s" % (tool, shutil.which(tool) or "-"))
    try:
        import nova3d
        print("nova3d      : ok")
    except Exception as e:
        print("nova3d      : missing (%s)" % e)
    print("projects    :", projects_dir())
    print("storage     :", "linked" if os.path.isdir(os.path.join(HOME, "storage", "shared")) else "run: termux-setup-storage")


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("help", "-h", "--help"):
        print(__doc__)
        return
    cmd, rest = argv[0], argv[1:]
    table = {"model": cmd_model, "convert": cmd_convert, "sign": cmd_sign, "serve": cmd_serve,
             "game": cmd_game, "doctor": cmd_doctor, "link": cmd_link, "daemon": cmd_daemon, "projects": lambda a: print(projects_dir())}
    if cmd not in table:
        raise SystemExit("unknown command: %s (try: nova help)" % cmd)
    table[cmd](rest)


if __name__ == "__main__":
    main()
