#!/data/data/com.termux/files/usr/bin/bash
# Nova installer for Termux (also works on a normal Linux/macOS shell without pkg).
set -e
echo "== Nova setup =="
if command -v pkg >/dev/null 2>&1; then
  pkg update -y
  pkg install -y python git curl zip unzip
fi
mkdir -p "$HOME/.termux" "$HOME/.nova"
touch "$HOME/.termux/termux.properties"
if grep -q '^allow-external-apps' "$HOME/.termux/termux.properties"; then
  sed -i 's/^allow-external-apps.*/allow-external-apps=true/' "$HOME/.termux/termux.properties"
else
  echo 'allow-external-apps=true' >> "$HOME/.termux/termux.properties"
fi
command -v termux-reload-settings >/dev/null 2>&1 && termux-reload-settings || true

cat > "$HOME/.nova/nova3d.py" <<'NOVA_EOF_3D'
__NOVA3D__
NOVA_EOF_3D

cat > "$HOME/.nova/nova_cli.py" <<'NOVA_EOF_CLI'
__NOVA_CLI__
NOVA_EOF_CLI

BIN="${PREFIX:-$HOME/.local}/bin"
mkdir -p "$BIN"
cat > "$BIN/nova" <<'NOVA_EOF_BIN'
#!/usr/bin/env sh
exec python3 "$HOME/.nova/nova_cli.py" "$@"
NOVA_EOF_BIN
chmod +x "$BIN/nova"

if [ -d "$HOME/storage" ]; then :; else command -v termux-setup-storage >/dev/null 2>&1 && termux-setup-storage || true; fi
echo
echo "Nova is ready. Try:  nova doctor"
echo "If this is your first time, close and reopen Termux once so that external apps are allowed."
