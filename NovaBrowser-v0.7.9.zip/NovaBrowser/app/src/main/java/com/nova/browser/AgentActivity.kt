package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch

private const val MAX_STEPS = 8

/** Chat page for the AI assistant. The assistant can use tools (project files, web, Termux) with user approval. */
class AgentActivity : Activity() {
    private lateinit var ws: Workspace
    private val history = ArrayList<ChatMsg>()
    private var chatBox: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null
    private var thinking: TextView? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ws = WorkspaceManager.get(this)
        val f = createToolFrame("دستیار هوشمند نوا")
        f.header.addView(iconButton(R.drawable.ic_add, 44, 22, C_TEXT) { newChat() })
        f.header.addView(iconButton(R.drawable.ic_file, 44, 22, C_TEXT) { startActivity(Intent(this, ProjectActivity::class.java)) })
        f.header.addView(iconButton(R.drawable.ic_settings, 44, 22, C_TEXT) { startActivity(Intent(this, AgentSettingsActivity::class.java)) })

        val sc = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(10), dp(8), dp(10), dp(8))
        sc.addView(box, FrameLayout.LayoutParams(MATCH, WRAP))
        f.root.addView(sc, LinearLayout.LayoutParams(MATCH, 0, 1f))
        chatBox = box
        scroll = sc

        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.setBackgroundColor(C_TOOLBAR)
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(dp(6), dp(6), dp(6), dp(2))
        val quick = listOf(
            "یک بازی ساده‌ی لمسی بساز و پیش‌نمایش بده",
            "با پایتون یک مدل سه‌بعدی بساز",
            "فایل‌های پروژه را بررسی کن",
            "در اینترنت جست‌وجو کن:",
            "با ترموکس محیط را بررسی کن (nova doctor)"
        )
        for (q in quick) {
            val chip = TextView(this)
            chip.text = q
            chip.textSize = 13f
            chip.setTextColor(C_TEXT)
            chip.background = roundRect(C_PILL, 16, C_PILL_STROKE, 1)
            chip.setPadding(dp(12), dp(7), dp(12), dp(7))
            chip.setOnClickListener {
                input?.setText(q)
                input?.setSelection(q.length)
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(dp(3), 0, dp(3), 0)
            chips.addView(chip, lp)
        }
        chipScroll.addView(chips)
        f.root.addView(chipScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(C_TOOLBAR)
        bar.setPadding(dp(8), dp(6), dp(8), dp(8))
        val ed = EditText(this)
        ed.hint = "با دستیار صحبت کنید…"
        ed.setHintTextColor(C_MUTED)
        ed.setTextColor(C_TEXT)
        ed.textSize = 15f
        ed.background = roundRect(C_PILL, 22)
        ed.setPadding(dp(16), dp(10), dp(16), dp(10))
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        ed.maxLines = 5
        ed.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        input = ed
        bar.addView(ed, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sendBtn = ImageView(this)
        sendBtn.setImageResource(R.drawable.ic_play)
        sendBtn.setColorFilter(Color.WHITE)
        sendBtn.setPadding(dp(11), dp(11), dp(11), dp(11))
        sendBtn.background = roundRect(C_ACCENT, 24)
        sendBtn.setOnClickListener { send() }
        val slp = LinearLayout.LayoutParams(dp(48), dp(48))
        slp.leftMargin = dp(8)
        bar.addView(sendBtn, slp)
        f.root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(f.root)
        loadHistory()
        if (history.isEmpty()) showWelcome()
    }

    override fun onResume() {
        super.onResume()
        ws = WorkspaceManager.get(this)
    }

    override fun onPause() {
        saveHistory()
        super.onPause()
    }

    // ------------------------------------------------------------------
    // history
    // ------------------------------------------------------------------

    private fun prefsStore() = getSharedPreferences("nova_ai", MODE_PRIVATE)

    private fun saveHistory() {
        val arr = JSONArray()
        val start = maxOf(0, history.size - 40)
        for (i in start until history.size) {
            val m = history[i]
            val o = JSONObject()
            o.put("r", m.role)
            o.put("c", if (m.content.length > 20000) m.content.substring(0, 20000) else m.content)
            arr.put(o)
        }
        prefsStore().edit().putString("chat", arr.toString()).apply()
    }

    private fun loadHistory() {
        try {
            val arr = JSONArray(prefsStore().getString("chat", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(ChatMsg(o.getString("r"), o.getString("c")))
            }
        } catch (e: Exception) {
            history.clear()
        }
        for (m in history) {
            if (m.role == "user" && m.content.startsWith("TOOL_RESULT")) {
                addToolResult("", m.content.removePrefix("TOOL_RESULT").trim())
            } else {
                addBubble(m.content, m.role == "user")
            }
        }
    }

    private fun newChat() {
        if (busy) {
            toast("صبر کنید تا پاسخ تمام شود")
            return
        }
        history.clear()
        chatBox?.removeAllViews()
        saveHistory()
        showWelcome()
    }

    private fun showWelcome() {
        val tv = TextView(this)
        tv.text = "سلام! من دستیار نوا هستم.\n\nمی‌توانم برنامه و بازی بنویسم، مدل سه‌بعدی با پایتون بسازم، در اینترنت بگردم، فایل‌های پروژه را بخوانم و بنویسم و (با اجازه‌ی شما) در Termux دستور اجرا کنم.\n\nاگر هنوز دستیاری تنظیم نکرده‌اید، از آیکون ⚙ یک سرویس (مثلاً OpenAI، Claude، Gemini یا مدل محلی Ollama) و کلید API را اضافه کنید."
        tv.textSize = 14f
        tv.setTextColor(C_MUTED)
        tv.setPadding(dp(12), dp(24), dp(12), dp(12))
        chatBox?.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    // ------------------------------------------------------------------
    // sending + agent loop
    // ------------------------------------------------------------------

    private fun ui(block: () -> Unit) {
        runOnUiThread { block() }
    }

    private fun send() {
        if (busy) return
        val ed = input ?: return
        val text = ed.text.toString().trim()
        if (text.isEmpty()) return
        val p = AiStore.active(this)
        if (p == null) {
            toast("ابتدا از ⚙ یک دستیار اضافه کنید")
            startActivity(Intent(this, AgentSettingsActivity::class.java))
            return
        }
        if (p.model.isEmpty()) {
            toast("نام مدل را در تنظیمات دستیار وارد کنید")
            startActivity(Intent(this, AgentSettingsActivity::class.java))
            return
        }
        ed.setText("")
        if (history.isEmpty()) chatBox?.removeAllViews()
        history.add(ChatMsg("user", text))
        addBubble(text, true)
        runAgent(p)
    }

    private fun runAgent(p: AiProvider) {
        busy = true
        showThinking(true)
        Thread {
            try {
                var steps = 0
                while (steps < MAX_STEPS) {
                    steps += 1
                    val start = maxOf(0, history.size - 24)
                    val reply = AiClient.chat(p, SYSTEM_PROMPT, ArrayList(history.subList(start, history.size)))
                    history.add(ChatMsg("assistant", reply))
                    ui {
                        addBubble(reply, false)
                        saveHistory()
                    }
                    val calls = AgentTools.parse(reply)
                    if (calls.isEmpty()) break
                    val sb = StringBuilder("TOOL_RESULT\n")
                    for (c in calls) {
                        val r = runTool(c)
                        ui { addToolResult(c.name, r) }
                        sb.append("[").append(c.name).append("]\n").append(r).append("\n\n")
                    }
                    history.add(ChatMsg("user", sb.toString().trim()))
                    ui { saveHistory() }
                    if (steps >= MAX_STEPS) ui { addNotice("به سقف مراحل رسیدم. اگر ادامه لازم است بنویسید «ادامه».") }
                }
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                ui { addNotice("خطا: " + msg) }
            } finally {
                ui {
                    busy = false
                    showThinking(false)
                }
            }
        }.start()
    }

    private fun askApproval(title: String, detail: String): Boolean {
        val latch = CountDownLatch(1)
        var result = false
        runOnUiThread {
            try {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(detail)
                    .setPositiveButton("اجازه") { _, _ ->
                        result = true
                        latch.countDown()
                    }
                    .setNegativeButton("رد") { _, _ -> latch.countDown() }
                    .setOnCancelListener { latch.countDown() }
                    .show()
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        latch.await()
        return result
    }

    private fun clip(s: String, max: Int): String = if (s.length > max) s.substring(0, max) + "\n…(بریده شد)" else s

    private fun runTool(c: ToolCall): String {
        val a: JSONObject = c.args ?: return "خطا: " + (c.error ?: "فراخوانی نامعتبر")
        try {
            when (c.name) {
                "list_files" -> {
                    val names = ws.list(a.optString("path", ""))
                    return if (names.isEmpty()) "(خالی)" else names.joinToString("\n")
                }
                "read_file" -> {
                    val t = ws.readText(a.optString("path"))
                    return if (t == null) "فایل پیدا نشد" else clip(t, 20000)
                }
                "write_file" -> {
                    val path = a.optString("path")
                    val content = a.optString("content")
                    if (path.isEmpty()) return "خطا: path خالی است"
                    if (!AiStore.autoWrite(this)) {
                        val ok = askApproval("نوشتن فایل", path + "\n(" + content.length + " نویسه)")
                        if (!ok) return "کاربر اجازه نداد."
                    }
                    return if (ws.writeText(path, content)) "نوشته شد: " + path else "نوشتن ناموفق بود"
                }
                "delete_file" -> {
                    val path = a.optString("path")
                    if (!askApproval("حذف فایل", path)) return "کاربر اجازه نداد."
                    return if (ws.delete(path)) "حذف شد" else "حذف ناموفق بود"
                }
                "web_search" -> return clip(AgentTools.webSearch(a.optString("query")), 8000)
                "web_fetch" -> return AgentTools.webFetch(a.optString("url"))
                "preview" -> {
                    val path = a.optString("path", "index.html")
                    ui {
                        val i = Intent(this, ProjectPreviewActivity::class.java)
                        i.putExtra("entry", path)
                        startActivity(i)
                    }
                    return "پیش‌نمایش باز شد: " + path
                }
                "open_studio" -> {
                    val path = a.optString("path")
                    val code = ws.readText(path) ?: return "فایل پیدا نشد"
                    getSharedPreferences("nova_py", MODE_PRIVATE).edit().putString("code", code).apply()
                    ui { startActivity(Intent(this, PyStudioActivity::class.java)) }
                    return "در استودیوی ۳بعدی باز شد: " + path
                }
                "termux" -> return termuxTool(a.optString("command"))
                else -> return "ابزار ناشناخته: " + c.name
            }
        } catch (e: Exception) {
            return "خطا: " + (e.message ?: e.javaClass.simpleName)
        }
        return ""
    }

    private fun termuxTool(cmd: String): String {
        if (cmd.isBlank()) return "خطا: دستور خالی است"
        if (!TermuxBridge.available(this)) return "Termux متصل نیست: در تنظیمات دستیار پوشه‌ی مشترک را انتخاب کنید و در Termux «nova daemon» را اجرا کنید."
        if (!askApproval("اجرای دستور در Termux", cmd)) return "کاربر اجازه نداد."
        val latch = CountDownLatch(1)
        var res: TermuxResult? = null
        runOnUiThread {
            TermuxBridge.run(this, cmd, 240000L) { r ->
                res = r
                latch.countDown()
            }
        }
        latch.await()
        val r = res ?: return "نتیجه‌ای دریافت نشد"
        if (!r.ok) return "خطا: " + r.error + (if (r.stderr.isNotEmpty()) "\n" + clip(r.stderr, 3000) else "")
        return "exit=" + r.exitCode + "\n" + clip(r.stdout, 6000) + (if (r.stderr.isNotEmpty()) "\n[stderr]\n" + clip(r.stderr, 3000) else "")
    }

    // ------------------------------------------------------------------
    // rendering
    // ------------------------------------------------------------------

    private fun scrollDown() {
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showThinking(on: Boolean) {
        val box = chatBox ?: return
        if (on) {
            val tv = TextView(this)
            tv.text = "در حال فکر کردن…"
            tv.textSize = 13f
            tv.setTextColor(C_MUTED)
            tv.setPadding(dp(12), dp(8), dp(12), dp(8))
            thinking = tv
            box.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
            scrollDown()
        } else {
            val t = thinking
            if (t != null) box.removeView(t)
            thinking = null
        }
    }

    private fun addNotice(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(C_DANGER)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        insertBeforeThinking(tv)
    }

    private fun insertBeforeThinking(v: View) {
        val box = chatBox ?: return
        val t = thinking
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(4), 0, dp(4))
        if (t != null) {
            val idx = box.indexOfChild(t)
            box.addView(v, if (idx >= 0) idx else box.childCount, lp)
        } else {
            box.addView(v, lp)
        }
        scrollDown()
    }

    private fun addBubble(text: String, isUser: Boolean) {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.background = roundRect(if (isUser) Color.parseColor("#2B3180") else C_PILL, 16, C_PILL_STROKE, 1)
        wrap.setPadding(dp(12), dp(8), dp(12), dp(8))
        wrap.addView(renderMessage(text), LinearLayout.LayoutParams(MATCH, WRAP))
        insertBeforeThinking(wrap)
    }

    private fun addToolResult(name: String, text: String) {
        val tv = TextView(this)
        val shown = if (text.length > 700) text.substring(0, 700) + "…" else text
        tv.text = (if (name.isEmpty()) "🔧 " else "🔧 " + name + ": ") + shown
        tv.textSize = 12f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(C_MUTED)
        tv.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        tv.setBackgroundColor(Color.parseColor("#0A0C24"))
        tv.setPadding(dp(10), dp(6), dp(10), dp(6))
        insertBeforeThinking(tv)
    }

    private fun renderMessage(text: String): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val lines = text.split("\n")
        val buf = StringBuilder()
        fun flushText() {
            val t = buf.toString().trim()
            buf.setLength(0)
            if (t.isEmpty()) return
            val tv = TextView(this)
            tv.text = t
            tv.textSize = 15f
            tv.setTextColor(C_TEXT)
            tv.setTextIsSelectable(true)
            tv.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            tv.setPadding(0, dp(2), 0, dp(2))
            col.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.trimStart().startsWith("```")) {
                flushText()
                val lang = line.trim().removePrefix("```").trim()
                val code = StringBuilder()
                i += 1
                while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                    code.append(lines[i]).append("\n")
                    i += 1
                }
                i += 1
                if (lang == "nova-tool") {
                    col.addView(toolChip(code.toString()), LinearLayout.LayoutParams(MATCH, WRAP))
                } else {
                    col.addView(codeBlock(lang, code.toString().trimEnd('\n')), LinearLayout.LayoutParams(MATCH, WRAP))
                }
            } else {
                buf.append(line).append("\n")
                i += 1
            }
        }
        flushText()
        return col
    }

    private fun toolChip(json: String): View {
        var label = "🔧 فراخوانی ابزار"
        try {
            val j = JSONObject(json)
            val extra = j.optString("path", j.optString("url", j.optString("query", j.optString("command", ""))))
            label = "🔧 " + j.optString("tool") + (if (extra.isNotEmpty()) " — " + (if (extra.length > 80) extra.substring(0, 80) + "…" else extra) else "")
        } catch (e: Exception) {
            // keep generic label
        }
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 13f
        tv.setTextColor(C_TAG2)
        tv.typeface = Typeface.MONOSPACE
        tv.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        tv.setPadding(0, dp(4), 0, dp(4))
        return tv
    }

    private fun codeBlock(lang: String, code: String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundRect(Color.parseColor("#080A1E"), 12, C_PILL_STROKE, 1)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(10), 0, dp(2), 0)
        val l = TextView(this)
        l.text = if (lang.isEmpty()) "code" else lang
        l.textSize = 12f
        l.setTextColor(C_MUTED)
        head.addView(l, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(iconButton(R.drawable.ic_save, 36, 18, C_MUTED) { saveSnippet(code, lang) })
        head.addView(iconButton(R.drawable.ic_copy, 36, 18, C_MUTED) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("code", code))
            toast("کپی شد")
        })
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val hs = HorizontalScrollView(this)
        val tv = TextView(this)
        tv.text = code
        tv.textSize = 12.5f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(C_TEXT)
        tv.setTextIsSelectable(true)
        tv.textDirection = View.TEXT_DIRECTION_LTR
        tv.setPadding(dp(10), dp(2), dp(10), dp(10))
        hs.addView(tv)
        box.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }

    private fun saveSnippet(code: String, lang: String) {
        val input = EditText(this)
        val ext = when (lang.lowercase()) {
            "python", "py" -> "py"
            "html" -> "html"
            "javascript", "js" -> "js"
            "css" -> "css"
            "json" -> "json"
            "bash", "sh" -> "sh"
            else -> "txt"
        }
        input.setText("snippet." + ext)
        input.setSingleLine(true)
        input.textDirection = View.TEXT_DIRECTION_LTR
        val holder = FrameLayout(this)
        holder.setPadding(dp(20), dp(8), dp(20), 0)
        holder.addView(input, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("ذخیره در پروژه")
            .setView(holder)
            .setPositiveButton("ذخیره") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    toast(if (ws.writeText(name, code)) "ذخیره شد: " + name else "ذخیره ناموفق بود")
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}
