package com.nova.browser

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

internal const val SYSTEM_PROMPT = """You are Nova Agent, a programming, game-making and project assistant that lives inside Nova Browser on an Android phone. Always answer in the language the user writes in (Persian if they write Persian). Be practical and concise.

TOOLS
To use a tool, write ONE fenced block per call, exactly like this (valid JSON; escape newlines inside strings as \n):
```nova-tool
{"tool":"write_file","path":"index.html","content":"<h1>Hello</h1>"}
```
Available tools:
- list_files {"path":""}                    list a folder of the project workspace
- read_file {"path":"src/main.py"}          read a text file
- write_file {"path":"a/b.txt","content":"..."}   create or overwrite a file (folders are created)
- delete_file {"path":"a/b.txt"}
- web_search {"query":"..."}                search the internet
- web_fetch {"url":"https://..."}           download a page as plain text
- preview {"path":"index.html"}             run a web project or HTML5 game inside Nova
- open_studio {"path":"model.py"}           open a nova3d Python script in Nova's 3D Studio (shows the model, exports GLB/STL/OBJ)
- termux {"command":"..."}                  run a shell command in Termux on this phone (the user must approve)
After a tool block STOP and wait. The result arrives in the next user message that starts with TOOL_RESULT. You may put several tool blocks in one reply. Never invent tool results and never claim you changed a file unless you called write_file.

WORKSPACE
All project files live in one workspace folder; use short relative paths (for example mygame/index.html). Prefer small clear files. Read a file before editing it. When you finish, tell the user what you created and how to run it.

GAMES
For games prefer a single-file HTML5 canvas game (touch friendly, no build step) that works with the preview tool. Use plain JavaScript unless the user asks for a library; libraries may be loaded from a CDN.

3D MODELS (nova3d, Python, Z is up)
from nova3d import *
shapes: box(w,d,h) cube(s) sphere(r) cylinder(r,h) cone(r,h) torus(R,r) extrude([(x,y),..],h) revolve([(r,z),..]) tube([(x,y,z),..],r) surface(f,u,v) heightmap(f,x,y,n,base) polyhedron(vertices,faces) gear(teeth,module,thickness,hole)
transforms: .move(x,y,z) .rotate(x,y,z) .scale(s) .mirror('x') .color('#ff8800')
boolean: a + b (union), a - b (difference), a & b (intersection); combine(a,b); polar(m,n); linear(m,n,dx,dy,dz)
finish with scene(shape1, shape2, ...). Save scripts as .py files and open them with open_studio. In Termux the user can also run: nova model script.py out.glb

TERMUX
Only use the termux tool when it is really needed (installing packages, running python, converting files with the nova command, signing APKs with: nova sign app.apk). Show a safe, minimal command. Never run destructive commands (rm -rf on home, formatting, etc.)."""

internal class ToolCall(val name: String, val args: JSONObject?, val error: String?)

internal object AgentTools {
    private val blockRegex = Regex("```nova-tool\\s*([\\s\\S]*?)```")

    fun parse(reply: String): List<ToolCall> {
        val out = ArrayList<ToolCall>()
        for (m in blockRegex.findAll(reply)) {
            val raw = m.groupValues[1].trim()
            try {
                val j = JSONObject(raw)
                out.add(ToolCall(j.optString("tool"), j, null))
            } catch (e: Exception) {
                out.add(ToolCall("invalid", null, "JSON نامعتبر: " + (e.message ?: "")))
            }
        }
        return out
    }

    private fun decodeEntities(s: String): String {
        return s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&")
    }

    fun htmlToText(html: String): String {
        var t = html.replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
        t = t.replace(Regex("(?s)<!--.*?-->"), " ")
        t = t.replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</li>|</h[1-6]>|</tr>"), "\n")
        t = t.replace(Regex("<[^>]+>"), " ")
        t = decodeEntities(t)
        t = t.replace(Regex("[ \\t\\u00a0]+"), " ")
        t = t.replace(Regex("\\n\\s*\\n+"), "\n\n")
        return t.trim()
    }

    /** GET with manual redirects (also http -> https), at most about 1.5 MB. */
    fun fetch(url: String): Pair<Int, String> {
        var current = url
        for (hop in 0 until 6) {
            val u = URL(current)
            if (u.protocol != "http" && u.protocol != "https") throw Exception("فقط http و https مجاز است")
            val conn = u.openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) NovaBrowser/0.7")
                conn.setRequestProperty("Accept", "text/html,application/json,text/plain,*/*")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (loc != null) {
                        current = URL(u, loc).toString()
                        continue
                    }
                }
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val sb = StringBuilder()
                if (stream != null) {
                    stream.bufferedReader(Charsets.UTF_8).use { r ->
                        val buf = CharArray(8192)
                        while (sb.length < 1500000) {
                            val n = r.read(buf)
                            if (n < 0) break
                            sb.append(buf, 0, n)
                        }
                    }
                }
                return Pair(code, sb.toString())
            } finally {
                conn.disconnect()
            }
        }
        throw Exception("تعداد ریدایرکت‌ها زیاد است")
    }

    fun webFetch(url: String): String {
        val (code, body) = fetch(url)
        val isHtml = body.contains("<html", true) || body.contains("<body", true) || body.contains("<div", true)
        val text = if (isHtml) htmlToText(body) else body
        val cut = if (text.length > 12000) text.substring(0, 12000) + "\n…(بریده شد)" else text
        return "HTTP " + code + "\n" + cut
    }

    fun webSearch(query: String): String {
        val (code, body) = fetch("https://html.duckduckgo.com/html/?q=" + Uri.encode(query))
        if (code !in 200..299) return "جست‌وجو ناموفق بود (HTTP " + code + ")"
        val links = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</a>").findAll(body).toList()
        val snippets = Regex("class=\"result__snippet\"[^>]*>([\\s\\S]*?)</a>").findAll(body).toList()
        if (links.isEmpty()) return "نتیجه‌ای پیدا نشد (ممکن است جست‌وجو مسدود شده باشد). از web_fetch با آدرس مستقیم استفاده کنید."
        val sb = StringBuilder()
        var n = 0
        for (i in links.indices) {
            if (n >= 8) break
            var href = decodeEntities(links[i].groupValues[1])
            val k = href.indexOf("uddg=")
            if (k >= 0) {
                var enc = href.substring(k + 5)
                val amp = enc.indexOf('&')
                if (amp >= 0) enc = enc.substring(0, amp)
                href = Uri.decode(enc)
            } else if (href.startsWith("//")) {
                href = "https:" + href
            }
            val title = htmlToText(links[i].groupValues[2])
            val snip = if (i < snippets.size) htmlToText(snippets[i].groupValues[1]) else ""
            n += 1
            sb.append(n).append(". ").append(title).append("\n").append(href).append("\n").append(snip).append("\n\n")
        }
        return sb.toString().trim()
    }
}
