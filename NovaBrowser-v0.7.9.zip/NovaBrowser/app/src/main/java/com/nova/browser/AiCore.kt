package com.nova.browser

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** API keys are encrypted with an Android Keystore key and never leave the device except to the chosen provider. */
internal object SecureStore {
    private const val ALIAS = "nova_ai_key_v1"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        if (!ks.containsAlias(ALIAS)) {
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            kg.init(spec)
            kg.generateKey()
        }
        return ks.getKey(ALIAS, null) as SecretKey
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = c.iv
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + ct, Base64.NO_WRAP)
    }

    fun decrypt(data: String): String? {
        return try {
            val raw = Base64.decode(data, Base64.NO_WRAP)
            val iv = raw.copyOfRange(0, 12)
            val ct = raw.copyOfRange(12, raw.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

internal class AiProvider(var name: String, var format: String, var baseUrl: String, var model: String, var encKey: String) {
    fun apiKey(): String = if (encKey.isEmpty()) "" else (SecureStore.decrypt(encKey) ?: "")

    fun setKey(key: String) {
        encKey = if (key.isEmpty()) "" else SecureStore.encrypt(key)
    }
}

internal class Preset(val name: String, val format: String, val baseUrl: String, val hint: String)

internal val AI_PRESETS = listOf(
    Preset("OpenAI", "openai", "https://api.openai.com/v1", "کلید از platform.openai.com"),
    Preset("Anthropic (Claude)", "anthropic", "https://api.anthropic.com", "کلید از console.anthropic.com"),
    Preset("Google Gemini", "gemini", "https://generativelanguage.googleapis.com", "کلید از aistudio.google.com"),
    Preset("OpenRouter (مدل‌های متعدد)", "openai", "https://openrouter.ai/api/v1", "کلید از openrouter.ai"),
    Preset("Groq", "openai", "https://api.groq.com/openai/v1", "کلید از console.groq.com"),
    Preset("DeepSeek", "openai", "https://api.deepseek.com/v1", "کلید از platform.deepseek.com"),
    Preset("Mistral", "openai", "https://api.mistral.ai/v1", "کلید از console.mistral.ai"),
    Preset("Ollama روی همین گوشی (Termux)", "openai", "http://127.0.0.1:11434/v1", "بدون کلید؛ ollama باید در Termux اجرا باشد"),
    Preset("llama.cpp روی همین گوشی (Termux)", "openai", "http://127.0.0.1:8080/v1", "بدون کلید؛ llama-server باید در Termux اجرا باشد"),
    Preset("سرور دلخواه سازگار با OpenAI", "openai", "", "آدرس پایه را خودتان وارد کنید")
)

internal object AiStore {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("nova_ai", Context.MODE_PRIVATE)

    fun load(ctx: Context): ArrayList<AiProvider> {
        val out = ArrayList<AiProvider>()
        try {
            val arr = JSONArray(sp(ctx).getString("providers", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(AiProvider(o.optString("name"), o.optString("format"), o.optString("base"), o.optString("model"), o.optString("key")))
            }
        } catch (e: Exception) {
            // ignore broken data
        }
        return out
    }

    fun save(ctx: Context, list: List<AiProvider>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("name", p.name)
            o.put("format", p.format)
            o.put("base", p.baseUrl)
            o.put("model", p.model)
            o.put("key", p.encKey)
            arr.put(o)
        }
        sp(ctx).edit().putString("providers", arr.toString()).apply()
    }

    fun activeIndex(ctx: Context): Int = sp(ctx).getInt("active", 0)

    fun setActive(ctx: Context, index: Int) {
        sp(ctx).edit().putInt("active", index).apply()
    }

    fun active(ctx: Context): AiProvider? {
        val l = load(ctx)
        if (l.isEmpty()) return null
        return l[activeIndex(ctx).coerceIn(0, l.size - 1)]
    }

    fun autoWrite(ctx: Context): Boolean = sp(ctx).getBoolean("auto_write", false)

    fun setAutoWrite(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("auto_write", v).apply()
    }
}

internal class ChatMsg(val role: String, val content: String)

internal object Http {
    fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeoutMs: Int): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 20000
            conn.readTimeout = timeoutMs
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            conn.disconnect()
        }
    }
}

internal object AiClient {
    private fun merge(msgs: List<ChatMsg>): List<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        for (m in msgs) {
            if (out.isNotEmpty() && out[out.size - 1].role == m.role) {
                val last = out.removeAt(out.size - 1)
                out.add(ChatMsg(m.role, last.content + "\n\n" + m.content))
            } else {
                out.add(m)
            }
        }
        return out
    }

    private fun base(p: AiProvider): String = p.baseUrl.trim().trimEnd('/')

    private fun errorText(code: Int, body: String): String {
        var msg = body.trim()
        try {
            val j = JSONObject(body)
            val e = j.opt("error")
            if (e is JSONObject) msg = e.optString("message", msg) else if (e is String) msg = e
        } catch (ex: Exception) {
            // keep raw body
        }
        if (msg.length > 400) msg = msg.substring(0, 400)
        return "HTTP " + code + ": " + msg
    }

    fun chat(p: AiProvider, system: String, msgs: List<ChatMsg>): String {
        val key = p.apiKey()
        val b = base(p)
        val list = merge(msgs)
        val headers = HashMap<String, String>()
        headers["Content-Type"] = "application/json"
        if (p.format == "anthropic") {
            headers["x-api-key"] = key
            headers["anthropic-version"] = "2023-06-01"
            val arr = JSONArray()
            for (m in list) arr.put(JSONObject().put("role", m.role).put("content", m.content))
            val body = JSONObject().put("model", p.model).put("max_tokens", 4096).put("system", system).put("messages", arr)
            val (code, text) = Http.request("POST", b + "/v1/messages", headers, body.toString(), 180000)
            if (code !in 200..299) throw Exception(errorText(code, text))
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val part = content.getJSONObject(i)
                if (part.optString("type") == "text") sb.append(part.optString("text"))
            }
            return sb.toString()
        }
        if (p.format == "gemini") {
            headers["x-goog-api-key"] = key
            val contents = JSONArray()
            for (m in list) {
                val role = if (m.role == "assistant") "model" else "user"
                val parts = JSONArray().put(JSONObject().put("text", m.content))
                contents.put(JSONObject().put("role", role).put("parts", parts))
            }
            val sys = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            val body = JSONObject().put("systemInstruction", sys).put("contents", contents)
            val model = p.model.removePrefix("models/")
            val (code, text) = Http.request("POST", b + "/v1beta/models/" + model + ":generateContent", headers, body.toString(), 180000)
            if (code !in 200..299) throw Exception(errorText(code, text))
            val cands = JSONObject(text).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) throw Exception("پاسخ خالی از Gemini")
            val parts = cands.getJSONObject(0).getJSONObject("content").optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            }
            return sb.toString()
        }
        // OpenAI-compatible
        if (key.isNotEmpty()) headers["Authorization"] = "Bearer " + key
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        for (m in list) arr.put(JSONObject().put("role", m.role).put("content", m.content))
        val body = JSONObject().put("model", p.model).put("messages", arr)
        val (code, text) = Http.request("POST", b + "/chat/completions", headers, body.toString(), 180000)
        if (code !in 200..299) throw Exception(errorText(code, text))
        val msg = JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val c = msg.opt("content")
        return if (c is String) c else (c?.toString() ?: "")
    }

    fun listModels(p: AiProvider): List<String> {
        val key = p.apiKey()
        val b = base(p)
        val headers = HashMap<String, String>()
        val out = ArrayList<String>()
        if (p.format == "anthropic") {
            headers["x-api-key"] = key
            headers["anthropic-version"] = "2023-06-01"
            val (code, text) = Http.request("GET", b + "/v1/models?limit=100", headers, null, 30000)
            if (code !in 200..299) throw Exception(errorText(code, text))
            val data = JSONObject(text).getJSONArray("data")
            for (i in 0 until data.length()) out.add(data.getJSONObject(i).optString("id"))
        } else if (p.format == "gemini") {
            headers["x-goog-api-key"] = key
            val (code, text) = Http.request("GET", b + "/v1beta/models?pageSize=100", headers, null, 30000)
            if (code !in 200..299) throw Exception(errorText(code, text))
            val data = JSONObject(text).getJSONArray("models")
            for (i in 0 until data.length()) {
                val m = data.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods")
                var ok = methods == null
                if (methods != null) {
                    for (k in 0 until methods.length()) {
                        if (methods.getString(k) == "generateContent") ok = true
                    }
                }
                if (ok) out.add(m.optString("name").removePrefix("models/"))
            }
        } else {
            if (key.isNotEmpty()) headers["Authorization"] = "Bearer " + key
            val (code, text) = Http.request("GET", b + "/models", headers, null, 30000)
            if (code !in 200..299) throw Exception(errorText(code, text))
            val data = JSONObject(text).getJSONArray("data")
            for (i in 0 until data.length()) out.add(data.getJSONObject(i).optString("id"))
        }
        out.sort()
        return out
    }
}
