package com.nova.browser

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val REQ_PICK = 3001
private const val REQ_WRITE = 3002

// ----------------------------------------------------------------------
// File center
// ----------------------------------------------------------------------

class FilesActivity : PageActivity() {
    private var forced: String? = null
    private var filter = "all"

    private val kinds = listOf(
        Pair("all", "همه"),
        Pair("pdf", "PDF"),
        Pair("3d", "سه‌بعدی"),
        Pair("code", "کد و متن"),
        Pair("win", "ویندوز"),
        Pair("image", "تصویر"),
        Pair("video", "ویدئو"),
        Pair("other", "سایر")
    )

    override fun pageTitle(): String = "مرکز فایل"

    override fun render() {
        heading("برنامه‌نویسی و ساخت")
        val studio = card()
        actionRow(studio, R.drawable.ic_chat, "دستیار هوشمند و محیط برنامه‌نویسی", "چت، پروژه، جست‌وجوی وب، Termux و بازی‌سازی", false) {
            startActivity(Intent(this, AgentActivity::class.java))
        }
        actionRow(studio, R.drawable.ic_code, "استودیوی پایتون ۳بعدی", "با کد پایتون مدل بسازید، ببینید و GLB/STL/OBJ ذخیره کنید", false) {
            startActivity(Intent(this, PyStudioActivity::class.java))
        }

        heading("باز کردن فایل از دستگاه")
        val c = card()
        actionRow(c, R.drawable.ic_file, "هر فایل…", "نوع فایل خودکار تشخیص داده می‌شود", false) { pick(null) }
        actionRow(c, R.drawable.ic_cube, "نمایشگر سه‌بعدی", "فایل‌های GLB و GLTF", false) { pick("3d") }
        actionRow(c, R.drawable.ic_file, "خواندن PDF", "نمایش صفحه‌ها، حالت شب، رفتن به صفحه", false) { pick("pdf") }
        actionRow(c, R.drawable.ic_code, "ویرایشگر کد و متن", "HTML، CSS، JS، Python، JSON و …", false) { pick("code") }
        actionRow(c, R.drawable.ic_desktop, "فایل ویندوز (EXE / MSI)", "اطلاعات فایل و ارسال به Winlator", false) { pick("win") }

        heading("دانلودهای نوا")
        val scroller = HorizontalScrollView(this)
        scroller.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for (k in kinds) {
            val chip = TextView(this)
            chip.text = k.second
            chip.textSize = 14f
            val on = k.first == filter
            chip.setTextColor(if (on) C_TEXT else C_MUTED)
            chip.background = roundRect(if (on) C_ACCENT else C_PILL, 18, C_PILL_STROKE, 1)
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            chip.setOnClickListener {
                filter = k.first
                rerender()
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(0, 0, dp(8), 0)
            chips.addView(chip, lp)
        }
        scroller.addView(chips)
        body.addView(scroller, LinearLayout.LayoutParams(MATCH, WRAP))

        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        var shown = 0
        val q = DownloadManager.Query()
        q.setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL)
        val cur = dm.query(q)
        if (cur != null) {
            try {
                val iId = cur.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = cur.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iMime = cur.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
                val iSize = cur.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                while (cur.moveToNext()) {
                    val title = cur.getString(iTitle) ?: "file"
                    val mime = cur.getString(iMime)
                    val kind = FileOpener.kindOf(title, mime)
                    if (filter != "all" && filter != kind) continue
                    shown += 1
                    addFileRow(dm, cur.getLong(iId), title, mime, cur.getLong(iSize), kind)
                }
            } finally {
                cur.close()
            }
        }
        if (shown == 0) note("فایلی در این دسته نیست.")
    }

    private fun kindLabel(kind: String): String {
        for (k in kinds) {
            if (k.first == kind) return k.second
        }
        return kind
    }

    private fun addFileRow(dm: DownloadManager, id: Long, title: String, mime: String?, size: Long, kind: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
        row.setPadding(dp(12), dp(10), dp(12), dp(10))

        val icon = ImageView(this)
        icon.setImageResource(
            when (kind) {
                "3d" -> R.drawable.ic_cube
                "code" -> R.drawable.ic_code
                "win" -> R.drawable.ic_desktop
                else -> R.drawable.ic_file
            }
        )
        icon.setColorFilter(C_ACCENT_LIGHT)
        row.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, 0, 0)
        val name = TextView(this)
        name.text = title
        name.textSize = 15f
        name.setTextColor(C_TEXT)
        name.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        col.addView(ellipsized(name))
        val info = TextView(this)
        info.text = kindLabel(kind) + (if (size > 0) " • " + faDigits(Formatter.formatShortFileSize(this, size)) else "")
        info.textSize = 12f
        info.setTextColor(C_MUTED)
        col.addView(info)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        row.setOnClickListener {
            val uri = dm.getUriForDownloadedFile(id)
            if (uri == null) {
                toast("فایل پیدا نشد")
            } else {
                FileOpener.open(this, uri, title, mime, null)
            }
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(8)
        body.addView(row, lp)
    }

    private fun pick(kind: String?) {
        forced = kind
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (kind == "pdf") "application/pdf" else "*/*"
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("انتخاب فایل ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null) {
            val uri = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                // permission could not be persisted; reading now still works
            }
            FileOpener.open(this, uri, displayName(uri), contentResolver.getType(uri), forced)
        }
    }
}

// ----------------------------------------------------------------------
// Windows file info + hand-off to Winlator
// ----------------------------------------------------------------------

class WindowsFileActivity : PageActivity() {
    private var fileUri: Uri? = null
    private var fileName = ""
    private var parsed = false
    private var sizeText = ""
    private var typeText = "نامشخص"
    private var archText = "نامشخص"
    private var subsystemText = "نامشخص"
    private var stampText = "نامشخص"
    private var archOk = false
    private var sha = ""

    override fun pageTitle(): String = "فایل ویندوز"

    private fun le16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun le32(b: ByteArray, o: Int): Long = le16(b, o).toLong() or (le16(b, o + 2).toLong() shl 16)

    private fun parse(u: Uri) {
        val size = fileSize(u)
        sizeText = if (size >= 0) faDigits(Formatter.formatShortFileSize(this, size)) else "نامشخص"
        var buf = ByteArray(0)
        try {
            val s = contentResolver.openInputStream(u)
            if (s != null) {
                s.use { input ->
                    val b = ByteArray(65536)
                    val n = input.read(b)
                    if (n > 0) buf = b.copyOf(n)
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        if (buf.size >= 64 && (buf[0].toInt() and 0xFF) == 0x4D && (buf[1].toInt() and 0xFF) == 0x5A) {
            val pe = le32(buf, 0x3C).toInt()
            if (pe > 0 && pe + 100 < buf.size &&
                (buf[pe].toInt() and 0xFF) == 0x50 && (buf[pe + 1].toInt() and 0xFF) == 0x45 &&
                buf[pe + 2].toInt() == 0 && buf[pe + 3].toInt() == 0
            ) {
                val machine = le16(buf, pe + 4)
                val ts = le32(buf, pe + 8)
                val chars = le16(buf, pe + 22)
                val magic = le16(buf, pe + 24)
                val subsystem = le16(buf, pe + 24 + 68)
                typeText = (if ((chars and 0x2000) != 0) "کتابخانه (DLL)" else "برنامه‌ی اجرایی (EXE)") +
                    (if (magic == 0x20B) " - PE32+" else " - PE32")
                when (machine) {
                    0x14C -> {
                        archText = "x86 (۳۲ بیتی)"
                        archOk = true
                    }
                    0x8664 -> {
                        archText = "x64 (۶۴ بیتی)"
                        archOk = true
                    }
                    0xAA64 -> archText = "ARM64"
                    0x1C4 -> archText = "ARM"
                    else -> archText = "کد " + machine.toString(16)
                }
                subsystemText = when (subsystem) {
                    2 -> "رابط گرافیکی (GUI)"
                    3 -> "خط فرمان (Console)"
                    else -> "کد " + subsystem.toString()
                }
                if (ts > 0) stampText = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ts * 1000L))
            } else {
                typeText = "فایل MZ (ساختار PE شناسایی نشد)"
            }
        } else if (buf.size >= 8 && (buf[0].toInt() and 0xFF) == 0xD0 && (buf[1].toInt() and 0xFF) == 0xCF) {
            typeText = "نصب‌کننده‌ی MSI (یا فایل OLE)"
        } else {
            typeText = "قالب ویندوز شناخته نشد"
        }
    }

    override fun render() {
        val u = intent.data
        if (u == null) {
            note("فایلی انتخاب نشده است.")
            return
        }
        fileUri = u
        fileName = intent.getStringExtra("name") ?: displayName(u)
        if (!parsed) {
            parsed = true
            parse(u)
        }

        heading("اطلاعات فایل")
        val info = card()
        addInfo(info, "نام", fileName)
        addInfo(info, "اندازه", sizeText)
        addInfo(info, "نوع", typeText)
        addInfo(info, "معماری", archText)
        addInfo(info, "زیرسیستم", subsystemText)
        addInfo(info, "تاریخ ساخت", stampText)
        addInfo(info, "SHA-256", if (sha.isEmpty()) "محاسبه نشده" else sha)

        if (!archOk && archText != "نامشخص") {
            note("توجه: Winlator معمولاً فقط برنامه‌های x86 و x64 را اجرا می‌کند.")
        }

        heading("کارها")
        val actions = card()
        actionRow(actions, R.drawable.ic_check, "محاسبه‌ی SHA-256", "برای مقایسه با مقدار منتشرشده‌ی سازنده", false) { computeHash() }
        actionRow(actions, R.drawable.ic_desktop, "ارسال به Winlator", "کپی در Download/Nova و باز کردن Winlator", false) { confirmSend() }
        note("نوا برنامه‌های ویندوز را خودش اجرا نمی‌کند. فایل فقط با تأیید شما برای Winlator آماده می‌شود و موفقیت اجرا به سازگاری برنامه و دستگاه بستگی دارد. فقط فایل‌های مطمئن را اجرا کنید.")
    }

    private fun addInfo(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        val l = TextView(this)
        l.text = label
        l.textSize = 15f
        l.setTextColor(C_MUTED)
        row.addView(l, LinearLayout.LayoutParams(WRAP, WRAP))
        val v = TextView(this)
        v.text = value
        v.textSize = 14f
        v.setTextColor(C_TEXT)
        v.gravity = Gravity.END
        v.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = dp(12)
        row.addView(v, lp)
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun computeHash() {
        val u = fileUri ?: return
        toast("در حال محاسبه…")
        Thread {
            var result = ""
            try {
                val md = MessageDigest.getInstance("SHA-256")
                val s = contentResolver.openInputStream(u)
                if (s != null) {
                    s.use { input ->
                        val b = ByteArray(65536)
                        while (true) {
                            val n = input.read(b)
                            if (n < 0) break
                            md.update(b, 0, n)
                        }
                    }
                    val sb = StringBuilder()
                    for (x in md.digest()) sb.append(String.format("%02x", x))
                    result = sb.toString()
                }
            } catch (e: Exception) {
                result = ""
            }
            runOnUiThread {
                if (result.isEmpty()) {
                    toast("محاسبه ناموفق بود")
                } else {
                    sha = result
                    rerender()
                }
            }
        }.start()
    }

    private fun confirmSend() {
        AlertDialog.Builder(this)
            .setTitle("ارسال به Winlator")
            .setMessage("فایل «" + fileName + "» در پوشه‌ی Download/Nova کپی می‌شود و Winlator باز می‌شود. این فایل را فقط اگر به منبعش اعتماد دارید اجرا کنید.")
            .setPositiveButton("ادامه") { _, _ -> sendToWinlator() }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun sendToWinlator() {
        val u = fileUri ?: return
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_WRITE)
            toast("اجازه‌ی حافظه را بدهید و دوباره بزنید")
            return
        }
        toast("در حال کپی فایل…")
        Thread {
            var ok = false
            try {
                ok = copyToDownloads(u, fileName)
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                if (ok) showLaunchDialog() else toast("کپی فایل ناموفق بود")
            }
        }.start()
    }

    private fun copyToDownloads(u: Uri, name: String): Boolean {
        val input = contentResolver.openInputStream(u) ?: return false
        input.use { src ->
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nova")
                val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                val out = contentResolver.openOutputStream(target) ?: return false
                out.use { dst -> src.copyTo(dst) }
            } else {
                val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nova")
                dir.mkdirs()
                java.io.FileOutputStream(java.io.File(dir, name)).use { dst -> src.copyTo(dst) }
            }
        }
        return true
    }

    private fun showLaunchDialog() {
        var launch: Intent? = null
        val pkgs = listOf("com.winlator", "com.winlator.cmod")
        for (p in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                launch = i
                break
            }
        }
        val target = launch
        val b = AlertDialog.Builder(this)
            .setTitle("آماده شد")
            .setNegativeButton("بستن", null)
        if (target != null) {
            b.setMessage("فایل در Download/Nova ذخیره شد. در Winlator همان پوشه را باز کنید و فایل را اجرا کنید.")
            b.setPositiveButton("باز کردن Winlator") { _, _ -> startActivity(target) }
        } else {
            b.setMessage("فایل در Download/Nova ذخیره شد، اما Winlator روی این دستگاه پیدا نشد. پس از نصب Winlator آن را از همان پوشه اجرا کنید.")
        }
        b.show()
    }
}
