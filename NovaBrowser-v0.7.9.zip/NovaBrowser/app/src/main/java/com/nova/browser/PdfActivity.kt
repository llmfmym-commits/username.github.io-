package com.nova.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView

/** PDF reader built on the platform PdfRenderer (offline, no libraries). */
class PdfActivity : Activity() {
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var cache: LruCache<Int, Bitmap>? = null
    private var night = false
    private var fileUri: Uri? = null
    private var fileName = "PDF"
    private var list: ListView? = null
    private var frame: ToolFrame? = null

    private val invertFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent.data
        if (u == null) {
            toast("فایلی انتخاب نشده است")
            finish()
            return
        }
        fileUri = u
        fileName = intent.getStringExtra("name") ?: displayName(u)
        val f = createToolFrame(fileName)
        frame = f

        try {
            val d = contentResolver.openFileDescriptor(u, "r")
            if (d == null) {
                toast("فایل باز نشد")
                finish()
                return
            }
            pfd = d
            renderer = PdfRenderer(d)
        } catch (e: Exception) {
            toast("این PDF باز نشد (شاید رمزدار یا خراب است)")
            finish()
            return
        }

        val maxMem = (Runtime.getRuntime().maxMemory() / 6).toInt()
        cache = object : LruCache<Int, Bitmap>(maxMem) {
            override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
        }

        f.header.addView(iconButton(R.drawable.ic_moon, 44, 22, C_TEXT) { toggleNight() })
        f.header.addView(iconButton(R.drawable.ic_list, 44, 22, C_TEXT) { askPage() })
        f.header.addView(iconButton(R.drawable.ic_share, 44, 22, C_TEXT) { openExternal() })

        val lv = ListView(this)
        lv.divider = ColorDrawable(Color.TRANSPARENT)
        lv.dividerHeight = dp(8)
        lv.setBackgroundColor(Color.parseColor("#2A2D3E"))
        lv.adapter = PageAdapter()
        lv.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {
            }

            override fun onScroll(view: AbsListView?, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {
                f.titleView.text = fileName + "  •  " + faDigits((firstVisibleItem + 1).toString() + "/" + totalItemCount.toString())
            }
        })
        list = lv
        f.root.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(f.root)
    }

    override fun onDestroy() {
        try {
            renderer?.close()
            pfd?.close()
        } catch (e: Exception) {
            // ignore
        }
        renderer = null
        pfd = null
        super.onDestroy()
    }

    private fun pageBitmap(index: Int): Bitmap? {
        val c = cache ?: return null
        val cached = c.get(index)
        if (cached != null) return cached
        val r = renderer ?: return null
        return try {
            synchronized(r) {
                val page = r.openPage(index)
                val w = resources.displayMetrics.widthPixels
                val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                c.put(index, bmp)
                bmp
            }
        } catch (e: Exception) {
            null
        }
    }

    private inner class PageAdapter : BaseAdapter() {
        override fun getCount(): Int = renderer?.pageCount ?: 0

        override fun getItem(position: Int): Any = position

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val iv = if (convertView is ImageView) convertView else ImageView(this@PdfActivity)
            iv.adjustViewBounds = true
            iv.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
            iv.setImageBitmap(pageBitmap(position))
            if (night) iv.colorFilter = invertFilter else iv.clearColorFilter()
            return iv
        }
    }

    private fun toggleNight() {
        night = !night
        val adapter = list?.adapter
        if (adapter is BaseAdapter) adapter.notifyDataSetChanged()
    }

    private fun askPage() {
        val total = renderer?.pageCount ?: 0
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.hint = "۱ تا " + faDigits(total.toString())
        val holder = FrameLayout(this)
        holder.setPadding(dp(20), dp(8), dp(20), 0)
        holder.addView(input, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("رفتن به صفحه")
            .setView(holder)
            .setPositiveButton("برو") { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n != null && n >= 1 && n <= total) list?.setSelection(n - 1) else toast("شماره‌ی صفحه نامعتبر است")
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun openExternal() {
        val u = fileUri ?: return
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(u, "application/pdf")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "باز کردن با"))
        } catch (e: Exception) {
            toast("برنامه‌ای برای باز کردن PDF نیست")
        }
    }
}
