package com.nova.browser

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal class TermuxResult(val ok: Boolean, val stdout: String, val stderr: String, val exitCode: Int, val error: String)

/** Runs commands inside Termux through its RUN_COMMAND service (needs allow-external-apps=true). */
internal object TermuxBridge {
    const val PKG = "com.termux"
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    const val RESULT_ACTION = "ir.noornavar.nova.TERMUX_RESULT"

    private val callbacks = HashMap<Int, (TermuxResult) -> Unit>()
    private var nextId = 1
    private val handler = Handler(Looper.getMainLooper())

    fun isInstalled(ctx: Context): Boolean {
        return try {
            ctx.packageManager.getPackageInfo(PKG, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** True when commands can reach Termux either through the RUN_COMMAND permission or the shared-folder daemon. */
    fun available(ctx: Context): Boolean = (isInstalled(ctx) && hasPermission(ctx)) || QueueBridge.ready(ctx)

    fun run(ctx: Context, command: String, timeoutMs: Long, cb: (TermuxResult) -> Unit) {
        if (isInstalled(ctx) && hasPermission(ctx)) {
            runIntent(ctx, command, timeoutMs, cb)
        } else if (QueueBridge.ready(ctx)) {
            QueueBridge.run(ctx, command, timeoutMs, cb)
        } else {
            cb(TermuxResult(false, "", "", -1, "اتصالی به Termux برقرار نیست. پوشه‌ی مشترک را انتخاب کنید و «nova daemon» را اجرا کنید."))
        }
    }

    private fun runIntent(ctx: Context, command: String, timeoutMs: Long, cb: (TermuxResult) -> Unit) {
        val id = synchronized(this) {
            val v = nextId
            nextId += 1
            v
        }
        callbacks[id] = cb
        val ri = Intent(ctx, TermuxResultReceiver::class.java)
        ri.action = RESULT_ACTION
        ri.putExtra("req", id)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
        val pi = PendingIntent.getBroadcast(ctx, id, ri, flags)

        val i = Intent()
        i.setClassName(PKG, "com.termux.app.RunCommandService")
        i.action = "com.termux.RUN_COMMAND"
        i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
        i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
        i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
        i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
        i.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        try {
            ctx.startService(i)
        } catch (e: Exception) {
            callbacks.remove(id)
            cb(TermuxResult(false, "", "", -1, "اجرای دستور ممکن نشد: " + (e.message ?: e.javaClass.simpleName)))
            return
        }
        handler.postDelayed({
            val c = callbacks.remove(id)
            if (c != null) c(TermuxResult(false, "", "", -1, "زمان اجرا تمام شد"))
        }, timeoutMs)
    }

    fun deliver(id: Int, r: TermuxResult) {
        val c = callbacks.remove(id)
        if (c != null) c(r)
    }
}

class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return
        val id = intent.getIntExtra("req", -1)
        val b = intent.getBundleExtra("result")
        if (b == null) {
            TermuxBridge.deliver(id, TermuxResult(false, "", "", -1, "نتیجه‌ای از Termux نرسید"))
            return
        }
        val err = b.getInt("err", -1)
        val code = b.getInt("exitCode", -1)
        val out = b.getString("stdout") ?: ""
        val errText = b.getString("stderr") ?: ""
        val errMsg = b.getString("errmsg") ?: ""
        val failed = err != -1 && err != 0
        TermuxBridge.deliver(id, TermuxResult(!failed, out, errText, code, errMsg))
    }
}

/**
 * Permission-free bridge: Nova writes a signed command file into the shared project folder and the
 * "nova daemon" running in Termux executes it and writes the result back.
 */
internal object QueueBridge {
    private const val DIR = "_nova_bridge"

    fun secret(ctx: Context): String {
        val sp = ctx.getSharedPreferences("nova_ai", Context.MODE_PRIVATE)
        val enc = sp.getString("bridge_secret", null)
        if (enc != null) {
            val plain = SecureStore.decrypt(enc)
            if (plain != null) return plain
        }
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02x", b))
        val s = sb.toString()
        sp.edit().putString("bridge_secret", SecureStore.encrypt(s)).apply()
        return s
    }

    fun ready(ctx: Context): Boolean = WorkspaceManager.isShared(ctx)

    private fun hmac(key: String, data: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val out = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (b in out) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun run(ctx: Context, command: String, timeoutMs: Long, cb: (TermuxResult) -> Unit) {
        val app = ctx.applicationContext
        val main = Handler(Looper.getMainLooper())
        Thread {
            val r = execute(app, command, timeoutMs)
            main.post { cb(r) }
        }.start()
    }

    private fun execute(ctx: Context, command: String, timeoutMs: Long): TermuxResult {
        val ws = WorkspaceManager.get(ctx)
        if (ws !is SafWorkspace) return TermuxResult(false, "", "", -1, "پوشه‌ی مشترک تنظیم نشده است")
        val id = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16)
        val ts = System.currentTimeMillis() / 1000
        val sig = hmac(secret(ctx), id + "\n" + ts + "\n" + command)
        val j = JSONObject()
        j.put("id", id)
        j.put("ts", ts)
        j.put("cmd", command)
        j.put("sig", sig)
        val inPath = DIR + "/inbox/" + id + ".json"
        val outPath = DIR + "/outbox/" + id + ".json"
        if (!ws.writeText(inPath, j.toString())) {
            return TermuxResult(false, "", "", -1, "نوشتن در پوشه‌ی مشترک ناموفق بود")
        }
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Thread.sleep(700)
            } catch (e: InterruptedException) {
                break
            }
            val raw = ws.readText(outPath)
            if (raw != null) {
                try {
                    val r = JSONObject(raw)
                    ws.delete(outPath)
                    val code = r.optInt("exit", 0)
                    return TermuxResult(true, r.optString("stdout"), r.optString("stderr"), code, "")
                } catch (e: Exception) {
                    // result still being written, try again
                }
            }
        }
        ws.delete(inPath)
        return TermuxResult(false, "", "", -1, "جوابی نیامد. در Termux باید «nova daemon» اجرا باشد و پوشه‌ی انتخاب‌شده در نوا همان پوشه‌ی NovaProjects باشد.")
    }
}
