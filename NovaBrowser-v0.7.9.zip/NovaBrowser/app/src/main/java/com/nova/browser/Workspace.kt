package com.nova.browser

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

/** A project folder the assistant (and the user) can read and write. */
internal interface Workspace {
    fun label(): String
    fun list(path: String): List<String>
    fun read(path: String): ByteArray?
    fun write(path: String, data: ByteArray): Boolean
    fun delete(path: String): Boolean
    fun uriOf(path: String): Uri?
}

internal fun cleanPath(path: String): List<String>? {
    val parts = path.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
    for (p in parts) {
        if (p == "..") return null
    }
    return parts
}

internal fun Workspace.readText(path: String): String? {
    val b = read(path) ?: return null
    return String(b, Charsets.UTF_8)
}

internal fun Workspace.writeText(path: String, text: String): Boolean = write(path, text.toByteArray(Charsets.UTF_8))

internal class LocalWorkspace(private val root: File) : Workspace {
    private fun file(path: String): File? {
        val parts = cleanPath(path) ?: return null
        var f = root
        for (p in parts) f = File(f, p)
        return f
    }

    override fun label(): String = "پوشه‌ی داخلی نوا"

    override fun list(path: String): List<String> {
        val f = file(path) ?: return ArrayList()
        val names = f.list() ?: return ArrayList()
        val out = ArrayList<String>()
        for (n in names.sorted()) out.add(if (File(f, n).isDirectory) n + "/" else n)
        return out
    }

    override fun read(path: String): ByteArray? {
        val f = file(path) ?: return null
        return if (f.isFile) f.readBytes() else null
    }

    override fun write(path: String, data: ByteArray): Boolean {
        val f = file(path) ?: return false
        return try {
            f.parentFile?.mkdirs()
            f.writeBytes(data)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun delete(path: String): Boolean {
        val f = file(path) ?: return false
        return if (f == root) false else f.deleteRecursively()
    }

    override fun uriOf(path: String): Uri? {
        val f = file(path) ?: return null
        return Uri.fromFile(f)
    }
}

internal class SafWorkspace(private val ctx: Context, private val tree: Uri) : Workspace {
    private val resolver = ctx.contentResolver
    private val rootId: String = DocumentsContract.getTreeDocumentId(tree)

    private class Entry(val id: String, val name: String, val mime: String)

    private fun docUri(id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    private fun children(id: String): List<Entry> {
        val out = ArrayList<Entry>()
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
        var c: Cursor? = null
        try {
            c = resolver.query(
                uri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ),
                null, null, null
            )
            if (c != null) {
                while (c.moveToNext()) out.add(Entry(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
            }
        } catch (e: Exception) {
            // empty list on failure
        } finally {
            c?.close()
        }
        return out
    }

    private fun find(parentId: String, name: String): Entry? {
        for (e in children(parentId)) {
            if (e.name == name) return e
        }
        return null
    }

    private fun isDir(e: Entry): Boolean = e.mime == DocumentsContract.Document.MIME_TYPE_DIR

    /** Returns the document id of the entry at parts, or null. */
    private fun resolve(parts: List<String>): Entry? {
        var cur = Entry(rootId, "", DocumentsContract.Document.MIME_TYPE_DIR)
        for (p in parts) {
            cur = find(cur.id, p) ?: return null
        }
        return cur
    }

    private fun ensureDir(parts: List<String>): String? {
        var curId = rootId
        for (p in parts) {
            val existing = find(curId, p)
            if (existing != null) {
                if (!isDir(existing)) return null
                curId = existing.id
            } else {
                val created = try {
                    DocumentsContract.createDocument(resolver, docUri(curId), DocumentsContract.Document.MIME_TYPE_DIR, p)
                } catch (e: Exception) {
                    null
                }
                if (created == null) return null
                curId = DocumentsContract.getDocumentId(created)
            }
        }
        return curId
    }

    override fun label(): String = "پوشه‌ی مشترک (" + (Uri.decode(rootId)) + ")"

    override fun list(path: String): List<String> {
        val parts = cleanPath(path) ?: return ArrayList()
        val e = resolve(parts) ?: return ArrayList()
        if (!isDir(e)) return ArrayList()
        val out = ArrayList<String>()
        for (c in children(e.id).sortedBy { it.name }) out.add(if (isDir(c)) c.name + "/" else c.name)
        return out
    }

    override fun read(path: String): ByteArray? {
        val parts = cleanPath(path) ?: return null
        val e = resolve(parts) ?: return null
        if (isDir(e)) return null
        return try {
            resolver.openInputStream(docUri(e.id))?.use { it.readBytes() }
        } catch (ex: Exception) {
            null
        }
    }

    override fun write(path: String, data: ByteArray): Boolean {
        val parts = cleanPath(path) ?: return false
        if (parts.isEmpty()) return false
        val parentId = ensureDir(parts.subList(0, parts.size - 1)) ?: return false
        val name = parts[parts.size - 1]
        return try {
            val existing = find(parentId, name)
            val target: Uri? = if (existing != null) {
                docUri(existing.id)
            } else {
                DocumentsContract.createDocument(resolver, docUri(parentId), "application/octet-stream", name)
            }
            if (target == null) {
                false
            } else {
                val out = resolver.openOutputStream(target, "wt")
                if (out == null) {
                    false
                } else {
                    out.use { it.write(data) }
                    true
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun delete(path: String): Boolean {
        val parts = cleanPath(path) ?: return false
        if (parts.isEmpty()) return false
        val e = resolve(parts) ?: return false
        return try {
            DocumentsContract.deleteDocument(resolver, docUri(e.id))
        } catch (ex: Exception) {
            false
        }
    }

    override fun uriOf(path: String): Uri? {
        val parts = cleanPath(path) ?: return null
        val e = resolve(parts) ?: return null
        return docUri(e.id)
    }
}

internal object WorkspaceManager {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("nova_ws", Context.MODE_PRIVATE)

    fun get(ctx: Context): Workspace {
        val t = sp(ctx).getString("tree", null)
        if (t != null) {
            try {
                val uri = Uri.parse(t)
                var granted = false
                for (p in ctx.contentResolver.persistedUriPermissions) {
                    if (p.uri == uri && p.isReadPermission && p.isWritePermission) granted = true
                }
                if (granted) return SafWorkspace(ctx, uri)
            } catch (e: Exception) {
                // fall back to the internal folder
            }
        }
        val root = File(ctx.filesDir, "workspace")
        root.mkdirs()
        return LocalWorkspace(root)
    }

    fun setTree(ctx: Context, uri: Uri?) {
        sp(ctx).edit().putString("tree", uri?.toString()).apply()
    }

    fun isShared(ctx: Context): Boolean = get(ctx) is SafWorkspace
}
